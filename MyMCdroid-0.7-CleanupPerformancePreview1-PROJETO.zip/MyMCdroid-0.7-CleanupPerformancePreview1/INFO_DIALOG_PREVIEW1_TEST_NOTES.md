# MyMCdroid 2.2.0 — Info Dialog Preview 1

## Alterações

- A janela de Informações usa a mesma entrada suave e centralizada dos demais popups.
- A animação lateral do sistema foi desativada.
- Largura, altura e posição são definidas antes do primeiro quadro.
- Ordem das ações: Manual → Engrenagem → Sobre → Fechar.
- O ícone Fechar permanece isolado à direita.
- A engrenagem está reservada para implementações futuras e exibe um aviso ao ser tocada.
- Os conteúdos completos de Manual e Sobre foram preservados.

## Roteiro de teste

1. Abra a janela pelo botão de Informações e confirme que ela surge centralizada e suavemente.
2. Confira a ordem Livro, Engrenagem, Perfil e Fechar.
3. Alterne entre Manual e Sobre e valide o destaque da aba ativa.
4. Toque na engrenagem e confirme o aviso de implementação futura.
5. Feche e reabra a janela repetidamente, em retrato e paisagem.

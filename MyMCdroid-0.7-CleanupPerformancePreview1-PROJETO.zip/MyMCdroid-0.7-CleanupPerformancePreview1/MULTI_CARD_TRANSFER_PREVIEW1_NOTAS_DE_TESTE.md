# MyMCdroid 2.2.0 — Multi Card Transfer Preview 1

## Principais testes

1. Abra ou crie dois ou mais Memory Cards e confirme o indicador `1/2`, `2/2` ou equivalente.
2. Arraste horizontalmente sobre a caixa do Memory Card, a barra de ações ou a lista para alternar entre os cartões.
3. Com dois cartões abertos, selecione um Game Save e teste **Transferir Game Save**.
4. Ative as opções em lote e teste **Transferir Save Games** com dois ou mais itens selecionados.
5. Em um cartão com pelo menos dois Save Games, teste **Transferir Todos os Save Games**.
6. Confirme que a mensagem mostra o nome correto do cartão de destino e que, após a operação, a tela muda para ele.
7. Se houver mais de um destino possível, confirme a seleção do Memory Card antes da mensagem final.
8. Repita os testes entre arquivo `.PS2` e Memory Card em pasta, nas duas direções.
9. Verifique sobrescrita de um Game Save com o mesmo Serial ID + Região no cartão de destino.
10. Confirme que importação, exportação, remoção, formatação, Manual, Sobre e idiomas permanecem funcionando.

## Resultado da validação interna

- Transferência direta preservando arquivos, datas e metadados: validada.
- Transferência pasta → pasta, pasta → `.PS2` e `.PS2` → pasta: validada.
- Recursos Android e XML: compilados com `aapt2` sem erros.
- Motor Python: verificação de sintaxe e testes de regressão aprovados.

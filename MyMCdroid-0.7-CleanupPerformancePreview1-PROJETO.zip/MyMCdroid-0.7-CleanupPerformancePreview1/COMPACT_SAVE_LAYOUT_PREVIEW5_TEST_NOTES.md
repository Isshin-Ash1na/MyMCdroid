# MyMCdroid 2.2.0 — Compact Save Layout Preview 5

## Botões do Memory Card

1. Ao iniciar o aplicativo, somente Abrir e Criar devem estar visíveis e centralizados.
2. As molduras dos botões não devem estar cortadas ou sobrepostas.
3. Abra ou crie um Memory Card.
4. Após aproximadamente dois segundos, Fechar e Apagar Todos devem surgir juntos da direita para a esquerda.
5. O conjunto completo deve permanecer centralizado.
6. Ao fechar o Memory Card, Fechar e Apagar Todos devem desaparecer.

## Importação sem espaço

Em um Memory Card cheio, tente importar um save novo. A mensagem esperada é:

“Sem Espaço no Memory Card - Apague um ou mais save games”

## Apagar todos

1. Confira o novo ícone vermelho, combinando Memory Card fechado e lixeira.
2. Confirme que a operação exige duas confirmações.
3. Cancele cada etapa separadamente e verifique que nenhum save foi removido.
4. Execute a operação somente em uma cópia de teste e reabra o arquivo para confirmar o resultado.

## Manual

- A explicação “Ícone 3D por save” deve ter sido removida.
- Confira os novos textos de Abrir, Fechar e Apagar todos os saves.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

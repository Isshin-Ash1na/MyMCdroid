# MyMCdroid 2.2.0 — Animated Icon Preview 1

## Alteração para teste

- A visualização 3D ampliada agora reproduz a animação original armazenada no PS2ICON.
- A primeira chave de cada trilha é preservada e as formas do modelo são interpoladas suavemente.
- Um pequeno controle branco permite pausar ou continuar somente a animação original.
- A rotação automática continua com seu controle independente e o giro manual foi preservado.
- Miniaturas e renders da lista permanecem no fluxo estático/isolado atual, sem animação adicional.

## Testes sugeridos

1. Abra os Game Saves de Onimusha 2, Onimusha 3 e Urban Reign e amplie seus ícones.
2. Confirme que cada modelo se movimenta continuamente sem trocar de ícone ou piscar as miniaturas.
3. Pause a animação original pelo pequeno botão branco e confirme que a rotação continua.
4. Pause a rotação pelo botão inferior e confirme que a animação original continua.
5. Feche e reabra a visualização ampliada algumas vezes e confirme que somente uma janela é aberta.

O ZIP contém somente o projeto-fonte. Nenhum APK compilado está incluído.

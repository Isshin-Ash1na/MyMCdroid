# MyMCdroid 2.2.0 — Expanded Save Preview 2

## Correção principal

As miniaturas visíveis são suspensas antes da criação do renderizador ampliado e reconstruídas ao fechar o modal. Isso evita perda de contextos WebGL e desaparecimento de ícones.

## Roteiro de testes

1. Abra um Memory Card com vários Save Games visíveis.
2. Selecione um Game Save e abra seu ícone ampliado.
3. Feche o modal e confira se todas as miniaturas retornaram corretamente.
4. Repita rapidamente com diferentes Game Saves.
5. Role a lista, abra outro ícone e confira as miniaturas novamente.
6. Pause a rotação e gire o modelo manualmente.
7. Feche pelo X, botão Voltar e toque externo.
8. Confirme que nenhum Game Save recebe o ícone pertencente a outro item.
9. Ative o modo em lote e confirme que o modal não abre nesse estado.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

# MyMCdroid 2.2.0 — Compact Save Layout Preview 8

## Teste intensivo de renderização

1. Abra um Memory Card com vários Game Saves.
2. Selecione rapidamente Game Saves diferentes durante pelo menos um minuto.
3. Alterne entre toques na linha e diretamente no ícone 3D.
4. Role a lista repetidamente durante o teste.
5. Confirme que cada ícone continua associado ao Game Save correto.
6. Confirme que não aparecem textos técnicos relacionados a WebGL.

## Game Save já selecionado

1. Selecione um Game Save e aguarde Exportar e Apagar aparecerem.
2. Toque repetidamente na mesma linha e no mesmo ícone 3D.
3. A seleção deve permanecer inalterada.
4. A rotação não deve reiniciar.
5. Exportar e Apagar não devem repetir a animação de entrada.

## Otimizações incluídas

- O modelo Base64 não é reenviado quando a linha continua vinculada ao mesmo Game Save.
- Apenas mudanças reais de seleção alteram a rotação.
- Renderizações fora da tela são pausadas.
- Respostas atrasadas continuam protegidas pelo controle de geração.
- Buffers e texturas WebGL permanecem reutilizados.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

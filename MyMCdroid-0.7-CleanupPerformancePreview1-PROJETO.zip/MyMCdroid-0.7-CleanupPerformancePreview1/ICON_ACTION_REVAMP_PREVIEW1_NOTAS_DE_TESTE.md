# MyMCdroid 2.2.0 — Icon Action Revamp Preview 1

## Alterações principais

- Iconografia de ações redesenhada com traços e contornos.
- Novo símbolo circular para **Ativar opções em lote**.
- **Remover Save Games** representado por duas lixeiras.
- Ícones de Manual, engrenagem, Sobre e Memory Card harmonizados com o novo padrão.
- Iluminação dos renders 3D reforçada nas miniaturas e na visualização ampliada.
- Nova função **Exportar Todos os Save Games**, com escolha entre PSU, MAX, CBS, SPS e XPS.
- Caixa do Memory Card posicionada abaixo da logo e barra de ações abaixo da caixa.
- Nova sequência da barra: Abrir, Exportar Todos, Exportar selecionados, Criar, Remover selecionados, Formatar e Fechar.
- Toque no ícone do Memory Card recolhe ou mostra apenas a barra de ações e o botão Importar.
- Rolagem da lista bloqueada durante operações iniciadas pela barra e pelo botão Importar.
- Miniaturas pré-carregadas e verificadas antes da lista ser revelada.
- Português (Brasil) e inglês preservados.

## Roteiro de testes

1. Inicie sem Memory Card e verifique a nova posição da caixa e os botões Abrir/Criar.
2. Toque no ícone do Memory Card e confirme que apenas os controles são recolhidos.
3. Abra cartões com zero, um e vários Save Games e confira quais botões ficam disponíveis.
4. Em um cartão com pelo menos dois Save Games, teste **Exportar Todos os Save Games** nos cinco formatos.
5. Ative o modo em lote e confirme a ordem e as animações de Exportar/Remover Save Games.
6. Feche o Memory Card e tente rolar a lista imediatamente; a lista deve permanecer bloqueada durante a transição.
7. Abra cartões com muitos Save Games e confirme que as miniaturas surgem já renderizadas.
8. Compare a iluminação das miniaturas com a visualização ampliada.
9. Repita os testes em Português (Brasil) e English (United States).

Este pacote contém somente o projeto-fonte. APK, AAB e diretórios de compilação não estão incluídos.

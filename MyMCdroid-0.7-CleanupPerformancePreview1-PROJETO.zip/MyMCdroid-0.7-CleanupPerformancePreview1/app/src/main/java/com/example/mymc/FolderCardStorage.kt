package com.example.mymc

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File

/**
 * Bridges Android's Storage Access Framework directory URIs to the local
 * folder-card backend. Heavy parsing and mutations happen in the local mirror;
 * this class synchronizes the result back to the directory selected by the
 * user without requiring broad storage permissions.
 */
class FolderCardStorage(private val context: Context) {
    private data class Entry(
        val name: String,
        val uri: Uri,
        val isDirectory: Boolean,
    )

    private val resolver get() = context.contentResolver

    fun copyTreeToCache(treeUri: Uri): File {
        val target = File(context.cacheDir, "folder-card-${System.currentTimeMillis()}")
        if (!target.mkdirs()) {
            throw IllegalStateException("Não foi possível preparar o Memory Card em pasta")
        }
        try {
            copyDirectoryFromTree(treeUri, selectedDocumentUri(treeUri), target)
            return target
        } catch (error: Exception) {
            target.deleteRecursively()
            throw error
        }
    }

    fun copySaveFolderToCache(treeUri: Uri): File {
        val container = File(context.cacheDir, "folder-save-${System.currentTimeMillis()}")
        if (!container.mkdirs()) {
            throw IllegalStateException("Não foi possível preparar o Game Save em pasta")
        }
        val target = File(container, treeDisplayName(treeUri))
        if (!target.mkdir()) {
            container.deleteRecursively()
            throw IllegalStateException("Não foi possível preparar o Game Save em pasta")
        }
        try {
            copyDirectoryFromTree(treeUri, selectedDocumentUri(treeUri), target)
            return target
        } catch (error: Exception) {
            container.deleteRecursively()
            throw error
        }
    }

    fun exportDirectoryToTree(
        localRoot: File,
        parentTreeUri: Uri,
        requestedName: String,
    ): String {
        require(localRoot.isDirectory) { "O Game Save em pasta é inválido" }
        val parent = selectedDocumentUri(parentTreeUri)
        val baseName = safeName(requestedName)
        val occupied = listChildren(parentTreeUri, parent)
            .map { it.name.lowercase() }
            .toMutableSet()
        var finalName = baseName
        var suffix = 2
        while (finalName.lowercase() in occupied) {
            finalName = "$baseName ($suffix)"
            suffix++
        }

        val created = createDirectory(parent, finalName)
        try {
            syncDirectory(parentTreeUri, created, localRoot)
            return finalName
        } catch (error: Exception) {
            deleteCreatedCardDirectory(created)
            throw error
        }
    }

    fun syncCacheToTree(localRoot: File, treeUri: Uri, allowEmptyDestination: Boolean = false) {
        require(localRoot.isDirectory) { "O espelho do Memory Card em pasta é inválido" }
        require(File(localRoot, "_pcsx2_superblock").isFile) {
            "O Memory Card em pasta não possui _pcsx2_superblock"
        }
        val root = selectedDocumentUri(treeUri)
        val remote = listChildren(treeUri, root)
        if (allowEmptyDestination && remote.isNotEmpty()) {
            throw IllegalStateException(
                "Selecione uma pasta vazia para criar o Memory Card em pasta"
            )
        }
        if (!allowEmptyDestination && remote.none { it.name == "_pcsx2_superblock" }) {
            throw IllegalStateException(
                "A pasta selecionada não é um Memory Card em pasta reconhecido"
            )
        }
        syncDirectory(treeUri, root, localRoot)
    }

    fun createCardDirectory(parentTreeUri: Uri, requestedName: String): Uri {
        val name = safeName(requestedName)
        val parent = selectedDocumentUri(parentTreeUri)
        if (listChildren(parentTreeUri, parent).any { it.name.equals(name, ignoreCase = true) }) {
            throw IllegalStateException(context.getString(R.string.folder_card_name_exists, name))
        }
        val created = createDirectory(parent, name)
        return DocumentsContract.buildDocumentUriUsingTree(
            parentTreeUri,
            DocumentsContract.getDocumentId(created),
        )
    }

    fun deleteCreatedCardDirectory(uri: Uri) {
        try {
            DocumentsContract.deleteDocument(resolver, uri)
        } catch (_: Exception) {
            // Best-effort rollback after a failed creation. Never mask the
            // original error which will be shown to the user.
        }
    }

    private fun selectedDocumentUri(uri: Uri): Uri =
        if (DocumentsContract.isDocumentUri(context, uri)) {
            uri
        } else {
            DocumentsContract.buildDocumentUriUsingTree(
                uri,
                DocumentsContract.getTreeDocumentId(uri),
            )
        }

    private fun treeDisplayName(treeUri: Uri): String {
        val selected = selectedDocumentUri(treeUri)
        try {
            resolver.query(
                selected,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME
                    )
                    if (index >= 0) return safeName(cursor.getString(index))
                }
            }
        } catch (_: Exception) {
            // Fall back to the URI when a provider omits the display name.
        }
        return safeName(treeUri.lastPathSegment?.substringAfterLast(':') ?: "GameSave")
    }

    private fun safeName(value: String): String {
        if (value.isBlank() || value == "." || value == ".." ||
            value.any { it < ' ' || it in "\\/:*?\"<>|" }
        ) {
            throw IllegalStateException("Nome inválido no Memory Card em pasta")
        }
        return value
    }

    private fun listChildren(treeUri: Uri, parentUri: Uri): List<Entry> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri,
            DocumentsContract.getDocumentId(parentUri),
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
        val entries = mutableListOf<Entry>()
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID
            )
            val nameIndex = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            )
            val typeIndex = cursor.getColumnIndexOrThrow(
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            while (cursor.moveToNext()) {
                val id = cursor.getString(idIndex)
                val name = safeName(cursor.getString(nameIndex))
                val mime = cursor.getString(typeIndex)
                entries += Entry(
                    name,
                    DocumentsContract.buildDocumentUriUsingTree(treeUri, id),
                    mime == DocumentsContract.Document.MIME_TYPE_DIR,
                )
            }
        }
        return entries
    }

    private fun copyDirectoryFromTree(treeUri: Uri, remoteDir: Uri, localDir: File) {
        for (entry in listChildren(treeUri, remoteDir)) {
            val target = File(localDir, entry.name)
            if (entry.isDirectory) {
                if (!target.mkdir()) {
                    throw IllegalStateException("Não foi possível copiar ${entry.name}")
                }
                copyDirectoryFromTree(treeUri, entry.uri, target)
            } else {
                resolver.openInputStream(entry.uri).use { rawInput ->
                    BufferedInputStream(requireNotNull(rawInput), BUFFER_SIZE).use { input ->
                        BufferedOutputStream(target.outputStream(), BUFFER_SIZE).use { output ->
                            input.copyTo(output, BUFFER_SIZE)
                        }
                    }
                }
            }
        }
    }

    private fun syncDirectory(treeUri: Uri, remoteDir: Uri, localDir: File) {
        val remoteByName = listChildren(treeUri, remoteDir).associateBy { it.name }.toMutableMap()
        val localChildren = localDir.listFiles()?.sortedBy { it.name.lowercase() }.orEmpty()

        for (local in localChildren) {
            val existing = remoteByName.remove(local.name)
            if (local.isDirectory) {
                val directoryUri = when {
                    existing == null -> createDirectory(remoteDir, local.name)
                    existing.isDirectory -> existing.uri
                    else -> {
                        deleteDocument(existing.uri)
                        createDirectory(remoteDir, local.name)
                    }
                }
                syncDirectory(treeUri, directoryUri, local)
            } else {
                val fileUri = when {
                    existing == null -> createFile(remoteDir, local.name)
                    !existing.isDirectory -> existing.uri
                    else -> {
                        deleteDocument(existing.uri)
                        createFile(remoteDir, local.name)
                    }
                }
                writeFile(local, fileUri)
            }
        }

        // A folder Memory Card is a dedicated tree. Entries absent from the
        // validated local mirror are saves or PCSX2 control files removed by
        // the requested operation and must also disappear from user storage.
        remoteByName.values.forEach { deleteDocument(it.uri) }
    }

    private fun createDirectory(parent: Uri, name: String): Uri =
        requireNotNull(
            DocumentsContract.createDocument(
                resolver,
                parent,
                DocumentsContract.Document.MIME_TYPE_DIR,
                name,
            )
        ) { "Não foi possível criar a pasta $name" }

    private fun createFile(parent: Uri, name: String): Uri =
        requireNotNull(
            DocumentsContract.createDocument(
                resolver,
                parent,
                "application/octet-stream",
                name,
            )
        ) { "Não foi possível criar o arquivo $name" }

    private fun writeFile(source: File, destination: Uri) {
        resolver.openOutputStream(destination, "wt").use { rawOutput ->
            BufferedOutputStream(requireNotNull(rawOutput), BUFFER_SIZE).use { output ->
                BufferedInputStream(source.inputStream(), BUFFER_SIZE).use { input ->
                    input.copyTo(output, BUFFER_SIZE)
                }
                output.flush()
            }
        }
        try {
            resolver.openFileDescriptor(destination, "r")?.use { descriptor ->
                if (descriptor.statSize >= 0L && descriptor.statSize != source.length()) {
                    throw IllegalStateException(
                        "Arquivo incompleto em ${source.name}: ${descriptor.statSize}/${source.length()} bytes"
                    )
                }
            }
        } catch (error: IllegalStateException) {
            throw error
        } catch (_: Exception) {
            // Some document providers do not report a size after a write.
        }
    }

    private fun deleteDocument(uri: Uri) {
        if (!DocumentsContract.deleteDocument(resolver, uri)) {
            throw IllegalStateException("Não foi possível atualizar o Memory Card em pasta")
        }
    }

    private companion object {
        const val BUFFER_SIZE = 256 * 1024
    }
}

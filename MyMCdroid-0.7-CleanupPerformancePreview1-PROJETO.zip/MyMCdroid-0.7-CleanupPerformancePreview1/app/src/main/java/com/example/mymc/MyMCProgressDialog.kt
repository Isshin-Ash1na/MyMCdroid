package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.TextView

object MyMCProgressDialog {
    fun show(context: Context, title: String, message: String): Dialog {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_mymc_progress, null)
        view.findViewById<TextView>(R.id.progressTitle).text = title
        view.findViewById<TextView>(R.id.progressMessage).text = message
        dialog.setContentView(view)
        dialog.setCancelable(false)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((context.resources.displayMetrics.widthPixels * 0.84).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        }
        dialog.show()
        dialog.window?.setLayout((context.resources.displayMetrics.widthPixels * 0.84).toInt(), WindowManager.LayoutParams.WRAP_CONTENT)
        return dialog
    }
}

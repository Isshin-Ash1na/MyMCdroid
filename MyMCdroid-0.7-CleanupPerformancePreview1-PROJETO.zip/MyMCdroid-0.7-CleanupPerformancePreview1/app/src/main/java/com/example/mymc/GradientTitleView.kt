package com.example.mymc

import android.content.Context
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.util.AttributeSet
import android.widget.TextView
import androidx.appcompat.widget.AppCompatTextView

class GradientTitleView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatTextView(context, attrs) {

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val label = text.toString()
        val droidStart = label.indexOf("droid", ignoreCase = true)
        if (droidStart < 0) return
        paint.shader = null
        val branded = SpannableString(label).apply {
            setSpan(
                ForegroundColorSpan(context.getColor(R.color.ps2_blue)),
                0,
                droidStart,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
            setSpan(
                ForegroundColorSpan(context.getColor(R.color.ps2_green)),
                droidStart,
                length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
        }
        super.setText(branded, TextView.BufferType.SPANNABLE)
    }
}

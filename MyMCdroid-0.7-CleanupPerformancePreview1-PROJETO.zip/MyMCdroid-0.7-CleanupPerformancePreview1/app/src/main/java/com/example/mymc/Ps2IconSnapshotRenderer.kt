package com.example.mymc

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.Base64
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Creates a stable, software-rendered thumbnail for a PS2ICON payload.
 *
 * List rows use these cached bitmaps instead of owning a WebView/WebGL context.
 * This prevents recycled rows from losing or exchanging GPU contexts while the
 * user scrolls and rapidly changes the selected Game Save.
 */
object Ps2IconSnapshotRenderer {
    private const val TEXTURE_SIZE = 128

    private data class IconData(
        val vertexCount: Int,
        val positions: FloatArray,
        val normals: FloatArray,
        val uvs: FloatArray,
        val colors: IntArray,
        val texture: Bitmap?
    )

    private data class ProjectedVertex(
        val x: Float,
        val y: Float,
        val depth: Float,
        val u: Float,
        val v: Float,
        val color: Int
    )

    private data class Triangle(
        val a: ProjectedVertex,
        val b: ProjectedVertex,
        val c: ProjectedVertex,
        val depth: Float
    )

    fun render(payloadJson: String, sizePx: Int = 160): Bitmap {
        val size = sizePx.coerceAtLeast(48)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        drawBackground(canvas, size)
        val data = parsePayload(payloadJson) ?: return output
        drawIcon(canvas, size, data)
        data.texture?.recycle()
        return output
    }

    private fun drawBackground(canvas: Canvas, size: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, 0f, size.toFloat(),
                intArrayOf(Color.rgb(105, 166, 215), Color.rgb(79, 143, 197), Color.rgb(57, 116, 170)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)
    }

    private fun parsePayload(json: String): IconData? {
        return try {
            val root = JSONObject(json)
            if (!root.optBoolean("ok", false)) return null
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                for (index in 0 until candidates.length()) {
                    val encoded = candidates.optJSONObject(index)?.optString("icon").orEmpty()
                    parseIcon(Base64.decode(encoded, Base64.DEFAULT))?.let { return it }
                }
            }
            parseIcon(Base64.decode(root.optString("icon"), Base64.DEFAULT))
        } catch (_: Exception) {
            null
        }
    }

    private fun parseIcon(bytes: ByteArray): IconData? {
        if (bytes.size < 40) return null
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val magic = buffer.intAt(0)
        val shapeCount = buffer.intAt(4)
        val type = buffer.intAt(8)
        val vertexCount = buffer.intAt(16)
        if (magic != 0x00010000 || shapeCount <= 0 || shapeCount > 64 || vertexCount <= 0 || vertexCount > 250_000) {
            return null
        }
        var offset = 20
        val recordSize = shapeCount * 8 + 16
        if (offset.toLong() + vertexCount.toLong() * recordSize > bytes.size.toLong()) return null
        val positions = FloatArray(vertexCount * 3)
        val normals = FloatArray(vertexCount * 3)
        val uvs = FloatArray(vertexCount * 2)
        val colorChannels = IntArray(vertexCount * 4)
        var anyAlpha = false
        val scale = 1f / 4096f
        repeat(vertexCount) { index ->
            repeat(shapeCount) { shape ->
                val x = buffer.shortAt(offset).toInt() * scale
                val y = buffer.shortAt(offset + 2).toInt() * scale
                val z = buffer.shortAt(offset + 4).toInt() * scale
                if (shape == 0) {
                    positions[index * 3] = x
                    positions[index * 3 + 1] = y
                    positions[index * 3 + 2] = z
                }
                offset += 8
            }
            normals[index * 3] = buffer.shortAt(offset).toInt() * scale
            normals[index * 3 + 1] = buffer.shortAt(offset + 2).toInt() * scale
            normals[index * 3 + 2] = buffer.shortAt(offset + 4).toInt() * scale
            offset += 8
            uvs[index * 2] = buffer.shortAt(offset).toInt() * scale
            uvs[index * 2 + 1] = buffer.shortAt(offset + 2).toInt() * scale
            offset += 4
            colorChannels[index * 4] = bytes[offset].toInt() and 0xff
            colorChannels[index * 4 + 1] = bytes[offset + 1].toInt() and 0xff
            colorChannels[index * 4 + 2] = bytes[offset + 2].toInt() and 0xff
            val ps2Alpha = bytes[offset + 3].toInt() and 0xff
            if (ps2Alpha != 0) anyAlpha = true
            colorChannels[index * 4 + 3] = min(255, ps2Alpha * 2)
            offset += 4
        }
        if (!anyAlpha) {
            for (index in 3 until colorChannels.size step 4) colorChannels[index] = 255
        }
        if (offset + 20 > bytes.size || buffer.intAt(offset) != 1) return null
        val frameCount = buffer.intAt(offset + 16)
        if (frameCount < 0 || frameCount > 100_000) return null
        offset += 20
        repeat(frameCount) {
            if (offset + 16 > bytes.size) return null
            val keyCount = buffer.intAt(offset + 4)
            if (keyCount <= 0) return null
            val advance = 16L + (keyCount - 1L) * 8L
            if (offset.toLong() + advance > bytes.size.toLong()) return null
            offset += advance.toInt()
        }
        val texture = if ((type and 4) != 0 && offset < bytes.size) {
            val raw = if ((type and 8) != 0) decodeRle(bytes, offset) else {
                bytes.copyOfRange(offset, min(bytes.size, offset + TEXTURE_SIZE * TEXTURE_SIZE * 2))
            }
            raw?.let(::decodeTexture1555)
        } else null
        val colors = IntArray(vertexCount) { index ->
            Color.argb(
                colorChannels[index * 4 + 3],
                colorChannels[index * 4],
                colorChannels[index * 4 + 1],
                colorChannels[index * 4 + 2]
            )
        }
        return IconData(vertexCount, positions, normals, uvs, colors, texture)
    }

    private fun decodeRle(bytes: ByteArray, start: Int): ByteArray? {
        if (start + 4 > bytes.size) return null
        val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val packedSize = buffer.intAt(start)
        if (packedSize < 0) return null
        var offset = start + 4
        val end = min(bytes.size.toLong(), offset.toLong() + packedSize.toLong()).toInt()
        val output = ArrayList<Byte>(TEXTURE_SIZE * TEXTURE_SIZE * 2)
        while (offset < end) {
            if (offset + 2 > end) return null
            val code = buffer.unsignedShortAt(offset)
            offset += 2
            if ((code and 0x8000) != 0) {
                val count = 0x10000 - code
                val byteCount = count * 2
                if (offset + byteCount > end) return null
                repeat(byteCount) { output.add(bytes[offset++]) }
            } else if (code > 0) {
                if (offset + 2 > end) return null
                val low = bytes[offset++]
                val high = bytes[offset++]
                repeat(code) {
                    output.add(low)
                    output.add(high)
                }
            }
            if (output.size > TEXTURE_SIZE * TEXTURE_SIZE * 2 * 4) return null
        }
        return ByteArray(output.size) { output[it] }
    }

    private fun decodeTexture1555(raw: ByteArray): Bitmap? {
        if (raw.size < TEXTURE_SIZE * TEXTURE_SIZE * 2) return null
        val pixels = IntArray(TEXTURE_SIZE * TEXTURE_SIZE)
        repeat(pixels.size) { index ->
            val value = (raw[index * 2].toInt() and 0xff) or ((raw[index * 2 + 1].toInt() and 0xff) shl 8)
            pixels[index] = Color.rgb(
                (value and 31) shl 3,
                ((value shr 5) and 31) shl 3,
                ((value shr 10) and 31) shl 3
            )
        }
        return Bitmap.createBitmap(pixels, TEXTURE_SIZE, TEXTURE_SIZE, Bitmap.Config.ARGB_8888)
    }

    private fun drawIcon(canvas: Canvas, size: Int, data: IconData) {
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var minZ = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        var maxZ = Float.NEGATIVE_INFINITY
        for (index in 0 until data.vertexCount) {
            minX = min(minX, data.positions[index * 3])
            minY = min(minY, data.positions[index * 3 + 1])
            minZ = min(minZ, data.positions[index * 3 + 2])
            maxX = max(maxX, data.positions[index * 3])
            maxY = max(maxY, data.positions[index * 3 + 1])
            maxZ = max(maxZ, data.positions[index * 3 + 2])
        }
        val centerX = (minX + maxX) * 0.5f
        val centerY = (minY + maxY) * 0.5f
        val centerZ = (minZ + maxZ) * 0.5f
        val dimension = max(maxX - minX, max(maxY - minY, maxZ - minZ))
        val modelScale = if (dimension > 0.00001f) 1.3f / dimension else 1f
        val angleY = Math.toRadians(220.0).toFloat()
        val angleX = (-Math.PI / 18.0).toFloat()
        val cosY = cos(angleY)
        val sinY = sin(angleY)
        val cosX = cos(angleX)
        val sinX = sin(angleX)
        val aspect = 1f
        val focal = (1.0 / tan(Math.PI / 8.0)).toFloat()
        val projected = ArrayList<ProjectedVertex>(data.vertexCount)
        repeat(data.vertexCount) { index ->
            var x = -(data.positions[index * 3] - centerX) * modelScale
            var y = -(data.positions[index * 3 + 1] - centerY) * modelScale
            var z = (data.positions[index * 3 + 2] - centerZ) * modelScale
            val ryX = cosY * x + sinY * z
            val ryZ = -sinY * x + cosY * z
            x = ryX
            z = ryZ
            val rxY = cosX * y - sinX * z
            val rxZ = sinX * y + cosX * z
            y = rxY
            z = rxZ - 2.5f
            val inverseDepth = 1f / max(0.08f, -z)
            val screenX = size * (0.5f + 0.5f * (focal / aspect) * x * inverseDepth)
            val screenY = size * (0.5f - 0.5f * focal * y * inverseDepth)

            var nx = -data.normals[index * 3]
            var ny = -data.normals[index * 3 + 1]
            var nz = data.normals[index * 3 + 2]
            val nRyX = cosY * nx + sinY * nz
            val nRyZ = -sinY * nx + cosY * nz
            nx = nRyX
            nz = nRyZ
            val nRxY = cosX * ny - sinX * nz
            val nRxZ = sinX * ny + cosX * nz
            ny = nRxY
            nz = nRxZ
            val normalLength = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(0.0001f)
            nx /= normalLength
            ny /= normalLength
            nz /= normalLength
            val key = max(0f, nx * 0.3504f + ny * 0.5506f + nz * 0.7608f)
            val fill = max(0f, nx * -0.797f + ny * 0.261f + nz * 0.551f)
            val hemi = 0.5f + 0.5f * ny
            val light = (0.68f + 0.30f * key + 0.16f * fill + 0.08f * hemi).coerceIn(0.62f, 1.18f)
            val original = data.colors[index]
            fun lit(channel: Int): Int = (255f * ((channel / 255f * light).coerceAtLeast(0f).pow(0.92f)))
                .toInt().coerceIn(0, 255)
            val litColor = Color.argb(
                Color.alpha(original),
                lit(Color.red(original)),
                lit(Color.green(original)),
                lit(Color.blue(original))
            )
            projected += ProjectedVertex(
                screenX, screenY, z,
                data.uvs[index * 2] * (TEXTURE_SIZE - 1),
                data.uvs[index * 2 + 1] * (TEXTURE_SIZE - 1),
                litColor
            )
        }

        val triangles = ArrayList<Triangle>(data.vertexCount / 3)
        var index = 0
        while (index + 2 < projected.size) {
            val a = projected[index]
            val b = projected[index + 1]
            val c = projected[index + 2]
            triangles += Triangle(a, b, c, (a.depth + b.depth + c.depth) / 3f)
            index += 3
        }
        triangles.sortBy { it.depth }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG or Paint.FILTER_BITMAP_FLAG)
        data.texture?.let {
            paint.shader = BitmapShader(it, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        }
        triangles.forEach { triangle ->
            val vertices = floatArrayOf(
                triangle.a.x, triangle.a.y,
                triangle.b.x, triangle.b.y,
                triangle.c.x, triangle.c.y
            )
            val textureCoordinates = if (data.texture != null) floatArrayOf(
                triangle.a.u, triangle.a.v,
                triangle.b.u, triangle.b.v,
                triangle.c.u, triangle.c.v
            ) else null
            val colors = intArrayOf(triangle.a.color, triangle.b.color, triangle.c.color)
            canvas.drawVertices(
                Canvas.VertexMode.TRIANGLES,
                vertices.size,
                vertices,
                0,
                textureCoordinates,
                0,
                colors,
                0,
                null,
                0,
                0,
                paint
            )
        }
    }

    private fun ByteBuffer.intAt(offset: Int): Int = getInt(offset)
    private fun ByteBuffer.shortAt(offset: Int): Short = getShort(offset)
    private fun ByteBuffer.unsignedShortAt(offset: Int): Int = getShort(offset).toInt() and 0xffff
}

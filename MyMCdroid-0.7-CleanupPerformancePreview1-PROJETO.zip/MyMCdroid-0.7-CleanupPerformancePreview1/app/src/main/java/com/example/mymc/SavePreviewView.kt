package com.example.mymc

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout

/**
 * Isolated PS2ICON preview. The WebGL context is created only after a save is
 * selected, so a bad icon cannot prevent the application from starting.
 * The renderer follows the mymc_web/dart_mymc pipeline.
 */
class SavePreviewView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {
    private val web = WebView(context)
    private val handler = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var pending: String? = null
    private var currentPayload: String? = null
    private var payloadGeneration = 0L
    private var rotationEnabled = true
    private var iconAnimationEnabled = false
    private var iconAnimationPlaying = true
    private var compactMode = false
    private var interactive = false
    private var touchX = 0f
    private var dragged = false
    private var rendererSuspended = false
    private var recoveryAttempts = 0
    private var reloadAttempts = 0
    private var verificationToken = 0L
    private var renderConfirmed = false
    private var onRenderReady: (() -> Unit)? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (url?.startsWith("file:///android_asset/") != true) return
                pageReady = true
                renderConfirmed = false
                if (rendererSuspended) {
                    web.evaluateJavascript("window.suspendRenderer();", null)
                    return
                }
                applyDisplayMode()
                (pending ?: currentPayload)?.let { payload ->
                    pending = null
                    val generation = payloadGeneration
                    handler.postDelayed({ applyPayload(payload, generation) }, 60L)
                }
            }
        }
        web.webChromeClient = WebChromeClient()
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = false
            allowFileAccess = true
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        web.setOnTouchListener { _, event ->
            if (!interactive) {
                if (event.action == MotionEvent.ACTION_UP) performClick()
                return@setOnTouchListener false
            }
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touchX = event.x
                    dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.x - touchX
                    if (kotlin.math.abs(delta) > 2f) dragged = true
                    touchX = event.x
                    if (pageReady) web.evaluateJavascript("window.rotateBy(${delta * 0.7f});", null)
                }
                MotionEvent.ACTION_UP -> if (!dragged) performClick()
            }
            true
        }
        addView(web, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        web.loadUrl("file:///android_asset/ps2icon_preview.html")
    }

    fun setSave(title: String?, serial: String?, region: String?) {
        // Metadata is displayed in the details panel, not over the 3D model.
    }

    fun setPayload(json: String) {
        if (
            currentPayload == json && renderConfirmed && pageReady &&
            !rendererSuspended
        ) return
        if (currentPayload != json) {
            payloadGeneration++
            currentPayload = json
            renderConfirmed = false
            recoveryAttempts = 0
            reloadAttempts = 0
            verificationToken++
        }
        val generation = payloadGeneration
        handler.post {
            if (generation != payloadGeneration || currentPayload != json) return@post
            if (!pageReady) { pending = json; return@post }
            applyPayload(json, generation)
        }
    }

    private fun applyPayload(json: String, generation: Long) {
        if (
            rendererSuspended || !pageReady || generation != payloadGeneration ||
            currentPayload != json
        ) {
            pending = json
            return
        }
        renderConfirmed = false
        // JSON is serialized as a JS string; no raw save bytes are inserted into source code.
        val js = "window.setIconPayload(${quote(json)});"
        web.evaluateJavascript(js) {
            scheduleRenderVerification(json, generation)
        }
    }

    private fun scheduleRenderVerification(
        json: String,
        generation: Long,
        delayMs: Long = 180L
    ) {
        val token = ++verificationToken
        handler.postDelayed({
            if (
                token != verificationToken || rendererSuspended || !pageReady ||
                generation != payloadGeneration || currentPayload != json
            ) return@postDelayed
            web.evaluateJavascript(
                "window.isRendererReady ? window.isRendererReady() : false"
            ) { result ->
                if (
                    token != verificationToken || generation != payloadGeneration ||
                    currentPayload != json
                ) return@evaluateJavascript
                if (result?.trim()?.equals("true", ignoreCase = true) == true) {
                    renderConfirmed = true
                    recoveryAttempts = 0
                    onRenderReady?.invoke()
                    return@evaluateJavascript
                }
                recoverRenderer(json, generation)
            }
        }, delayMs)
    }

    private fun recoverRenderer(json: String, generation: Long) {
        if (rendererSuspended || generation != payloadGeneration || currentPayload != json) return
        if (recoveryAttempts < 2) {
            recoveryAttempts++
            web.evaluateJavascript(
                "window.recoverRenderer ? window.recoverRenderer() : false"
            ) {
                scheduleRenderVerification(json, generation, 160L)
            }
            return
        }
        if (reloadAttempts < 1) {
            reloadAttempts++
            recoveryAttempts = 0
            pageReady = false
            pending = json
            web.reload()
        }
    }

    fun setRotationEnabled(enabled: Boolean) {
        if (rotationEnabled == enabled) return
        rotationEnabled = enabled
        if (pageReady) web.evaluateJavascript("window.setRotationEnabled(${enabled});", null)
    }

    fun setIconAnimationEnabled(enabled: Boolean) {
        if (iconAnimationEnabled == enabled) return
        iconAnimationEnabled = enabled
        if (pageReady) {
            web.evaluateJavascript("window.setIconAnimationEnabled(${enabled});", null)
        }
    }

    fun setIconAnimationPlaying(playing: Boolean) {
        if (iconAnimationPlaying == playing) return
        iconAnimationPlaying = playing
        if (pageReady) {
            web.evaluateJavascript("window.setIconAnimationPlaying(${playing});", null)
        }
    }

    fun queryIconAnimationAvailability(callback: (Boolean) -> Unit) {
        if (!pageReady || !renderConfirmed) {
            callback(false)
            return
        }
        web.evaluateJavascript(
            "window.hasIconAnimation ? window.hasIconAnimation() : false"
        ) { result ->
            callback(result?.trim()?.equals("true", ignoreCase = true) == true)
        }
    }

    fun setCompactMode(compact: Boolean) {
        if (compactMode == compact) return
        compactMode = compact
        if (pageReady) applyDisplayMode()
    }

    fun setInteractive(enabled: Boolean) {
        interactive = enabled
    }

    fun setOnRenderReadyListener(listener: (() -> Unit)?) {
        onRenderReady = listener
        if (listener != null && renderConfirmed) listener()
    }

    fun setRotationSpeed(value: Float) {
        if (pageReady) web.evaluateJavascript("window.setRotationSpeed($value);", null)
        else handler.postDelayed({ if (pageReady) setRotationSpeed(value) }, 120L)
    }

    fun suspendRenderer() {
        if (rendererSuspended) return
        rendererSuspended = true
        renderConfirmed = false
        verificationToken++
        pending = currentPayload
        if (pageReady) web.evaluateJavascript("window.suspendRenderer();", null)
        web.onPause()
    }

    fun resumeRenderer() {
        if (!rendererSuspended) return
        rendererSuspended = false
        pending = currentPayload
        web.onResume()
        if (pageReady) {
            val payload = currentPayload
            val generation = payloadGeneration
            web.evaluateJavascript("window.resumeRenderer();") {
                applyDisplayMode()
                if (payload != null) {
                    scheduleRenderVerification(payload, generation, 160L)
                }
            }
        }
    }

    private fun applyDisplayMode() {
        web.evaluateJavascript(
            "window.setCompactMode(${compactMode});" +
                "window.setRotationEnabled(${rotationEnabled});" +
                "window.setIconAnimationEnabled(${iconAnimationEnabled});" +
                "window.setIconAnimationPlaying(${iconAnimationPlaying});",
            null
        )
    }

    fun clearSave() {
        val generation = ++payloadGeneration
        verificationToken++
        pending = null
        currentPayload = null
        renderConfirmed = false
        handler.post {
            if (generation == payloadGeneration && currentPayload == null && pageReady) {
                web.evaluateJavascript("window.clearIcon();", null)
            }
        }
    }

    private fun quote(value: String): String = org.json.JSONObject.quote(value)

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (rendererSuspended) return
        if (pageReady && rotationEnabled) {
            web.evaluateJavascript("window.setRotationEnabled(true);", null)
        }
        val payload = currentPayload
        val generation = payloadGeneration
        if (payload != null && pageReady) {
            scheduleRenderVerification(payload, generation, 120L)
        }
    }

    override fun onDetachedFromWindow() {
        verificationToken++
        renderConfirmed = false
        if (!rendererSuspended && pageReady && rotationEnabled) {
            web.evaluateJavascript("window.setRotationEnabled(false);", null)
        }
        super.onDetachedFromWindow()
        // Keep the single shared WebView alive while it moves between selected rows.
    }
}

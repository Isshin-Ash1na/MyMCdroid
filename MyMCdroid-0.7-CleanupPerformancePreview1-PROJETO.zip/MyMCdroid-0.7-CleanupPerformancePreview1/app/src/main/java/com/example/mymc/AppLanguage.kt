package com.example.mymc

import android.content.Context
import android.content.res.Configuration
import android.os.LocaleList
import java.util.Locale

object AppLanguage {
    const val PORTUGUESE_BRAZIL = "pt-BR"
    const val ENGLISH_US = "en-US"

    private const val PREFERENCES = "mymcdroid_preferences"
    private const val LANGUAGE_KEY = "interface_language"

    fun current(context: Context): String =
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .getString(LANGUAGE_KEY, PORTUGUESE_BRAZIL)
            ?: PORTUGUESE_BRAZIL

    fun set(context: Context, languageTag: String) {
        val supported = if (languageTag == ENGLISH_US) ENGLISH_US else PORTUGUESE_BRAZIL
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .edit()
            .putString(LANGUAGE_KEY, supported)
            .apply()
    }

    fun wrap(context: Context): Context {
        val locale = Locale.forLanguageTag(current(context))
        Locale.setDefault(locale)
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        configuration.setLocales(LocaleList(locale))
        return context.createConfigurationContext(configuration)
    }
}

package com.example.mymc

import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast

object MyMCToast {
    fun show(context: Context, title: String, message: String? = null, long: Boolean = false) {
        val view = LayoutInflater.from(context).inflate(R.layout.toast_mymc, null)
        view.findViewById<TextView>(R.id.toastTitle).text = title
        val messageView = view.findViewById<TextView>(R.id.toastMessage)
        if (message.isNullOrBlank()) {
            messageView.visibility = View.GONE
        } else {
            messageView.text = message
            messageView.visibility = View.VISIBLE
        }
        view.alpha = 0f
        view.animate().alpha(1f).setDuration(180).start()

        @Suppress("DEPRECATION")
        Toast(context.applicationContext).apply {
            duration = if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
            setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL, 0, 72)
            this.view = view
            show()
        }
    }
}

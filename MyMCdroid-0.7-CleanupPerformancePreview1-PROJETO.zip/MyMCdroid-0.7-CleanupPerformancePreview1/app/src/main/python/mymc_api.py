from pathlib import Path
import json
import hashlib
import re
from mymc_core import open_card
from mymc_export import export_psu, export_any, find_save, unpack_save_files
from ps2_writer import WritableCard

_METADATA_FILE = Path.home() / "mymc_save_metadata.json"
_SERIAL_PATTERN = re.compile(
    r"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|"
    r"SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPH|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}",
    re.I,
)
_SERIAL_BYTES_PATTERN = re.compile(
    rb"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|"
    rb"SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPH|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}",
    re.I,
)


def _metadata_signature(card, save, entries=None):
    """Stable signature for a save independent of its memory-card position/name."""
    h = hashlib.sha256()
    entries = entries if entries is not None else card.save_files(save)
    for entry in sorted(entries, key=lambda x: x["name"].lower()):
        name = entry["name"]
        data = card.extract_file(entry["first_cluster"], entry["size"])
        h.update(name.encode("utf-8", "replace"))
        h.update(b"\0")
        h.update(data)
        h.update(b"\0")
    return h.hexdigest()


def _load_metadata_cache():
    try:
        if _METADATA_FILE.exists():
            obj = json.loads(_METADATA_FILE.read_text(encoding="utf-8"))
            return obj if isinstance(obj, dict) else {}
    except Exception:
        pass
    return {}


def _save_metadata_cache(cache):
    try:
        _METADATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = _METADATA_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        tmp.replace(_METADATA_FILE)
    except Exception:
        pass


def _remember_metadata(card, save, title, serial, region, flag):
    if not serial:
        return
    cache = _load_metadata_cache()
    cache[_metadata_signature(card, save)] = {
        "title": title or save.name,
        "serial": serial,
        "region": region,
        "flag": flag,
    }
    _save_metadata_cache(cache)


def _serial_from_files(card, save, entries=None):
    """Find a PS2 serial in save entry names or textual file data."""
    entries = entries if entries is not None else card.save_files(save)
    for entry in entries:
        match = _SERIAL_PATTERN.search(entry["name"])
        if match:
            serial = _normalize_serial(match.group(0))
            if serial:
                return serial
        # Serial IDs are normally present in a small metadata/header file.
        # Limit scanning to the first 64 KiB of each file to avoid expensive
        # scans through large game-specific save blobs.
        try:
            data = card.extract_file(entry["first_cluster"], min(entry["size"], 65536))
            match = _SERIAL_BYTES_PATTERN.search(data)
            if match:
                serial = _normalize_serial(match.group(0).decode("ascii", "ignore"))
                if serial:
                    return serial
        except Exception:
            pass
    return ""


def _serial_from_imported_files(files):
    """Find a serial before writing a container into a folder card."""
    for item in files:
        candidates = [getattr(item, "name", "")]
        try:
            candidates.append(bytes(item.data[:65536]).decode("latin1", "ignore"))
        except Exception:
            pass
        for candidate in candidates:
            match = _SERIAL_PATTERN.search(candidate)
            if match:
                serial = _normalize_serial(match.group(0))
                if serial:
                    return serial
    return ""

def _decode_icon_title(data):
    """Extract the two title lines from a PS2 icon.sys file.

    icon.sys stores a title split at the byte offset in the header.  The
    original mymc implementation treats the two parts separately; doing the
    same avoids decoding the padding/binary fields as part of the title.
    """
    import struct

    if len(data) < 964:
        return None
    try:
        fmt = (
            "<4s2xH4xL"
            "16s16s16s16s16s16s16s16s16s16s16s"
            "68s64s64s64s512x"
        )
        fields = list(struct.unpack(fmt, data[:964]))
        offset = int(fields[1])
        title_raw = fields[14]

        def decode(raw):
            raw = raw.split(b"\x00", 1)[0]
            return raw.decode("shift_jis", "replace").strip()

        # The offset is a byte offset into the 512-byte title field.
        if 0 < offset < len(title_raw):
            first = decode(title_raw[:offset])
            second = decode(title_raw[offset:])
            title = " ".join(x for x in (first, second) if x).strip()
        else:
            title = decode(title_raw)

        # Some saves contain embedded line/control separators.  Never expose
        # literal escape sequences in the Android list.
        title = title.replace("\\n", " ").replace("\r", " ").replace("\n", " ")
        title = " ".join(title.split())
        return title or None
    except Exception:
        return None


def _normalize_serial(serial):
    """Normalize container-specific PS2 serial prefixes to the game serial.

    SharkPort/X-Port and CodeBreaker commonly store a region prefix such as
    BASLUS/BISLPM.  The leading B is a container/database marker; the
    consumer-facing game serial is SLUS/SLPM/etc.
    """
    s = (serial or "").upper().strip()
    m = _SERIAL_PATTERN.search(s)
    if not m:
        return ""
    token = m.group(0)
    prefix, number = token.split("-", 1)
    aliases = {
        "BASLUS": "SLUS", "BASCUS": "SCUS",
        "BESLES": "SLES", "BESCES": "SCES",
        "BISLPS": "SLPS", "BISLPM": "SLPM",
        "BISCPH": "SCPH", "BISCPS": "SCPS",
    }
    prefix = aliases.get(prefix, prefix)
    return f"{prefix}-{number}"


def _folder_card_host_name(save_name, serial):
    """Build a host directory name which survives PCSX2/ARMSX2 filtering.

    Folder cards filter their physical top-level directories for the running
    game's serial before reading ``_pcsx2_meta_directory``. Some containers
    legitimately use a friendly logical directory name, so keep that name in
    metadata while prefixing only the host directory with a searchable serial.
    """
    normalized = _normalize_serial(serial)
    if not normalized:
        return save_name
    prefix, number = normalized.split("-", 1)
    aliases = {
        "SLUS": "BASLUS", "SCUS": "BASCUS",
        "SLES": "BESLES", "SCES": "BESCES",
        "SLPS": "BISLPS", "SLPM": "BISLPM",
        "SCPH": "BISCPH", "SCPS": "BISCPS",
    }
    filter_name = f"{aliases.get(prefix, prefix)}-{number}"
    if filter_name in (save_name or "").upper():
        return save_name
    return f"{filter_name}__{save_name}"


def _extract_serial(save_name, game_title=None, container_serial=None):
    """Extract and normalize a PS2 game serial.

    Prefer a serial embedded in the source container (MAX/CBS/SPS/XPS),
    then a serial in the imported save directory name, then known title
    fallbacks.  This is important for GameShark/CodeBreaker saves whose
    directory name can be a friendly label rather than a serial.
    """
    for candidate in (container_serial, save_name):
        s = (candidate or "").upper()
        m = _SERIAL_PATTERN.search(s)
        if m:
            normalized = _normalize_serial(m.group(0))
            if normalized:
                return normalized

    t = re.sub(r"[^A-Z0-9]+", "", (game_title or save_name or "").upper())
    known = {
        "ONIMUSHA3": "SLUS-20694",
        "ONIMUSHA3DEMONSIEGE": "SLUS-20694",
    }
    return known.get(t, "")


def _serial_from_container(path):
    """Find a serial embedded in a save-container header.

    The supported container formats keep the game ID in plain ASCII.  We
    scan only the header/metadata area first, avoiding false matches inside
    arbitrary save data.
    """
    ext = Path(path).suffix.lower()
    if ext in (".sps", ".xps"):
        header_size = 8192
    else:
        header_size = 4096
    with Path(path).open("rb") as source:
        header = source.read(header_size)
    for match in _SERIAL_BYTES_PATTERN.finditer(header):
        raw_serial = match.group(0)
        serial = _normalize_serial(raw_serial.decode("ascii", "ignore"))
        if serial:
            return serial
    return ""


def _region_info(serial):
    s = (serial or "").upper()
    if s.startswith(("BASLUS-", "BASCUS-", "SCUS-", "SLUS-")):
        return "NTSC-U", "🇺🇸"
    if s.startswith(("BESLES-", "BESCES-", "SLES-", "SLED-", "SCES-", "SCED-", "PBPX-")):
        return "PAL", "🇪🇺"
    if s.startswith(("BISLPS-", "BISLPM-", "BISCPH-", "SLPS-", "SLPM-", "SCPH-", "SCPS-")):
        return "NTSC-J", "🇯🇵"
    return "Desconhecida", "🌐"


def save_metadata(card, save, metadata_cache=None):
    title = None
    entries = card.save_files(save)
    for entry in entries:
        if entry["name"].lower() == "icon.sys":
            data = card.extract_file(entry["first_cluster"], entry["size"])
            title = _decode_icon_title(data)
            break

    serial = _extract_serial(save.name, title)
    if not serial:
        serial = _serial_from_files(card, save, entries)
    cached = {}
    if not serial or not title or title == save.name:
        cache = metadata_cache if metadata_cache is not None else _load_metadata_cache()
        cached = cache.get(_metadata_signature(card, save, entries), {})
    if not serial:
        serial = cached.get("serial", "")
    region, flag = _region_info(serial)
    if not serial and cached.get("region"):
        region, flag = cached.get("region", "Desconhecida"), cached.get("flag", "🌐")
    if cached.get("title") and (not title or title == save.name):
        title = cached.get("title")
    return {
        "name": save.name,
        "title": title or save.name,
        "serial": serial,
        "region": region,
        "flag": flag,
        "size": save.size,
        "size_bytes": sum(e["size"] for e in entries if not e.get("is_directory")),
        "first_cluster": save.first_cluster,
    }


def _card_stats_obj(card):
    if getattr(card, "is_folder_card", False):
        return card.stats()
    free_clusters = 0
    for index in range(card.alloc_end):
        if (card.lookup_fat(index) & 0x80000000) == 0:
            free_clusters += 1
    free_bytes = free_clusters * card.cluster_size
    total_bytes = card.alloc_end * card.cluster_size
    used_bytes = max(0, total_bytes - free_bytes)
    return {
        "free_bytes": free_bytes,
        "used_bytes": used_bytes,
        "total_bytes": total_bytes,
        "free_percent": round((free_bytes * 100.0 / total_bytes), 1) if total_bytes else 0.0,
    }

def card_stats(card_path):
    """Return reliable free-space information from the PS2 FAT."""
    return json.dumps(_card_stats_obj(open_card(card_path)), ensure_ascii=False)

def list_saves(card_path):
    card = open_card(card_path)
    metadata_cache = _load_metadata_cache()
    return json.dumps(
        [save_metadata(card, s, metadata_cache) for s in card.saves()],
        ensure_ascii=False
    )

def card_snapshot(card_path):
    """List saves and space from one buffered card load after a mutation."""
    card = open_card(card_path)
    metadata_cache = _load_metadata_cache()
    return json.dumps({
        "saves": [save_metadata(card, s, metadata_cache) for s in card.saves()],
        "stats": _card_stats_obj(card),
    }, ensure_ascii=False)

def export_save(card_path, save_name, destination):
    card = open_card(card_path)
    save = find_save(card, save_name)
    count, size = export_psu(card, save, destination)
    return json.dumps({"save": save_name, "files": count, "bytes": size}, ensure_ascii=False)

def export_save_any(card_path, save_name, destination, format_name):
    card = open_card(card_path)
    save = find_save(card, save_name)
    count, size = export_any(card, save, destination, format_name)
    return json.dumps({"save": save_name, "format": format_name, "files": count, "bytes": size}, ensure_ascii=False)


def export_save_folder(card_path, save_name, destination):
    """Export one Game Save as a PCSX2/ARMSX2-compatible directory."""
    from folder_card import write_folder_save
    from save_formats import ImportedFile, ImportedSave

    card = open_card(card_path)
    save = find_save(card, save_name)
    root_entry = next(
        (entry for entry in card.root_entries() if entry[8] == save.name), None
    )
    files = [
        ImportedFile(entry[8], data, entry[0], entry[3], entry[6], entry[7])
        for entry, data in unpack_save_files(card, save)
    ]
    imported = ImportedSave(
        save.name,
        files,
        root_entry[0] if root_entry else 0x8427,
        root_entry[3] if root_entry else None,
        root_entry[6] if root_entry else None,
        root_entry[7] if root_entry else 0,
    )
    metadata = save_metadata(card, save)
    serial = metadata.get("serial") or _extract_serial(
        save.name, metadata.get("title")
    )
    folder_name = _folder_card_host_name(save.name, serial)
    count = write_folder_save(
        destination,
        files,
        save.name,
        save_metadata=imported,
        host_directory_name=folder_name,
    )
    return json.dumps({
        "save": save.name,
        "format": "folder",
        "folder_name": folder_name,
        "files": count,
    }, ensure_ascii=False)

def delete_save(card_path, save_name, destination):
    """Delete one save from a card image and write the result to destination."""
    if Path(card_path).is_dir():
        from folder_card import FolderCardWriter
        return FolderCardWriter(card_path, destination).delete_save(save_name)
    return WritableCard(card_path, destination).delete_save(save_name)

def delete_saves(card_path, save_names_json, destination):
    """Delete selected saves in one working-card transaction."""
    names = json.loads(save_names_json)
    if Path(card_path).is_dir():
        from folder_card import FolderCardWriter
        removed = FolderCardWriter(card_path, destination).delete_saves(names)
    else:
        removed = WritableCard(card_path, destination).delete_saves(names)
    return json.dumps({"removed": removed, "count": len(removed)}, ensure_ascii=False)

def delete_all_saves(card_path, destination):
    """Delete all saves in a working copy and return the removed count."""
    if Path(card_path).is_dir():
        from folder_card import FolderCardWriter
        removed = FolderCardWriter(card_path, destination).delete_all_saves()
    else:
        removed = WritableCard(card_path, destination).delete_all_saves()
    return json.dumps({"removed": removed}, ensure_ascii=False)


def _psu_metadata(psu_path):
    """Read the imported save name and game title from a PSU without changing it."""
    from save_formats import load_any
    imported = load_any(psu_path)
    title = None
    for f in imported.files:
        if f.name.lower() == "icon.sys":
            title = _decode_icon_title(f.data)
            break
    return imported, title or imported.name


def _matching_save_names(card, serial, region, saves=None, metadata_cache=None):
    """Return all existing saves with the same normalized Serial ID + region.

    Directory names are deliberately not used as the identity because saves
    imported from MAX/CBS/SPS/XPS often use different container-specific
    names. Empty/unknown serials never match anything.
    """
    serial = _normalize_serial(serial)
    if not serial or region == "Desconhecida":
        return []
    matches = []
    saves = saves if saves is not None else card.saves()
    metadata_cache = metadata_cache if metadata_cache is not None else _load_metadata_cache()
    for save in saves:
        meta = save_metadata(card, save, metadata_cache)
        if meta.get("serial") == serial and meta.get("region") == region:
            matches.append(save.name)
    return matches


def import_save(card_path, psu_path, destination, save_name=None):
    """Import a PSU, replacing an existing save with the same Serial ID + region."""
    imported, imported_title = _psu_metadata(psu_path)
    target = save_name or imported.name
    serial = _extract_serial(target, imported_title)
    if not serial:
        serial = _serial_from_imported_files(imported.files)
    region, flag = _region_info(serial)
    card = open_card(card_path)
    existing_saves = card.saves()
    matching_names = _matching_save_names(
        card, serial, region, existing_saves, _load_metadata_cache()
    )
    exact_existing = any(s.name == target for s in existing_saves)
    replace_names = sorted(set(matching_names + ([target] if exact_existing else [])))

    folder_card = Path(card_path).is_dir()
    if folder_card:
        from folder_card import FolderCardWriter
        writer = FolderCardWriter(card_path, destination)
    else:
        writer = WritableCard(card_path, destination)
    import_options = {
        "replace_existing": True,
        "replace_names": replace_names,
        "save_metadata": imported,
    }
    if folder_card:
        import_options["host_directory_name"] = _folder_card_host_name(target, serial)
    result = writer.import_files(imported.files, target, **import_options)
    return json.dumps({
        "files": result,
        "overwritten": bool(replace_names),
        "save_name": target,
        "title": imported_title,
        "serial": serial,
        "region": region,
        "flag": flag,
    }, ensure_ascii=False)


def import_save_any(card_path, save_path, destination, save_name=None):
    source_path = Path(save_path)
    if source_path.is_dir():
        from folder_card import load_folder_save
        imported = load_folder_save(source_path)
        container_serial = ""
    else:
        from save_formats import load_any
        imported = load_any(source_path)
        container_serial = _serial_from_container(source_path)
    imported_name, files = imported
    target = save_name or imported_name

    imported_title = None
    for f in files:
        if f.name.lower() == "icon.sys":
            imported_title = _decode_icon_title(f.data)
            break

    serial = _extract_serial(target, imported_title, container_serial)
    if not serial:
        serial = _serial_from_imported_files(files)

    region, flag = _region_info(serial)
    card = open_card(card_path)
    existing_saves = card.saves()
    matching_names = _matching_save_names(
        card, serial, region, existing_saves, _load_metadata_cache()
    )
    exact_existing = any(s.name == target for s in existing_saves)
    replace_names = sorted(set(matching_names + ([target] if exact_existing else [])))

    folder_card = Path(card_path).is_dir()
    if folder_card:
        from folder_card import FolderCardWriter
        writer = FolderCardWriter(card_path, destination)
    else:
        writer = WritableCard(card_path, destination)
    import_options = {
        "replace_existing": True,
        "replace_names": replace_names,
        "save_metadata": imported,
    }
    if folder_card:
        import_options["host_directory_name"] = _folder_card_host_name(target, serial)
    result = writer.import_files(files, target, **import_options)
    overwritten = bool(replace_names)

    # Persist metadata against the newly-created entry so it remains available
    # even when its directory name is a friendly label without a serial.
    if serial:
        out_card = open_card(destination)
        new_save = next((s for s in out_card.saves() if s.name == target), None)
        if new_save is not None:
            _remember_metadata(
                out_card, new_save, imported_title or target,
                serial, region, flag
            )

    return json.dumps({
        "files": result, "overwritten": overwritten, "save_name": target,
        "title": imported_title or target, "serial": serial,
        "region": region, "flag": flag
    }, ensure_ascii=False)


def transfer_saves(source_card_path, destination_card_path, save_names_json, destination):
    """Copy selected saves directly between two open cards in one transaction.

    The destination card is never edited in place. Metadata, timestamps and the
    Serial ID + region overwrite rule are preserved for both image and folder
    Memory Cards.
    """
    from save_formats import ImportedFile, ImportedSave

    names = list(dict.fromkeys(json.loads(save_names_json)))
    if not names:
        raise ValueError("Nenhum Game Save selecionado")

    source = open_card(source_card_path)
    destination_is_folder = Path(destination_card_path).is_dir()
    if destination_is_folder:
        from folder_card import FolderCardWriter
        writer = FolderCardWriter(destination_card_path, destination)
    else:
        writer = WritableCard(destination_card_path, destination)

    transferred = []
    overwritten = []
    source_metadata_cache = _load_metadata_cache()
    for index, name in enumerate(names):
        save = find_save(source, name)
        root_entry = next(
            (entry for entry in source.root_entries() if entry[8] == save.name),
            None,
        )
        files = [
            ImportedFile(
                entry[8], data, entry[0], entry[3], entry[6], entry[7]
            )
            for entry, data in unpack_save_files(source, save)
        ]
        imported = ImportedSave(
            save.name,
            files,
            root_entry[0] if root_entry else 0x8427,
            root_entry[3] if root_entry else None,
            root_entry[6] if root_entry else None,
            root_entry[7] if root_entry else 0,
        )
        source_meta = save_metadata(source, save, source_metadata_cache)
        title = source_meta.get("title") or save.name
        serial = source_meta.get("serial") or _extract_serial(save.name, title)
        region = source_meta.get("region") or _region_info(serial)[0]
        flag = source_meta.get("flag") or _region_info(serial)[1]

        current_path = destination_card_path if index == 0 else destination
        current = open_card(current_path)
        current_saves = current.saves()
        matching_names = _matching_save_names(
            current, serial, region, current_saves, _load_metadata_cache()
        )
        exact_existing = any(item.name == save.name for item in current_saves)
        replace_names = sorted(set(
            matching_names + ([save.name] if exact_existing else [])
        ))
        options = {
            "replace_existing": True,
            "replace_names": replace_names,
            "save_metadata": imported,
        }
        if destination_is_folder:
            options["host_directory_name"] = _folder_card_host_name(save.name, serial)
        writer.import_files(files, save.name, **options)

        output = open_card(destination)
        copied = next((item for item in output.saves() if item.name == save.name), None)
        if copied is not None and serial:
            _remember_metadata(output, copied, title, serial, region, flag)
        transferred.append(save.name)
        if replace_names:
            overwritten.append(save.name)

    return json.dumps({
        "count": len(transferred),
        "transferred": transferred,
        "overwritten": overwritten,
    }, ensure_ascii=False)


def list_save_files(card_path, save_name):
    """List regular files stored inside one Game Save directory."""
    card = open_card(card_path)
    save = find_save(card, save_name)
    files = [
        {
            "name": entry["name"],
            "size": entry["size"],
            "mode": entry.get("mode", 0),
        }
        for entry in card.save_files(save)
        if not entry.get("is_directory")
    ]
    files.sort(key=lambda item: item["name"].casefold())
    return json.dumps(files, ensure_ascii=False)


def read_save_file(card_path, save_name, file_name):
    """Return the exact bytes of one selected file inside a Game Save."""
    card = open_card(card_path)
    save = find_save(card, save_name)
    wanted = file_name.casefold()
    entry = next(
        (
            item for item in card.save_files(save)
            if not item.get("is_directory") and item["name"].casefold() == wanted
        ),
        None,
    )
    if entry is None:
        raise FileNotFoundError(file_name)
    return card.extract_file(entry["first_cluster"], entry["size"])


def replace_save_file(card_path, save_name, file_name, replacement_path, destination):
    """Replace one file while preserving the rest of the Game Save metadata."""
    from save_formats import ImportedFile, ImportedSave

    card = open_card(card_path)
    save = find_save(card, save_name)
    wanted = file_name.casefold()
    replacement = Path(replacement_path).read_bytes()
    replaced = False
    files = []
    for entry, data in unpack_save_files(card, save):
        if entry[8].casefold() == wanted:
            data = replacement
            replaced = True
        files.append(ImportedFile(
            entry[8], data, entry[0], entry[3], entry[6], entry[7]
        ))
    if not replaced:
        raise FileNotFoundError(file_name)

    root_entry = next(
        (entry for entry in card.root_entries() if entry[8] == save.name),
        None,
    )
    imported = ImportedSave(
        save.name,
        files,
        root_entry[0] if root_entry else 0x8427,
        root_entry[3] if root_entry else None,
        root_entry[6] if root_entry else None,
        root_entry[7] if root_entry else 0,
    )
    folder_card = Path(card_path).is_dir()
    if folder_card:
        from folder_card import FolderCardWriter
        writer = FolderCardWriter(card_path, destination)
    else:
        writer = WritableCard(card_path, destination)
    options = {
        "replace_existing": True,
        "replace_names": [save.name],
        "save_metadata": imported,
    }
    if folder_card:
        save_path = card.save_path(save.name)
        options["host_directory_name"] = (
            Path(save_path).name if save_path is not None
            else _folder_card_host_name(save.name, "")
        )
    writer.import_files(files, save.name, **options)

    source_meta = save_metadata(card, save)
    output = open_card(destination)
    updated = next((item for item in output.saves() if item.name == save.name), None)
    if updated is not None and source_meta.get("serial"):
        _remember_metadata(
            output,
            updated,
            source_meta.get("title") or save.name,
            source_meta["serial"],
            source_meta.get("region") or _region_info(source_meta["serial"])[0],
            source_meta.get("flag") or _region_info(source_meta["serial"])[1],
        )
    return json.dumps({
        "save_name": save.name,
        "file_name": file_name,
        "size": len(replacement),
    }, ensure_ascii=False)

def create_card(destination, size_mb=8):
    from ps2_formatter import create_memory_card
    size_mb = int(size_mb)
    if size_mb not in (8, 16, 32, 64):
        raise ValueError("Tamanho de Memory Card não suportado")
    return create_memory_card(destination, pages_per_card=16384 * (size_mb // 8))


def create_folder_card(destination):
    from folder_card import create_folder_card as create
    return create(destination, 8)


def card_kind(card_path):
    return "folder" if Path(card_path).is_dir() else "file"


def card_state(card_path):
    """Return 'valid', 'blank', or 'invalid' for a PS2 memory-card image."""
    p = Path(card_path)
    if p.is_dir():
        try:
            from folder_card import FolderMemoryCard
            FolderMemoryCard(p)
            return "valid"
        except Exception:
            return "invalid"
    # A PCSX2-created, completely erased image is raw 0xFF. Inspect it in
    # buffered chunks so a normal card isn't loaded fully once here and then
    # loaded a second time by open_card below.
    try:
        size = p.stat().st_size
        erased = size > 0
        full_erased_chunk = b"\xff" * 65536
        with p.open("rb", buffering=65536) as source:
            while erased:
                chunk = source.read(65536)
                if not chunk:
                    break
                if chunk != full_erased_chunk[:len(chunk)]:
                    erased = False
    except OSError:
        return "invalid"
    if erased:
        if size % 528 == 0:
            return "blank"
        return "invalid"
    try:
        card = open_card(card_path)
        # Force a root/FAT read so malformed images are not classified as valid.
        card.root_entries()
        return "valid"
    except Exception:
        return "invalid"


def format_blank_card(source, destination):
    """Format an erased raw image, preserving its original capacity."""
    from pathlib import Path
    from ps2_formatter import create_memory_card
    size = Path(source).stat().st_size
    if size % 528 != 0:
        raise ValueError("Tamanho de imagem não suportado para formatação.")
    pages = size // 528
    if pages < 16384 or pages % 16 != 0:
        raise ValueError("Capacidade da memory card não é compatível com o formato PS2.")
    return create_memory_card(destination, pages_per_card=pages)


def _get_icon_payload_for_card(card, save_name):
    """Return PS2ICON candidates for the selected save.

    The normal/copy/delete icon filenames are defined by ``icon.sys`` and may
    be completely unrelated to ``icon.icn`` (for example ``game.icn``,
    ``slime1.ico`` or ``bio4.ico``).  Resolve those references first, using a
    case-insensitive filename lookup, then fall back to header discovery.
    """
    import base64
    import struct

    save = find_save(card, save_name)
    entries = card.save_files(save)
    file_entries = [e for e in entries if not e.get("is_directory") and e["size"] > 0]
    by_name = {e["name"].casefold(): e for e in file_entries}

    candidates = []
    seen = set()
    icon_sys_refs = []
    diagnostics = []

    def read_entry(entry):
        try:
            return card.extract_file(entry["first_cluster"], entry["size"])
        except Exception as exc:
            diagnostics.append(f'{entry["name"]}: leitura falhou ({exc})')
            return None

    def add_candidate(entry, reason, referenced_as=None):
        key = (entry["first_cluster"], entry["size"])
        if key in seen:
            return
        raw = read_entry(entry)
        if raw is None or len(raw) < 20:
            return
        magic = int.from_bytes(raw[0:4], "little")
        if magic != 0x00010000:
            diagnostics.append(f'{entry["name"]}: cabeçalho 0x{magic:08X} não é PS2ICON')
            return
        seen.add(key)
        candidates.append({
            "file": entry["name"],
            "reason": reason,
            "referenced_as": referenced_as or "",
            "size": entry["size"],
            "icon": base64.b64encode(raw).decode("ascii"),
        })

    # Resolve exact normal/copy/delete icon filenames from icon.sys.
    icon_sys_entry = by_name.get("icon.sys")
    if icon_sys_entry is not None and icon_sys_entry["size"] >= 964:
        raw = read_entry(icon_sys_entry)
        if raw is not None and len(raw) >= 964:
            try:
                fmt = (
                    "<4s2xH4xL"
                    "16s16s16s16s16s16s16s16s16s16s16s"
                    "68s64s64s64s512x"
                )
                fields = struct.unpack(fmt, raw[:964])
                # fields 15, 16 and 17 are normal, copy and delete icons.
                for label, value in zip(("normal", "copy", "delete"), fields[15:18]):
                    name = value.split(b"\0", 1)[0].decode("shift_jis", "replace").strip()
                    if not name:
                        continue
                    icon_sys_refs.append({"role": label, "name": name})
                    entry = by_name.get(name.casefold())
                    if entry is not None:
                        add_candidate(entry, "icon.sys", label)
                    else:
                        diagnostics.append(f'icon.sys refere {label}="{name}", mas o ficheiro não existe')
            except Exception as exc:
                diagnostics.append(f"icon.sys inválido: {exc}")

    # Conventional names next.  This includes uncommon .ico/.icn names even
    # when icon.sys is malformed or missing.
    for entry in file_entries:
        lower = entry["name"].casefold()
        if lower.endswith((".icn", ".ico")) or lower.startswith("icon"):
            add_candidate(entry, "filename")

    # Last fallback: inspect every reasonably sized file for the PS2ICON magic.
    for entry in file_entries:
        if entry["size"] > 2 * 1024 * 1024:
            continue
        key = (entry["first_cluster"], entry["size"])
        if key in seen:
            continue
        try:
            head = card.extract_file(entry["first_cluster"], min(entry["size"], 20))
        except Exception:
            continue
        if len(head) >= 4 and int.from_bytes(head[:4], "little") == 0x00010000:
            add_candidate(entry, "signature")

    if not candidates:
        return json.dumps({
            "ok": False,
            "error": "Nenhum ficheiro PS2ICON válido encontrado no save.",
            "icon_sys_refs": icon_sys_refs,
            "files": [e["name"] for e in file_entries],
            "diagnostics": diagnostics,
        }, ensure_ascii=False)

    return json.dumps({
        "ok": True,
        "candidates": candidates,
        "icon_sys_refs": icon_sys_refs,
        "diagnostics": diagnostics,
        "file": candidates[0]["file"],
        "icon": candidates[0]["icon"],
    }, ensure_ascii=False)


def get_icon_payload(card_path, save_name):
    return _get_icon_payload_for_card(open_card(card_path), save_name)


def get_icon_payloads(card_path, save_names_json):
    """Load multiple row-preview payloads from one Memory Card read."""
    card = open_card(card_path)
    names = json.loads(save_names_json)
    result = {}
    for name in names:
        try:
            result[name] = json.loads(_get_icon_payload_for_card(card, name))
        except Exception as exc:
            result[name] = {"ok": False, "error": str(exc)}
    return json.dumps(result, ensure_ascii=False)

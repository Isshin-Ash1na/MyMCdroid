from __future__ import annotations
import struct
import binascii
import zlib
from pathlib import Path
from mymc_core import open_card

DIRENT_FMT = '<HHL8sLL8sL28x448s'
DIRENT_STRUCT = struct.Struct(DIRENT_FMT)
TOD_STRUCT = struct.Struct('<xBBBBBH')
DF_FILE=0x10; DF_DIR=0x20; DF_EXISTS=0x8000; DF_RWX=0x7; DF_0400=0x400


def pack_dirent(e):
    e=list(e)
    e[3]=TOD_STRUCT.pack(*e[3])
    e[6]=TOD_STRUCT.pack(*e[6])
    name=e[8].encode('shift_jis','replace') if isinstance(e[8],str) else e[8]
    name=name[:447]+b'\0'
    e[8]=name.ljust(448,b'\0')
    return DIRENT_STRUCT.pack(*e)


def unpack_save_files(card, save):
    raw=card.read_file(save.first_cluster, save.size*512)
    out=[]
    for i in range(save.size):
        e=list(DIRENT_STRUCT.unpack(raw[i*512:(i+1)*512]))
        e[3]=TOD_STRUCT.unpack(e[3]); e[6]=TOD_STRUCT.unpack(e[6])
        e[8]=e[8].split(b'\0',1)[0].decode('shift_jis','replace')
        if e[8] in ('.','..') or not e[8]: continue
        if e[0] & DF_FILE and e[0] & DF_EXISTS:
            data=card.read_file(e[4],e[2]) if e[2] else b''
            out.append((e,data))
    return out


def export_psu(card, save, destination):
    files=unpack_save_files(card,save)
    dirent=[DF_RWX|DF_DIR|0x400|DF_EXISTS,0,len(files)+2, (0,0,0,0,0,0),0,0,(0,0,0,0,0,0),0,save.name]
    # Use the original save's timestamp fields when available.
    root=card.root_entries()
    original=None
    for e in root:
        if e[8]==save.name: original=e; break
    if original:
        dirent[0]=original[0]
        dirent[3]=original[3]; dirent[6]=original[6]
        dirent[7]=original[7]
    dot=[DF_RWX|DF_DIR|0x400|DF_EXISTS,0,0,dirent[3],0,0,dirent[3],0,'.']
    dotdot=[DF_RWX|DF_DIR|0x400|DF_EXISTS,0,0,dirent[3],0,0,dirent[3],0,'..']
    with open(destination,'wb') as f:
        f.write(pack_dirent(dirent)); f.write(pack_dirent(dot)); f.write(pack_dirent(dotdot))
        for e,data in files:
            f.write(pack_dirent(e)); f.write(data)
            f.write(b'\0'*((-len(data))%1024))
    return len(files), Path(destination).stat().st_size


def _save_context(card, save):
    files = unpack_save_files(card, save)
    root = next((e for e in card.root_entries() if e[8] == save.name), None)
    timestamp = root[3] if root else (0, 0, 0, 0, 0, 0)
    modified = root[6] if root else timestamp
    mode = root[0] if root else (DF_RWX | DF_DIR | DF_0400 | DF_EXISTS)
    return files, timestamp, modified, mode


def _fixed_name(value, length):
    raw = value.encode('shift_jis', 'replace') if isinstance(value, str) else value
    return raw[:length - 1].ljust(length, b'\0')


def export_max(card, save, destination):
    """Write a standards-compatible uncompressed MAX Drive container."""
    files, _created, _modified, _mode = _save_context(card, save)
    body = bytearray()
    for entry, data in files:
        body += struct.pack('<L32s', len(data), _fixed_name(entry[8], 32))
        body += data
        body += b'\0' * ((-((len(body) + 8))) % 16)
    dirname = _fixed_name(save.name, 32)
    icon_title = dirname
    header = struct.pack(
        '<12sL32s32sLLL', b'Ps2PowerSave', 0, dirname, icon_title,
        len(body), len(files), len(body)
    )
    crc = binascii.crc32(header)
    crc = binascii.crc32(body, crc) & 0xffffffff
    header = struct.pack(
        '<12sL32s32sLLL', b'Ps2PowerSave', crc, dirname, icon_title,
        len(body), len(files), len(body)
    )
    Path(destination).write_bytes(header + body)
    return len(files), Path(destination).stat().st_size


def export_sps(card, save, destination):
    files, created, modified, mode = _save_context(card, save)
    dirname = save.name.encode('shift_jis', 'replace')
    def long_string(value):
        return struct.pack('<L', len(value)) + value
    def swapped(value):
        return ((value & 0xff) << 8) | ((value >> 8) & 0xff)
    body = bytearray()
    body += struct.pack(
        '<H64sL8xH2x8s8s', 98, _fixed_name(save.name, 64),
        len(files) + 2, swapped(mode), TOD_STRUCT.pack(*created), TOD_STRUCT.pack(*modified)
    )
    for entry, data in files:
        body += struct.pack(
            '<H64sL8xH2x8s8s', 98, _fixed_name(entry[8], 64), len(data),
            swapped(entry[0]), TOD_STRUCT.pack(*entry[3]), TOD_STRUCT.pack(*entry[6])
        )
        body += data
    prefix = b'\x0d\0\0\0SharkPortSave' + struct.pack('<L', 2)
    prefix += long_string(dirname) + long_string(b'') + long_string(b'')
    prefix += struct.pack('<L', len(body))
    Path(destination).write_bytes(prefix + body + b'\0\0\0\0')
    return len(files), Path(destination).stat().st_size


def export_cbs(card, save, destination):
    from save_formats import _rc4_cbs
    files, created, modified, mode = _save_context(card, save)
    body = bytearray()
    for entry, data in files:
        body += struct.pack(
            '<8s8sLHHLL32s', TOD_STRUCT.pack(*entry[3]), TOD_STRUCT.pack(*entry[6]),
            len(data), entry[0], 0, 0, 0, _fixed_name(entry[8], 32)
        )
        body += data
    compressed = zlib.compress(bytes(body), 9)
    encrypted = _rc4_cbs(compressed)
    title = _fixed_name(save.name, 32)
    hlen = 124
    header = b'CFU\0' + struct.pack('<LL', 0, hlen)
    header += struct.pack(
        '<LL32s8s8sLLLLLL', len(body), len(encrypted), _fixed_name(save.name, 32),
        TOD_STRUCT.pack(*created), TOD_STRUCT.pack(*modified), 0, 0, mode, 0, 0, 0
    ) + title
    Path(destination).write_bytes(header + encrypted)
    return len(files), Path(destination).stat().st_size


def export_any(card, save, destination, format_name):
    fmt = format_name.lower().lstrip('.')
    if fmt == 'psu':
        return export_psu(card, save, destination)
    if fmt == 'max':
        return export_max(card, save, destination)
    if fmt in ('sps', 'xps'):
        return export_sps(card, save, destination)
    if fmt == 'cbs':
        return export_cbs(card, save, destination)
    raise ValueError('Formato de exportação não suportado')


def find_save(card,name):
    for s in card.saves():
        if s.name==name: return s
    raise KeyError(name)

"""Create standard PS2 memory-card images."""
from __future__ import annotations
import struct
import time
from pathlib import Path
from ps2_ecc import ecc_calculate_page

MAGIC = b"Sony PS2 Memory Card Format "
SUPER_FMT = "<28s12sHHHHLLLLLL8x128s128sbb"
SUPER_STRUCT = struct.Struct(SUPER_FMT)
PAGE_SIZE = 512
PAGES_PER_CLUSTER = 2
PAGES_PER_ERASE_BLOCK = 16
PAGES_PER_CARD = 16384
CLUSTER_SIZE = PAGE_SIZE * PAGES_PER_CLUSTER
EPC = CLUSTER_SIZE // 4
MAX_IFC = 32
INDIRECT_FAT_OFFSET = 0x2000

def _pack_page(data: bytes) -> bytes:
    ecc = ecc_calculate_page(data)
    spare = ecc + b"\0" * (16 - len(ecc))
    return data + spare

def _ps2_tod_bytes() -> bytes:
    """PS2 directory timestamps always use Japan time (UTC+9)."""
    value = time.gmtime(time.time() + 9 * 60 * 60)
    return struct.pack(
        "<xBBBBBH", value.tm_sec, value.tm_min, value.tm_hour,
        value.tm_mday, value.tm_mon, value.tm_year
    )

def create_memory_card(destination: str, pages_per_card: int = PAGES_PER_CARD) -> str:
    page_size = PAGE_SIZE
    pages_per_cluster = PAGES_PER_CLUSTER
    pe = PAGES_PER_ERASE_BLOCK
    pages = (pages_per_card // pe) * pe
    clusters = pages // pages_per_cluster
    first_ifc = (INDIRECT_FAT_OFFSET + CLUSTER_SIZE - 1) // CLUSTER_SIZE
    fat_clusters = (clusters - (first_ifc + 2) + EPC - 1) // EPC
    ifc_clusters = (fat_clusters + EPC - 1) // EPC
    alloc_offset = first_ifc + ifc_clusters + fat_clusters
    clusters_per_erase = pe // pages_per_cluster
    erase_blocks = pages // pe
    good_block1 = erase_blocks - 1
    good_block2 = erase_blocks - 2
    alloc_end = good_block2 * clusters_per_erase - alloc_offset
    ifc = [0] * MAX_IFC
    for i in range(ifc_clusters):
        ifc[i] = first_ifc + i
    bad = [0xFFFFFFFF] * 32

    size = pages * (page_size + 16)
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)

    zero_page = _pack_page(b"\0" * page_size)
    with path.open("wb") as f:
        for _ in range(pages):
            f.write(zero_page)

        # Superblock.
        sb = (MAGIC + b"\0" * (28-len(MAGIC)))
        sb += b"1.2.0.0\0\0\0\0\0"
        sb += struct.pack("<HHHHLLLLLL", page_size, pages_per_cluster, pe, 0xFF00,
                          clusters, alloc_offset, alloc_end, 0, good_block1, good_block2)
        sb += b"\0" * 8
        sb += struct.pack("<32I", *ifc)
        sb += struct.pack("<32I", *bad)
        sb += struct.pack("<bb", 2, 0x2B)
        sb += b"\0\0"  # padding required by SUPER_FMT
        sb += b"\0" * (page_size - len(sb))
        f.seek(0)
        f.write(_pack_page(sb))

        # Indirect FAT cluster: pointers to FAT clusters.
        f.seek(first_ifc * CLUSTER_SIZE * (page_size + 16) // page_size)
        ifc_data = struct.pack("<256I", *([first_ifc + ifc_clusters + i for i in range(fat_clusters)] + [0] * (256-fat_clusters)))
        f.write(_pack_page(ifc_data[:512]))
        f.write(_pack_page(ifc_data[512:1024]))

        # FAT clusters.
        for fi in range(fat_clusters):
            base = first_ifc + ifc_clusters + fi * EPC
            entries = []
            for j in range(EPC):
                idx = fi * EPC + j
                if idx == 0:
                    val = 0xFFFFFFFF
                elif idx < alloc_end:
                    val = 0x80000000
                else:
                    val = 0xFFFFFFFF
                entries.append(val)
            data = struct.pack("<256I", *entries)
            phys = base * CLUSTER_SIZE * (page_size + 16) // page_size
            f.seek(phys)
            f.write(_pack_page(data[:512])); f.write(_pack_page(data[512:1024]))

        # Root directory cluster ('.' and '..').
        # Directory entry format matches mymc_core.
        now = _ps2_tod_bytes()
        ent = struct.pack("<HHL8sLL8sL28x448s",
                          0x8427, 0, 2, now, 0, 0, now, 0,
                          b".\0" + b"\0"*446)
        ent2 = struct.pack("<HHL8sLL8sL28x448s",
                           0x8427, 0, 0, now, 0, 0, now, 0,
                           b"..\0" + b"\0"*445)
        data = ent + ent2
        data += b"\0" * (1024-len(data))
        phys = alloc_offset * CLUSTER_SIZE * (page_size + 16) // page_size
        f.seek(phys)
        f.write(_pack_page(data[:512])); f.write(_pack_page(data[512:1024]))

        # Mark the second good erase block as erased.
        phys = good_block2 * pe * (page_size + 16)
        f.seek(phys)
        ff = b"\xff" * (page_size + 16)
        for _ in range(pe):
            f.write(ff)
    return str(path)

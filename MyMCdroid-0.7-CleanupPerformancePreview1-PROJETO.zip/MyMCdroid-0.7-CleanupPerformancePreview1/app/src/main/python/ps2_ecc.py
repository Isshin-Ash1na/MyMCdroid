"""PS2 memory-card Hamming ECC, ported from the original mymc ps2mc_ecc.py."""
from __future__ import annotations

ECC_CHECK_OK = 0
ECC_CHECK_CORRECTED = 1
ECC_CHECK_FAILED = 2


def _popcount(a: int) -> int:
    return a.bit_count()


def _parityb(a: int) -> int:
    a ^= a >> 1
    a ^= a >> 2
    a ^= a >> 4
    return a & 1


def _make_ecc_tables():
    parity_table = [_parityb(b) for b in range(256)]
    cpmasks = [0x55, 0x33, 0x0F, 0x00, 0xAA, 0xCC, 0xF0]
    column_parity_masks = [0] * 256
    for b in range(256):
        mask = 0
        for i, cpm in enumerate(cpmasks):
            mask |= parity_table[b & cpm] << i
        column_parity_masks[b] = mask
    return parity_table, column_parity_masks


_parity_table, _column_parity_masks = _make_ecc_tables()


def ecc_calculate(s: bytes | bytearray | memoryview) -> list[int]:
    if len(s) != 128:
        raise ValueError("PS2 ECC data block must contain exactly 128 bytes")
    column_parity = 0x77
    line_parity_0 = 0x7F
    line_parity_1 = 0x7F
    for i, b in enumerate(s):
        column_parity ^= _column_parity_masks[b]
        if _parity_table[b]:
            line_parity_0 ^= ~i
            line_parity_1 ^= i
    return [column_parity, line_parity_0 & 0x7F, line_parity_1]


def ecc_check(s: bytearray, ecc: bytearray | list[int]) -> int:
    if len(s) != 128 or len(ecc) != 3:
        raise ValueError("ECC check expects 128 bytes of data and 3 ECC bytes")
    computed = ecc_calculate(s)
    if computed == list(ecc):
        return ECC_CHECK_OK

    cp_diff = (computed[0] ^ ecc[0]) & 0x77
    lp0_diff = (computed[1] ^ ecc[1]) & 0x7F
    lp1_diff = (computed[2] ^ ecc[2]) & 0x7F
    lp_comp = lp0_diff ^ lp1_diff
    cp_comp = (cp_diff >> 4) ^ (cp_diff & 0x07)

    if lp_comp == 0x7F and cp_comp == 0x07:
        s[lp1_diff] ^= 1 << (cp_diff >> 4)
        return ECC_CHECK_CORRECTED

    if ((cp_diff == 0 and lp0_diff == 0 and lp1_diff == 0)
            or _popcount(lp_comp) + _popcount(cp_comp) == 1):
        ecc[0], ecc[1], ecc[2] = computed
        return ECC_CHECK_CORRECTED

    return ECC_CHECK_FAILED


def ecc_calculate_page(page: bytes) -> bytes:
    return b"".join(bytes(ecc_calculate(page[i:i + 128]))
                     for i in range(0, len(page), 128))


def ecc_check_page(page: bytearray, spare: bytearray):
    if len(page) % 128:
        raise ValueError("Page length must be a multiple of 128")
    chunks = len(page) // 128
    if len(spare) < chunks * 3:
        raise ValueError("Spare area is too small for ECC")
    corrected = False
    failed = False
    for i in range(chunks):
        data = page[i * 128:(i + 1) * 128]
        ecc = spare[i * 3:i * 3 + 3]
        result = ecc_check(data, ecc)
        if result == ECC_CHECK_CORRECTED:
            corrected = True
            page[i * 128:(i + 1) * 128] = data
            spare[i * 3:i * 3 + 3] = ecc
        elif result == ECC_CHECK_FAILED:
            failed = True
    if failed:
        ret = ECC_CHECK_FAILED
    elif corrected:
        ret = ECC_CHECK_CORRECTED
    else:
        ret = ECC_CHECK_OK
    return ret, page, spare

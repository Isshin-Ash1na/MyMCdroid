from __future__ import annotations

import calendar
import json
import os
import re
import shutil
import tempfile
import time
import uuid
from pathlib import Path

from mymc_core import DIRENT_SIZE, DIRENT_STRUCT, FAT_END, SaveEntry, TOD_STRUCT
from ps2_writer import (
    DF_0400,
    DF_DIR,
    DF_EXISTS,
    DF_FILE,
    DF_RWX,
    ZERO_TOD,
    normalize_mode,
    normalize_tod,
    pack_ent,
    ps2_tod_now,
)

SUPERBLOCK_NAME = "_pcsx2_superblock"
INDEX_NAME = "_pcsx2_index"
DIRECTORY_META_NAME = "_pcsx2_meta_directory"
FILE_META_DIR = "_pcsx2_meta"
CONTROL_PREFIX = "_pcsx2_"
MAGIC = b"Sony PS2 Memory Card Format "
SUPERBLOCK_BLOCK_SIZE = 8192
DEFAULT_DIRECTORY_MODE = DF_RWX | DF_0400 | DF_EXISTS | DF_DIR
DEFAULT_FILE_MODE = DF_RWX | DF_0400 | DF_EXISTS | DF_FILE


def _unpack_ent(raw: bytes):
    entry = list(DIRENT_STRUCT.unpack(raw[:DIRENT_SIZE]))
    entry[3] = TOD_STRUCT.unpack(entry[3])
    entry[6] = TOD_STRUCT.unpack(entry[6])
    entry[8] = entry[8].split(b"\0", 1)[0].decode("shift_jis", "replace")
    return entry


def _epoch_to_tod(value, fallback=None):
    try:
        converted = time.gmtime(int(value))
        return (
            converted.tm_sec,
            converted.tm_min,
            converted.tm_hour,
            converted.tm_mday,
            converted.tm_mon,
            converted.tm_year,
        )
    except (TypeError, ValueError, OverflowError, OSError):
        return fallback or ps2_tod_now()


def _tod_to_epoch(value):
    try:
        second, minute, hour, day, month, year = (int(v) for v in value)
        return calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))
    except (TypeError, ValueError, OverflowError, OSError):
        return int(time.time())


def _decode_yaml_key(value: str):
    value = value.strip()
    if len(value) >= 2 and value[0] in "\"'" and value[-1] == value[0]:
        if value[0] == '"':
            try:
                return json.loads(value)
            except Exception:
                pass
        return value[1:-1]
    return value


def _load_index(path: Path):
    """Read the small YAML subset used by PCSX2 folder Memory Cards.

    PCSX2 has emitted both ``%ROOT`` and ``$ROOT`` over its lifetime, and old
    cards may not contain an index at all.  This parser deliberately accepts
    block and flow-style mappings without adding a YAML dependency to the APK.
    """
    if not path.is_file():
        return {}
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return {}

    # Current PCSX2/ARMSX2 builds emit the complete document as a compact
    # flow-style map on one line. Parse that form before the block parser.
    if text.lstrip().startswith("{"):
        flow = {}
        pattern = re.compile(
            r"(?:^|[,{])\s*(?P<key>\"(?:\\.|[^\"])*\"|'(?:''|[^'])*'|[^{}\s,:]+)"
            r"\s*:\s*\{(?P<body>[^{}]*)\}"
        )
        for match in pattern.finditer(text):
            key = _decode_yaml_key(match.group("key"))
            node = flow.setdefault(key, {})
            for prop, number in re.findall(
                r"(order|timeCreated|timeModified)\s*:\s*(-?\d+)",
                match.group("body"),
            ):
                node[prop] = int(number)
        if flow:
            return flow

    result = {}
    current = None
    for raw_line in text.splitlines():
        if not raw_line.strip() or raw_line.lstrip().startswith("#"):
            continue
        indent = len(raw_line) - len(raw_line.lstrip(" "))
        line = raw_line.strip()
        if indent == 0 and ":" in line:
            key_raw, tail = line.split(":", 1)
            current = _decode_yaml_key(key_raw)
            result.setdefault(current, {})
            for prop, number in re.findall(
                r"(order|timeCreated|timeModified)\s*:\s*(-?\d+)", tail
            ):
                result[current][prop] = int(number)
            continue
        if current is not None:
            match = re.match(r"(order|timeCreated|timeModified)\s*:\s*(-?\d+)", line)
            if match:
                result[current][match.group(1)] = int(match.group(2))

    # Very old cards can use one flow-style map for the entire document.
    if not result:
        for key, body in re.findall(r"([^\s{},:]+)\s*:\s*\{([^{}]*)\}", text):
            node = result.setdefault(_decode_yaml_key(key), {})
            for prop, number in re.findall(
                r"(order|timeCreated|timeModified)\s*:\s*(-?\d+)", body
            ):
                node[prop] = int(number)
    return result


def _write_index(path: Path, root_created, root_modified, files):
    nodes = [
        "$ROOT: {"
        f"timeCreated: {_tod_to_epoch(root_created)},"
        f"timeModified: {_tod_to_epoch(root_modified)}"
        "}"
    ]
    for order, (host_name, created, modified) in enumerate(files, 1):
        key = (
            host_name
            if re.fullmatch(r"[A-Za-z0-9_.-]+", host_name)
            else json.dumps(host_name, ensure_ascii=False)
        )
        nodes.append(
            f"{key}: {{"
            f"order: {order},"
            f"timeCreated: {_tod_to_epoch(created)},"
            f"timeModified: {_tod_to_epoch(modified)}"
            "}"
        )
    path.write_text("{" + ",".join(nodes) + "}\n", encoding="utf-8")


def _ensure_full_superblock(path: Path):
    """Normalize the control file to the complete PCSX2 8 KiB block."""
    raw = path.read_bytes()
    if not raw.startswith(MAGIC):
        raise ValueError("_pcsx2_superblock inválido")
    if len(raw) < SUPERBLOCK_BLOCK_SIZE:
        path.write_bytes(raw + b"\xff" * (SUPERBLOCK_BLOCK_SIZE - len(raw)))
    elif len(raw) > SUPERBLOCK_BLOCK_SIZE:
        path.write_bytes(raw[:SUPERBLOCK_BLOCK_SIZE])


def _clean_host_name(value: str):
    # Keep folder cards portable between Android, Linux, macOS, and Windows.
    clean = "".join("_" if ch in '\\/%:|\"<>?*' else ch for ch in value)
    had_trailing_separator = clean.endswith((" ", "."))
    clean = clean.rstrip(" .")
    if had_trailing_separator:
        clean += "_"
    if clean in ("", ".", ".."):
        raise ValueError("Nome de arquivo inválido no Game Save")
    return clean


def _default_entry(name, size, created, modified, is_directory=False, attr=0):
    mode = DF_RWX | DF_0400 | DF_EXISTS | (DF_DIR if is_directory else DF_FILE)
    return [mode, 0, size, created, FAT_END, 0, modified, attr, name]


def _metadata_is_nonstandard(host_name, logical_name, mode, attr, default_mode):
    """Match PCSX2's rule for optional per-entry metadata files."""
    return host_name != logical_name or mode != default_mode or int(attr or 0) != 0


def load_folder_save(folder, fallback_name=None):
    """Load one PCSX2/ARMSX2 Game Save directory as an import container.

    Current emulator-created saves normally contain only payload files and
    ``_pcsx2_index``. Older or nonstandard saves may additionally carry
    ``_pcsx2_meta_directory`` and ``_pcsx2_meta``; both remain readable.
    """
    from save_formats import ImportedFile, ImportedSave

    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError("O Game Save em pasta não é um diretório")
    if (folder / SUPERBLOCK_NAME).is_file():
        raise ValueError("Selecione a pasta de um Game Save, não o Memory Card inteiro")

    nested = [
        item.name for item in folder.iterdir()
        if item.is_dir() and not item.name.startswith(CONTROL_PREFIX)
    ]
    if nested:
        raise ValueError("O Game Save em pasta contém subpastas não suportadas")

    index = _load_index(folder / INDEX_NAME)
    root_times = index.get("$ROOT", index.get("%ROOT", {}))
    fallback_created = _epoch_to_tod(
        root_times.get("timeCreated", folder.stat().st_ctime)
    )
    fallback_modified = _epoch_to_tod(
        root_times.get("timeModified", folder.stat().st_mtime), fallback_created
    )
    physical_name = fallback_name or folder.name
    fallback_dir = _default_entry(
        physical_name, 2, fallback_created, fallback_modified, True
    )
    directory_entry = fallback_dir
    directory_meta = folder / DIRECTORY_META_NAME
    if directory_meta.is_file():
        try:
            raw = directory_meta.read_bytes()
            if len(raw) >= DIRENT_SIZE:
                directory_entry = _unpack_ent(raw)
        except OSError:
            pass
    logical_name = directory_entry[8] or physical_name

    files_on_disk = [
        item for item in folder.iterdir()
        if item.is_file() and not item.name.startswith(CONTROL_PREFIX)
    ]
    files_on_disk.sort(
        key=lambda item: (
            index.get(item.name, {}).get("order", 1 << 30),
            item.name.casefold(),
        )
    )
    if not files_on_disk:
        raise ValueError("A pasta selecionada não contém arquivos de um Game Save")

    files = []
    for file_path in files_on_disk:
        node = index.get(file_path.name, {})
        created = _epoch_to_tod(
            node.get("timeCreated", file_path.stat().st_ctime), fallback_created
        )
        modified = _epoch_to_tod(
            node.get("timeModified", file_path.stat().st_mtime), created
        )
        entry = _default_entry(
            file_path.name, file_path.stat().st_size, created, modified, False
        )
        metadata_path = folder / FILE_META_DIR / file_path.name
        if metadata_path.is_file():
            try:
                raw = metadata_path.read_bytes()
                if len(raw) >= DIRENT_SIZE:
                    entry = _unpack_ent(raw)
            except OSError:
                pass
        entry[2] = file_path.stat().st_size
        entry[8] = entry[8] or file_path.name
        with file_path.open("rb", buffering=256 * 1024) as stream:
            data = stream.read()
        files.append(ImportedFile(
            entry[8], data, entry[0], entry[3], entry[6], entry[7]
        ))

    return ImportedSave(
        logical_name,
        files,
        directory_entry[0],
        directory_entry[3],
        directory_entry[6],
        directory_entry[7],
    )


def write_folder_save(destination, files, name, save_metadata=None,
                      host_directory_name=None):
    """Write one emulator-compatible Game Save directory.

    PCSX2 only creates ``_pcsx2_meta`` for filenames, modes or attributes
    which cannot be represented by the normal host file. Keeping that folder
    optional makes common exports match folders created by PCSX2 and ARMSX2.
    """
    destination = Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("A pasta de destino do Game Save deve estar vazia")
    destination.mkdir(parents=True, exist_ok=True)

    files = list(files)
    operation_time = ps2_tod_now()
    created = normalize_tod(
        getattr(save_metadata, "created", None) if save_metadata else None,
        operation_time,
    )
    modified = normalize_tod(
        getattr(save_metadata, "modified", None) if save_metadata else None,
        operation_time,
    )
    directory_mode = normalize_mode(
        getattr(save_metadata, "mode", None) if save_metadata else None, True
    )
    directory_attr = int(
        getattr(save_metadata, "attr", 0) if save_metadata else 0
    ) & 0xffffffff
    host_directory_name = _clean_host_name(host_directory_name or name)
    if _metadata_is_nonstandard(
        host_directory_name,
        name,
        directory_mode,
        directory_attr,
        DEFAULT_DIRECTORY_MODE,
    ):
        directory_entry = [
            directory_mode, 0, len(files) + 2, created, FAT_END, 0,
            modified, directory_attr, name,
        ]
        (destination / DIRECTORY_META_NAME).write_bytes(pack_ent(directory_entry))

    metadata_dir = destination / FILE_META_DIR
    index_files = []
    used_host_names = set()
    for source in files:
        host_name = _clean_host_name(source.name)
        folded = host_name.casefold()
        if folded in used_host_names:
            raise ValueError("Dois arquivos do Game Save possuem o mesmo nome compatível")
        used_host_names.add(folded)
        file_created = normalize_tod(
            getattr(source, "created", None), operation_time
        )
        file_modified = normalize_tod(
            getattr(source, "modified", None), operation_time
        )
        file_mode = normalize_mode(getattr(source, "mode", None), False)
        file_attr = int(getattr(source, "attr", 0) or 0) & 0xffffffff
        target = destination / host_name
        with target.open("wb", buffering=256 * 1024) as output:
            output.write(source.data)

        if _metadata_is_nonstandard(
            host_name, source.name, file_mode, file_attr, DEFAULT_FILE_MODE
        ):
            metadata_dir.mkdir(exist_ok=True)
            entry = [
                file_mode, 0, len(source.data), file_created, FAT_END, 0,
                file_modified, file_attr, source.name,
            ]
            (metadata_dir / host_name).write_bytes(pack_ent(entry))
        index_files.append((host_name, file_created, file_modified))

    _write_index(destination / INDEX_NAME, created, modified, index_files)
    return len(files)


class FolderMemoryCard:
    """Read a PCSX2-compatible folder Memory Card through the mymc card API."""

    is_folder_card = True

    def __init__(self, folder):
        self.path = Path(folder)
        if not self.path.is_dir():
            raise ValueError("O Memory Card em pasta não é um diretório")
        superblock = self.path / SUPERBLOCK_NAME
        if not superblock.is_file():
            raise ValueError("A pasta não possui _pcsx2_superblock")
        raw = superblock.read_bytes()
        if len(raw) < len(MAGIC) or not raw.startswith(MAGIC):
            raise ValueError("_pcsx2_superblock inválido")

        self.version = "folder"
        self.cluster_size = 1024
        self.alloc_end = 0
        self._next_id = 1
        self._path_by_id = {}
        self._dir_blob_by_id = {}
        self._save_files = {}
        self._save_root_entries = {}
        self._save_paths = {}
        self._saves = []
        self._scan()

    def _id(self, path=None):
        value = self._next_id
        self._next_id += 1
        if path is not None:
            self._path_by_id[value] = Path(path)
        return value

    def _read_entry_meta(self, path, fallback):
        try:
            raw = Path(path).read_bytes()
            if len(raw) >= DIRENT_SIZE:
                return _unpack_ent(raw)
        except OSError:
            pass
        return fallback

    def _scan(self):
        candidates = [
            p for p in self.path.iterdir()
            if p.is_dir() and not p.name.startswith(CONTROL_PREFIX)
        ]
        for host_dir in sorted(candidates, key=lambda p: p.name.casefold()):
            index = _load_index(host_dir / INDEX_NAME)
            root_times = index.get("$ROOT", index.get("%ROOT", {}))
            fallback_created = _epoch_to_tod(
                root_times.get("timeCreated", host_dir.stat().st_ctime)
            )
            fallback_modified = _epoch_to_tod(
                root_times.get("timeModified", host_dir.stat().st_mtime), fallback_created
            )
            fallback_dir = _default_entry(
                host_dir.name, 2, fallback_created, fallback_modified, True
            )
            dir_entry = self._read_entry_meta(
                host_dir / DIRECTORY_META_NAME, fallback_dir
            )
            logical_name = dir_entry[8] or host_dir.name
            dir_entry[8] = logical_name

            files_on_disk = [
                p for p in host_dir.iterdir()
                if p.is_file() and not p.name.startswith(CONTROL_PREFIX)
            ]
            files_on_disk.sort(
                key=lambda p: (
                    index.get(p.name, {}).get("order", 1 << 30),
                    p.name.casefold(),
                )
            )
            file_records = []
            packed_children = []
            directory_id = self._id()
            dot = _default_entry(".", 0, fallback_created, fallback_modified, True)
            dotdot = _default_entry("..", 0, fallback_created, fallback_modified, True)
            packed_children.extend((dot, dotdot))

            for file_path in files_on_disk:
                node = index.get(file_path.name, {})
                created = _epoch_to_tod(
                    node.get("timeCreated", file_path.stat().st_ctime), fallback_created
                )
                modified = _epoch_to_tod(
                    node.get("timeModified", file_path.stat().st_mtime), created
                )
                fallback_file = _default_entry(
                    file_path.name, file_path.stat().st_size, created, modified, False
                )
                meta_path = host_dir / FILE_META_DIR / file_path.name
                entry = self._read_entry_meta(meta_path, fallback_file)
                entry[2] = file_path.stat().st_size
                entry[8] = entry[8] or file_path.name
                file_id = self._id(file_path)
                entry[4] = file_id
                packed_children.append(entry)
                file_records.append({
                    "name": entry[8],
                    "host_name": file_path.name,
                    "size": entry[2],
                    "first_cluster": file_id,
                    "mode": entry[0],
                    "is_directory": False,
                    "created": entry[3],
                    "modified": entry[6],
                    "attr": entry[7],
                })

            dir_entry[2] = len(packed_children)
            dir_entry[4] = directory_id
            self._dir_blob_by_id[directory_id] = b"".join(
                pack_ent(entry) for entry in packed_children
            )
            self._save_files[logical_name] = file_records
            self._save_root_entries[logical_name] = dir_entry
            self._save_paths[logical_name] = host_dir
            self._saves.append(SaveEntry(
                len(self._saves) + 2,
                logical_name,
                len(packed_children),
                directory_id,
                dir_entry[0],
                True,
            ))

    def saves(self):
        return list(self._saves)

    def save_path(self, name):
        return self._save_paths.get(name)

    def save_files(self, save):
        return [dict(item) for item in self._save_files.get(save.name, [])]

    def extract_file(self, first_cluster, size):
        return self.read_file(first_cluster, size)

    def read_file(self, first_cluster, length):
        if first_cluster in self._dir_blob_by_id:
            return self._dir_blob_by_id[first_cluster][:length]
        path = self._path_by_id.get(first_cluster)
        if path is None:
            raise FileNotFoundError(first_cluster)
        with path.open("rb", buffering=256 * 1024) as stream:
            return stream.read(length)

    def directory_entries(self, first_cluster, entry_count):
        raw = self.read_file(first_cluster, entry_count * DIRENT_SIZE)
        return [
            _unpack_ent(raw[offset:offset + DIRENT_SIZE])
            for offset in range(0, len(raw), DIRENT_SIZE)
        ]

    def root_entries(self):
        now = ps2_tod_now()
        root = _default_entry(".", len(self._saves) + 2, now, now, True)
        parent = _default_entry("..", 0, now, now, True)
        return [root, parent] + [
            list(self._save_root_entries[save.name]) for save in self._saves
        ]

    def lookup_fat(self, _index):
        return 0

    def check(self):
        return []

    def stats(self):
        used = sum(
            item["size"] for files in self._save_files.values() for item in files
        )
        return {
            "free_bytes": -1,
            "used_bytes": used,
            "total_bytes": -1,
            "free_percent": -1.0,
            "dynamic": True,
            "kind": "folder",
        }


def is_folder_card(path):
    path = Path(path)
    if not path.is_dir():
        return False
    superblock = path / SUPERBLOCK_NAME
    try:
        return superblock.is_file() and superblock.read_bytes()[:len(MAGIC)] == MAGIC
    except OSError:
        return False


def create_folder_card(destination, size_mb=8):
    """Create the conservative PCSX2 folder-card structure.

    Folder cards have dynamic practical capacity, but their superblock still
    advertises a virtual PS2 size.  Eight megabytes is the broadest-compatible
    value and matches PCSX2's normal default.
    """
    destination = Path(destination)
    if destination.exists() and any(destination.iterdir()):
        raise ValueError("Selecione uma pasta vazia para criar o Memory Card")
    destination.mkdir(parents=True, exist_ok=True)
    if int(size_mb) != 8:
        size_mb = 8
    from ps2_formatter import create_memory_card
    fd, temp_name = tempfile.mkstemp(prefix="mymcdroid-folder-", suffix=".ps2")
    os.close(fd)
    temp = Path(temp_name)
    try:
        create_memory_card(temp, pages_per_card=16384)
        # PCSX2/ARMSX2 stores the complete first erase block as 16 logical
        # pages. ECC/spare bytes are omitted and unused pages remain erased.
        with temp.open("rb") as stream:
            superblock = stream.read(512)
        if not superblock.startswith(MAGIC):
            raise ValueError("Não foi possível criar o superblock do Memory Card")
        superblock += b"\xff" * (SUPERBLOCK_BLOCK_SIZE - len(superblock))
        (destination / SUPERBLOCK_NAME).write_bytes(superblock)
    finally:
        temp.unlink(missing_ok=True)
    return str(destination)


class FolderCardWriter:
    """Transactional writer for a local mirror of a folder Memory Card."""

    def __init__(self, source, destination):
        self.source = Path(source)
        self.destination = Path(destination)
        FolderMemoryCard(self.source)
        if self.destination.exists():
            if self.destination.is_dir():
                shutil.rmtree(self.destination)
            else:
                self.destination.unlink()
        shutil.copytree(self.source, self.destination, copy_function=shutil.copy2)
        # Cards created by the first MyMCdroid preview used a short 512-byte
        # control file. Upgrade them on the next write so ARMSX2 can open them.
        _ensure_full_superblock(self.destination / SUPERBLOCK_NAME)

    def _card(self):
        return FolderMemoryCard(self.destination)

    def _remove_names(self, names):
        wanted = set(names)
        card = self._card()
        removed = []
        for save in card.saves():
            if save.name not in wanted:
                continue
            path = card.save_path(save.name)
            if path is not None and path.is_dir():
                shutil.rmtree(path)
                removed.append(save.name)
        return removed

    def delete_save(self, save_name):
        removed = self._remove_names([save_name])
        if not removed:
            raise FileNotFoundError(save_name)
        return removed[0]

    def delete_saves(self, save_names):
        return self._remove_names(save_names)

    def delete_all_saves(self):
        card = self._card()
        names = [save.name for save in card.saves()]
        return len(self._remove_names(names))

    def import_files(self, files, name, timestamp=None, replace_existing=True,
                     replace_names=None, save_metadata=None,
                     host_directory_name=None):
        files = list(files)
        current = self._card()
        replace_names = list(replace_names or [])
        exact = next((save.name for save in current.saves() if save.name == name), None)
        if exact and exact not in replace_names:
            replace_names.append(exact)
        if replace_names:
            if not replace_existing:
                raise FileExistsError(name)
            self._remove_names(replace_names)

        host_directory_name = _clean_host_name(host_directory_name or name)
        final_dir = self.destination / host_directory_name
        if final_dir.exists():
            raise FileExistsError(name)
        stage = self.destination / f"_pcsx2_mymcdroid_stage_{uuid.uuid4().hex}"
        stage.mkdir(parents=False)
        try:
            if timestamp is not None and save_metadata is None:
                from save_formats import ImportedSave
                save_metadata = ImportedSave(
                    name, files, created=timestamp, modified=timestamp
                )
            write_folder_save(
                stage,
                files,
                name,
                save_metadata=save_metadata,
                host_directory_name=host_directory_name,
            )
            stage.replace(final_dir)
        except Exception:
            if stage.exists():
                shutil.rmtree(stage, ignore_errors=True)
            raise

        # Re-open after commit to ensure PCSX2 control files and every payload
        # are readable before Android synchronizes the mirror to user storage.
        verified = FolderMemoryCard(self.destination)
        saved = next((save for save in verified.saves() if save.name == name), None)
        if saved is None or len(verified.save_files(saved)) != len(files):
            raise ValueError("Falha ao validar o Game Save no Memory Card em pasta")
        return len(files)


from __future__ import annotations
import struct
import time
from datetime import datetime
from pathlib import Path
from save_formats import load_any

ENTRY=512
DF_FILE=0x10
DF_DIR=0x20
DF_EXISTS=0x8000
DF_RWX=0x7
DF_0400=0x400
FAT_ALLOC=0x80000000
FAT_END=0xffffffff
DIRENT=struct.Struct("<HHL8sLL8sL28x448s")
TOD=struct.Struct("<xBBBBBH")
ZERO_TOD=(0,0,0,0,0,0)

def ps2_tod_now():
    """Return the current PS2 timestamp (the on-card format always uses UTC+9)."""
    value=time.gmtime(time.time()+9*60*60)
    return (value.tm_sec,value.tm_min,value.tm_hour,
            value.tm_mday,value.tm_mon,value.tm_year)

def valid_tod(value):
    try:
        sec,minute,hour,day,month,year=(int(v) for v in value)
        datetime(year,month,day,hour,minute,sec)
        return 0 <= sec <= 59 and 0 <= minute <= 59 and 0 <= hour <= 23
    except (TypeError,ValueError,OverflowError):
        return False

def normalize_tod(value,fallback):
    return tuple(int(v) for v in value) if valid_tod(value) else fallback

def normalize_mode(value,is_directory):
    default=DF_RWX|DF_0400|DF_EXISTS|(DF_DIR if is_directory else DF_FILE)
    try:
        mode=int(value)&0xffff
    except (TypeError,ValueError):
        return default
    required=DF_DIR if is_directory else DF_FILE
    forbidden=DF_FILE if is_directory else DF_DIR
    if not(mode&DF_EXISTS) or not(mode&required) or mode&forbidden:
        return default
    return mode

def unpack_ent(raw):
    e=list(DIRENT.unpack(raw))
    e[3]=TOD.unpack(e[3]); e[6]=TOD.unpack(e[6])
    e[8]=e[8].split(b"\0",1)[0].decode("shift_jis","replace")
    return e

def pack_ent(e):
    e=list(e)
    e[3]=TOD.pack(*e[3]); e[6]=TOD.pack(*e[6])
    n=e[8].encode("shift_jis","replace") if isinstance(e[8],str) else e[8]
    e[8]=(n[:447]+b"\0").ljust(448,b"\0")
    return DIRENT.pack(*e)

class WritableCard:
    """Controlled PSU importer; destination is always a separate image."""
    def __init__(self, source, destination):
        self.source=Path(source); self.destination=Path(destination)
        with self.source.open("rb", buffering=256 * 1024) as stream:
            self.data=bytearray(stream.read())
        sb=struct.unpack("<28s12sHHHHLLLLLL8x128s128sbbxx",self.data[:0x154])
        if not sb[0].startswith(b"Sony PS2 Memory Card Format "):
            raise ValueError("Imagem PS2 inválida")
        self.page,self.ppc,self.alloc_offset,self.alloc_end,self.root_cluster=sb[2],sb[3],sb[7],sb[8],sb[9]
        self.cluster_size=self.page*self.ppc
        self.spare=((self.page+127)//128)*4
        self.raw_page=self.page+self.spare
        self.epc=self.cluster_size//4
        self.ifc=list(struct.unpack("<32I",sb[12]))
        self._fat_cache={}
        self._fat_dirty=set()
        self._indirect_cache={}
        self._alloc_cursor=0

    def _ecc(self,page):
        def parity(b):
            b^=b>>1; b^=b>>2; b^=b>>4
            return b&1
        pt=[parity(x) for x in range(256)]
        masks=[0x55,0x33,0x0F,0,0xAA,0xCC,0xF0]
        cpm=[]
        for b in range(256):
            m=0
            for i,x in enumerate(masks): m|=pt[b&x]<<i
            cpm.append(m)
        out=[]
        for start in range(0,len(page),128):
            cp=0x77; lp0=lp1=0x7f
            for i,b in enumerate(page[start:start+128]):
                cp^=cpm[b]
                if pt[b]:
                    lp0^=~i; lp1^=i
            out += [cp&255,lp0&127,lp1&255]
        return bytes(out)

    def write_page(self,n,page):
        if len(page)!=self.page: raise ValueError("Página inválida")
        raw=page+self._ecc(page)
        raw+=b"\0"*(self.spare-len(raw))
        o=n*self.raw_page
        self.data[o:o+len(raw)]=raw

    def read_page(self,n):
        o=n*self.raw_page
        return bytes(self.data[o:o+self.page])

    def read_cluster(self,n):
        return b"".join(self.read_page(n*self.ppc+i) for i in range(self.ppc))

    def write_cluster(self,n,buf):
        if len(buf)!=self.cluster_size: raise ValueError("Cluster inválido")
        for i in range(self.ppc):
            self.write_page(n*self.ppc+i,buf[i*self.page:(i+1)*self.page])

    def _fat_cluster(self,n):
        fat_offset=n % self.epc
        indirect_index=n // self.epc
        indirect_offset=indirect_index % self.epc
        double_index=indirect_index // self.epc
        indirect=self._indirect_cache.get(double_index)
        if indirect is None:
            indirect=struct.unpack("<%dI" % self.epc, self.read_cluster(self.ifc[double_index]))
            self._indirect_cache[double_index]=indirect
        return indirect[indirect_offset]

    def _fat_entries(self, fc):
        entries=self._fat_cache.get(fc)
        if entries is None:
            entries=list(struct.unpack("<%dI"%self.epc,self.read_cluster(fc)))
            self._fat_cache[fc]=entries
        return entries

    def get_fat(self,n):
        fc=self._fat_cluster(n)
        return self._fat_entries(fc)[n%self.epc]

    def set_fat(self,n,value):
        fc=self._fat_cluster(n)
        f=self._fat_entries(fc)
        f[n%self.epc]=value
        self._fat_dirty.add(fc)

    def alloc(self):
        for n in range(self._alloc_cursor, self.alloc_end):
            if not (self.get_fat(n)&FAT_ALLOC):
                self.set_fat(n,FAT_END)
                self._alloc_cursor=n+1
                return n
        raise OSError("Sem espaço na memory card")

    def write_alloc(self,n,buf):
        self.write_cluster(n+self.alloc_offset,buf)

    def chain(self,first):
        out=[]; seen=set(); c=first
        while c!=FAT_END:
            if c in seen: raise ValueError("Ciclo FAT")
            seen.add(c); out.append(c); v=self.get_fat(c)
            if v==FAT_END: break
            if not(v&FAT_ALLOC): raise ValueError("Cadeia FAT inválida")
            c=v&~FAT_ALLOC
        return out

    def read_file(self,first,size):
        if not size:return b""
        out=[]; left=size
        for c in self.chain(first):
            raw=self.read_cluster(c+self.alloc_offset)
            take=min(left,len(raw)); out.append(raw[:take]); left-=take
            if not left: break
        if left: raise ValueError("Cadeia curta")
        return b"".join(out)

    def read_dir(self,first,count):
        raw=self.read_file(first,count*ENTRY)
        return [unpack_ent(raw[i:i+ENTRY]) for i in range(0,len(raw),ENTRY)]

    def write_chain(self,data):
        if not data:return FAT_END
        chunks=[data[i:i+self.cluster_size] for i in range(0,len(data),self.cluster_size)]
        cs=[self.alloc() for _ in chunks]
        for i,ch in enumerate(chunks):
            self.write_alloc(cs[i],ch.ljust(self.cluster_size,b"\0"))
            if i+1<len(cs): self.set_fat(cs[i],cs[i+1]|FAT_ALLOC)
        return cs[0]

    def _alloc_chain(self, count):
        if count <= 0:
            return []
        cs=[self.alloc() for _ in range(count)]
        for i in range(count-1):
            self.set_fat(cs[i], cs[i+1] | FAT_ALLOC)
        return cs

    def _write_alloc_chain(self, cs, data):
        for i,c in enumerate(cs):
            chunk=data[i*self.cluster_size:(i+1)*self.cluster_size]
            self.write_alloc(c, chunk.ljust(self.cluster_size,b"\0"))

    def _free_chain(self, first):
        if first == FAT_END:
            return
        for c in self.chain(first):
            self.set_fat(c, 0)
            self._alloc_cursor=min(self._alloc_cursor, c)

    def _delete_save_entry(self, entry):
        # A save is a directory. Free every file chain inside it and then
        # free the directory chain itself. The root directory is untouched.
        if not (entry[0] & DF_EXISTS):
            return
        if entry[0] & DF_DIR:
            child_count = entry[2]
            if entry[4] != FAT_END and child_count:
                for child in self.read_dir(entry[4], child_count):
                    if child[8] not in (".", "..") and (child[0] & DF_EXISTS):
                        self._free_chain(child[4])
            self._free_chain(entry[4])
        else:
            self._free_chain(entry[4])

    def _touch_root(self, entries, when=None):
        if entries:
            entries[0][6]=when or ps2_tod_now()

    def delete_save(self, save_name):
        entries = self.read_dir(self.root_cluster, unpack_ent(self.read_alloc0())[2])
        match = next((i for i,e in enumerate(entries) if e[8] == save_name and (e[0] & DF_EXISTS)), None)
        if match is None:
            raise FileNotFoundError(save_name)
        self._delete_save_entry(entries[match])
        entries[match] = [0,0,0,ZERO_TOD,FAT_END,0,ZERO_TOD,0,""]
        self._touch_root(entries)
        self._write_root(entries)
        self._flush_destination()
        return save_name

    def delete_saves(self, save_names):
        """Delete selected save directories and commit the card image once."""
        wanted = set(save_names)
        entries = self.read_dir(self.root_cluster, unpack_ent(self.read_alloc0())[2])
        removed = []
        for index, entry in enumerate(entries):
            if index < 2 or entry[8] not in wanted or not (entry[0] & DF_EXISTS):
                continue
            self._delete_save_entry(entry)
            removed.append(entry[8])
            entries[index] = [0,0,0,ZERO_TOD,FAT_END,0,ZERO_TOD,0,""]
        self._touch_root(entries)
        self._write_root(entries)
        self._flush_destination()
        return removed

    def delete_all_saves(self):
        """Delete every save directory and commit the card image once."""
        entries = self.read_dir(self.root_cluster, unpack_ent(self.read_alloc0())[2])
        removed = 0
        for index, entry in enumerate(entries):
            if index < 2:
                continue
            mode = entry[0]
            if (mode & DF_EXISTS) and (mode & DF_DIR) and not (mode & DF_FILE):
                self._delete_save_entry(entry)
                entries[index] = [0,0,0,ZERO_TOD,FAT_END,0,ZERO_TOD,0,""]
                removed += 1
        self._touch_root(entries)
        self._write_root(entries)
        self._flush_destination()
        return removed

    def import_files(self, files, name, timestamp=None, replace_existing=True,
                     replace_names=None, save_metadata=None):
        files=list(files)
        entries=self.read_dir(self.root_cluster,unpack_ent(self.read_alloc0())[2])

        # If the same save already exists, replace it in this working image.
        # The Android side only commits the working image after validation, so
        # a failed import cannot damage the user's original memory card.
        # replace_names lets the caller replace saves by a logical identity
        # (for example normalized Serial ID + region) instead of requiring
        # the on-card directory names to be identical. This is important
        # when the same game is imported from CBS, XPS, SPS or MAX, because
        # each container can generate a different save-directory name.
        if replace_names is not None:
            names = set(replace_names)
            matches = [i for i,e in enumerate(entries)
                       if e[8] in names and (e[0]&DF_EXISTS)]
        else:
            matches = [i for i,e in enumerate(entries)
                       if e[8] == name and (e[0]&DF_EXISTS)]
        if matches:
            if not replace_existing:
                raise FileExistsError(name)
            for existing in matches:
                self._delete_save_entry(entries[existing])
                entries[existing]=[0,0,0,ZERO_TOD,FAT_END,0,ZERO_TOD,0,""]

        free=next((i for i,e in enumerate(entries) if not(e[0]&DF_EXISTS)),None)
        if free is None:
            free=len(entries)
            entries.append([0,0,0,(0,0,0,0,0,0),FAT_END,0,(0,0,0,0,0,0),0,""])

        # Allocate file data first so their FAT chains are complete before
        # publishing the directory entry.
        file_first=[]
        for f in files:
            file_first.append(self.write_chain(f.data))

        child_count=len(files)+2
        child_bytes=child_count*ENTRY
        dir_clusters=(child_bytes+self.cluster_size-1)//self.cluster_size
        dchain=self._alloc_chain(dir_clusters)
        dc=dchain[0]
        operation_time=ps2_tod_now()
        source_created=(getattr(save_metadata,"created",None)
                        if save_metadata is not None else timestamp)
        source_modified=(getattr(save_metadata,"modified",None)
                         if save_metadata is not None else timestamp)
        created=normalize_tod(source_created,operation_time)
        modified=normalize_tod(source_modified,operation_time)
        directory_mode=normalize_mode(
            getattr(save_metadata,"mode",None) if save_metadata is not None else None,
            True
        )
        directory_attr=int(getattr(save_metadata,"attr",0) or 0)&0xffffffff
        entries[free]=[
            directory_mode,0,child_count,created,dc,0,modified,directory_attr,name
        ]
        entries[0][2]=len(entries)
        self._touch_root(entries,operation_time)
        self._write_root(entries)

        child=[
            [DF_RWX|DF_DIR|DF_0400|DF_EXISTS,0,0,created,
             self.root_cluster,free,created,0,"."],
            [DF_RWX|DF_DIR|DF_0400|DF_EXISTS,0,0,created,
             0,0,created,0,".."]]
        for f,fc in zip(files,file_first):
            file_created=normalize_tod(getattr(f,"created",None),operation_time)
            file_modified=normalize_tod(getattr(f,"modified",None),operation_time)
            file_mode=normalize_mode(getattr(f,"mode",None),False)
            file_attr=int(getattr(f,"attr",0) or 0)&0xffffffff
            child.append([
                file_mode,0,f.size,file_created,fc,0,file_modified,file_attr,f.name
            ])
        self._write_alloc_chain(dchain,b"".join(pack_ent(e) for e in child))
        self._validate_imported_save(entries,free,files,child)
        self._flush_destination()
        return len(files)

    def _validate_imported_save(self, root_entries, root_index, files, expected):
        """Validate filesystem metadata and FAT lengths without copying file data."""
        root=root_entries[root_index]
        if root[5] != 0 or root[2] != len(files)+2:
            raise ValueError("Diretório do Game Save inválido")
        if not valid_tod(root[3]) or not valid_tod(root[6]):
            raise ValueError("Data do Game Save inválida")
        directory_chain=self.chain(root[4])
        needed=(root[2]*ENTRY+self.cluster_size-1)//self.cluster_size
        if len(directory_chain) != needed:
            raise ValueError("Cadeia do diretório do Game Save inválida")

        actual=self.read_dir(root[4],root[2])
        if len(actual) != len(expected):
            raise ValueError("Contagem de entradas do Game Save inválida")
        dot,dotdot=actual[:2]
        if dot[8] != "." or (dot[4],dot[5]) != (self.root_cluster,root_index):
            raise ValueError("Vínculo interno do Game Save inválido")
        if dotdot[8] != ".." or (dotdot[4],dotdot[5]) != (0,0):
            raise ValueError("Entrada reservada do Game Save inválida")

        for source,entry in zip(files,actual[2:]):
            if entry[8] != source.name or entry[2] != source.size or entry[5] != 0:
                raise ValueError("Metadados de arquivo do Game Save inválidos")
            if not valid_tod(entry[3]) or not valid_tod(entry[6]):
                raise ValueError("Data de arquivo do Game Save inválida")
            expected_clusters=(source.size+self.cluster_size-1)//self.cluster_size
            if len(self.chain(entry[4])) != expected_clusters:
                raise ValueError("Tamanho do arquivo do Game Save inválido")

    def _flush_destination(self):
        # One buffered sequential write avoids Path.write_bytes creating an
        # additional full-size immutable bytes object for an 8/16/32 MB card.
        # FAT clusters are coalesced here, so hundreds of allocations don't
        # recalculate and rewrite the same cluster hundreds of times.
        for fc in self._fat_dirty:
            self.write_cluster(fc, struct.pack("<%dI"%self.epc, *self._fat_cache[fc]))
        self._fat_dirty.clear()
        with self.destination.open("wb", buffering=256 * 1024) as stream:
            stream.write(self.data)

    def import_psu(self,psu_path,target_name=None,replace_existing=True):
        imported=load_any(psu_path)
        name=target_name or imported.name
        return self.import_files(
            imported.files,name,replace_existing=replace_existing,
            save_metadata=imported
        )

    def read_alloc0(self):
        return self.read_cluster(self.root_cluster+self.alloc_offset)[:ENTRY]

    def _write_root(self,entries):
        data=b"".join(pack_ent(e) for e in entries)
        chain=self.chain(self.root_cluster)
        need=(len(data)+self.cluster_size-1)//self.cluster_size
        while len(chain)<need:
            n=self.alloc(); self.set_fat(chain[-1],n|FAT_ALLOC); chain.append(n)
        for i,c in enumerate(chain[:need]):
            self.write_alloc(c,data[i*self.cluster_size:(i+1)*self.cluster_size].ljust(self.cluster_size,b"\0"))

from __future__ import annotations
import struct, zlib, array
from dataclasses import dataclass
from pathlib import Path

@dataclass
class ImportedFile:
    name: str
    data: bytes
    mode: int = 0x8417
    created: tuple | None = None
    modified: tuple | None = None
    attr: int = 0

    @property
    def size(self):
        return len(self.data)

@dataclass
class ImportedSave:
    """A save container plus the PS2 directory metadata it can preserve.

    Iteration deliberately yields ``name, files`` so existing callers which
    unpacked the old two-item result continue to work.
    """
    name: str
    files: list[ImportedFile]
    mode: int = 0x8427
    created: tuple | None = None
    modified: tuple | None = None
    attr: int = 0

    def __iter__(self):
        yield self.name
        yield self.files

class SaveFormatError(ValueError):
    pass

def _z(b):
    return b.split(b"\0",1)[0]

def _sjis(b):
    return _z(b).decode('shift_jis','replace')

def _tod(raw):
    # PS2 TOD: reserved, sec, min, hour, day, month, year
    if len(raw)!=8: return (0,0,0,0,0,0)
    return struct.unpack('<xBBBBBH', raw)

# Minimal, self-contained LZARI decoder (Okumura-compatible) used by MAX Drive.
HIST_LEN=4096; MIN_MATCH_LEN=3; MAX_MATCH_LEN=60; ARITH_BITS=15
Q1=1<<ARITH_BITS; Q2=Q1*2; Q3=Q1*3; Q4=Q1*4; MAX_CUM=Q1-1
MAX_CHAR=256+MAX_MATCH_LEN-MIN_MATCH_LEN+1

def _bits(src):
    # LZARI stores bits MSB-first within each byte after converting bytes to bit array.
    for b in src:
        for i in range(7,-1,-1): yield (b>>i)&1


def _lzari_decode(src, out_length):
    """Decode the LZARI stream used by Action Replay MAX.
    Ported from the public-domain decoder used by Ross Ridge's mymc,
    with Python 3 integer arithmetic.
    """
    if out_length <= 0:
        return b""
    from bisect import bisect_right

    HIST_LEN = 4096
    MIN_MATCH_LEN = 3
    MAX_MATCH_LEN = 60
    ARITH_BITS = 15
    Q1 = 1 << ARITH_BITS
    Q2 = Q1 * 2
    Q3 = Q1 * 3
    Q4 = Q1 * 4
    MAX_CUM = Q1 - 1
    MAX_CHAR = 256 + MAX_MATCH_LEN - MIN_MATCH_LEN + 1

    # Read compressed bits directly. Building a Python list with eight
    # integers per input byte was particularly costly for large MAX saves.
    bit_pos = 0
    bit_length = len(src) * 8

    def next_bit():
        nonlocal bit_pos
        if bit_pos >= bit_length:
            return 0
        byte_pos = bit_pos >> 3
        shift = 7 - (bit_pos & 7)
        v = (src[byte_pos] >> shift) & 1
        bit_pos += 1
        return v

    high = Q4
    low = 0
    code = 0
    for _ in range(ARITH_BITS + 2):
        code = code * 2 + next_bit()

    # Decode model state exactly as in the original mymc decoder.
    sym_cum = list(range(MAX_CHAR + 1))
    symbol_to_char = [0] + list(range(MAX_CHAR))
    sym_freq = [0] + [1] * MAX_CHAR

    position_cum = [0] * (HIST_LEN + 1)
    a = 0
    for i in range(HIST_LEN, 0, -1):
        a += 10000 // (200 + i)
        position_cum[i - 1] = a

    def update_model(symbol):
        nonlocal sym_cum, sym_freq, symbol_to_char
        if sym_cum[MAX_CHAR] >= MAX_CUM:
            c = 0
            for i in range(MAX_CHAR, 0, -1):
                sym_cum[MAX_CHAR - i] = c
                a = (sym_freq[i] + 1) // 2
                sym_freq[i] = a
                c += a
            sym_cum[MAX_CHAR] = c

        freq = sym_freq[symbol]
        new_symbol = symbol
        while new_symbol > 1 and sym_freq[new_symbol - 1] == freq:
            new_symbol -= 1

        if new_symbol != symbol:
            symbol_to_char[new_symbol], symbol_to_char[symbol] = (
                symbol_to_char[symbol], symbol_to_char[new_symbol]
            )

        sym_freq[new_symbol] = freq + 1
        for i in range(MAX_CHAR - new_symbol + 1, MAX_CHAR + 1):
            sym_cum[i] += 1

    def decode_char():
        nonlocal high, low, code
        rng = high - low
        max_cum = sym_cum[MAX_CHAR]
        n = ((code - low + 1) * max_cum - 1) // rng
        i = bisect_right(sym_cum, n, 1)
        high = low + sym_cum[i] * rng // max_cum
        low += sym_cum[i - 1] * rng // max_cum
        symbol = MAX_CHAR + 1 - i

        while True:
            if low < Q2:
                if low < Q1 or high > Q3:
                    if high > Q2:
                        break
                else:
                    low -= Q1
                    code -= Q1
                    high -= Q1
            else:
                low -= Q2
                code -= Q2
                high -= Q2
            low *= 2
            high *= 2
            code = code * 2 + next_bit()

        ret = symbol_to_char[symbol]
        update_model(symbol)
        return ret

    def search(table, x):
        c = 1
        s = len(table) - 1
        while True:
            a = (s + c) // 2
            if table[a] <= x:
                s = a
            else:
                c = a + 1
            if c >= s:
                break
        return c

    def decode_position():
        nonlocal high, low, code
        rng = high - low
        max_cum = position_cum[0]
        posv = search(
            position_cum,
            ((code - low + 1) * max_cum - 1) // rng
        ) - 1
        high = low + position_cum[posv] * rng // max_cum
        low += position_cum[posv + 1] * rng // max_cum

        while True:
            if low < Q2:
                if low < Q1 or high > Q3:
                    if high > Q2:
                        return posv
                else:
                    low -= Q1
                    code -= Q1
                    high -= Q1
            else:
                low -= Q2
                code -= Q2
                high -= Q2
            low *= 2
            high *= 2
            code = next_bit() + code * 2

    out = bytearray(out_length)
    history = bytearray(HIST_LEN)
    hist_pos = HIST_LEN - MAX_MATCH_LEN

    op = 0
    while op < out_length:
        ch = decode_char()
        if ch >= 0x100:
            match_pos = decode_position()
            length = ch - 0x100 + MIN_MATCH_LEN
            base = (hist_pos - match_pos - 1) % HIST_LEN
            for j in range(length):
                v = history[(base + j) % HIST_LEN]
                out[op] = v
                op += 1
                history[hist_pos] = v
                hist_pos = (hist_pos + 1) % HIST_LEN
                if op >= out_length:
                    break
        else:
            out[op] = ch
            op += 1
            history[hist_pos] = ch
            hist_pos = (hist_pos + 1) % HIST_LEN
    return bytes(out)

def _load_psu(raw):
    if len(raw)<1536: raise SaveFormatError('PSU inválido')
    def ent(b):
        mode,_,size,created,cluster,dir_entry,modified,attr,name=struct.unpack('<HHL8sLL8sL28x448s',b)
        return mode,size,_sjis(name),_tod(created),cluster,dir_entry,_tod(modified),attr
    root=ent(raw[:512]); dot=ent(raw[512:1024]); dotdot=ent(raw[1024:1536])
    if root[1]<2 or not (root[0]&0x20) or not (root[0]&0x8000): raise SaveFormatError('PSU inválido')
    if dot[2] != '.' or dotdot[2] != '..': raise SaveFormatError('PSU inválido')
    off=1536; files=[]
    for _ in range(root[1]-2):
        if off+512>len(raw): raise SaveFormatError('PSU truncado')
        mode,size,name,created,cluster,dir_entry,modified,attr=ent(raw[off:off+512]); off+=512
        if mode&0x20 or not(mode&0x10) or not(mode&0x8000): raise SaveFormatError('PSU contém entrada inválida')
        data=raw[off:off+size];
        if len(data)!=size: raise SaveFormatError('PSU truncado')
        off += size + ((-size)%1024)
        files.append(ImportedFile(name,data,mode,created,modified,attr))
    return ImportedSave(root[2], files, root[0], root[3], root[6], root[7])

def _load_sps_xps(raw):
    magic=b'\x0d\0\0\0SharkPortSave'
    if not raw.startswith(magic): raise SaveFormatError('SPS/XPS inválido')
    off=17
    def u32():
        nonlocal off
        if off+4>len(raw): raise SaveFormatError('SPS/XPS truncado')
        v=struct.unpack_from('<L',raw,off)[0]; off+=4; return v
    def ls():
        nonlocal off
        n=u32(); b=raw[off:off+n]; off+=n
        if len(b)!=n: raise SaveFormatError('SPS/XPS truncado')
        return b
    _savetype=u32(); dirname=ls(); _date=ls(); _comment=ls(); _flen=u32()
    if off+98>len(raw): raise SaveFormatError('SPS/XPS truncado')
    hlen,name,dirlen,mode,dir_created,dir_modified=struct.unpack_from('<H64sL8xH2x8s8s',raw,off); off+=98
    off += max(0,hlen-98); dirlen-=2
    mode=((mode&0xff)<<8)|((mode>>8)&0xff)
    if dirlen<0 or not(mode&0x20) or not(mode&0x8000): raise SaveFormatError('SPS/XPS diretório inválido')
    files=[]
    for _ in range(dirlen):
        if off+98>len(raw): raise SaveFormatError('SPS/XPS truncado')
        hlen,name,flen,fmode,created,modified=struct.unpack_from('<H64sL8xH2x8s8s',raw,off); off+=98
        off+=max(0,hlen-98)
        fmode=((fmode&0xff)<<8)|((fmode>>8)&0xff)
        if fmode&0x20 or not(fmode&0x10) or not(fmode&0x8000): raise SaveFormatError('SPS/XPS contém entrada inválida')
        data=raw[off:off+flen];
        if len(data)!=flen: raise SaveFormatError('SPS/XPS truncado')
        off+=flen
        files.append(ImportedFile(_sjis(name),data,fmode,_tod(created),_tod(modified),0))
    return ImportedSave(
        _sjis(dirname), files, mode, _tod(dir_created), _tod(dir_modified), 0
    )

def _rc4_cbs(data):
    # Fixed RC4 initial permutation used by CodeBreaker PS2 saves.
    s=[0x5f,0x1f,0x85,0x6f,0x31,0xaa,0x3b,0x18,0x21,0xb9,0xce,0x1c,0x07,0x4c,0x9c,0xb4,0x81,0xb8,0xef,0x98,0x59,0xae,0xf9,0x26,0xe3,0x80,0xa3,0x29,0x2d,0x73,0x51,0x62,0x7c,0x64,0x46,0xf4,0x34,0x1a,0xf6,0xe1,0xba,0x3a,0x0d,0x82,0x79,0x0a,0x5c,0x16,0x71,0x49,0x8e,0xac,0x8c,0x9f,0x35,0x19,0x45,0x94,0x3f,0x56,0x0c,0x91,0x00,0x0b,0xd7,0xb0,0xdd,0x39,0x66,0xa1,0x76,0x52,0x13,0x57,0xf3,0xbb,0x4e,0xe5,0xdc,0xf0,0x65,0x84,0xb2,0xd6,0xdf,0x15,0x3c,0x63,0x1d,0x89,0x14,0xbd,0xd2,0x36,0xfe,0xb1,0xca,0x8b,0xa4,0xc6,0x9e,0x67,0x47,0x37,0x42,0x6d,0x6a,0x03,0x92,0x70,0x05,0x7d,0x96,0x2f,0x40,0x90,0xc4,0xf1,0x3e,0x3d,0x01,0xf7,0x68,0x1e,0xc3,0xfc,0x72,0xb5,0x54,0xcf,0xe7,0x41,0xe4,0x4d,0x83,0x55,0x12,0x22,0x09,0x78,0xfa,0xde,0xa7,0x06,0x08,0x23,0xbf,0x0f,0xcc,0xc1,0x97,0x61,0xc5,0x4a,0xe6,0xa0,0x11,0xc2,0xea,0x74,0x02,0x87,0xd5,0xd1,0x9d,0xb7,0x7e,0x38,0x60,0x53,0x95,0x8d,0x25,0x77,0x10,0x5e,0x9b,0x7f,0xd8,0x6e,0xda,0xa2,0x2e,0x20,0x4f,0xcd,0x8f,0xcb,0xbe,0x5a,0xe0,0xed,0x2c,0x9a,0xd4,0xe2,0xaf,0xd0,0xa9,0xe8,0xad,0x7a,0xbc,0xa8,0xf2,0xee,0xeb,0xf5,0xa6,0x99,0x28,0x24,0x6c,0x2b,0x75,0x5d,0xf8,0xd3,0x86,0x17,0xfb,0xc0,0x7b,0xb3,0x58,0xdb,0xc7,0x4b,0xff,0x04,0x50,0xe9,0x88,0x69,0xc9,0x2a,0xab,0xfd,0x5b,0x1b,0x8a,0xd9,0xec,0x27,0x44,0x0e,0x33,0xc8,0x6b,0x93,0x32,0x48,0xb6,0x30,0x43,0xa5]
    if len(s)!=256: raise SaveFormatError('CBS RC4 tabela inválida')
    t=bytearray(data); j=0
    for ii in range(len(t)):
        i=(ii+1)%256; j=(j+s[i])%256; s[i],s[j]=s[j],s[i]; t[ii]^=s[(s[i]+s[j])%256]
    return bytes(t)

def _load_cbs(raw):
    if not raw.startswith(b'CFU\0') or len(raw) < 12:
        raise SaveFormatError('CBS inválido')

    # The first 12 bytes are: magic, d04, header length.
    d04, hlen = struct.unpack_from('<LL', raw, 4)
    if hlen < 124:
        raise SaveFormatError('CBS cabeçalho inválido')
    if hlen > len(raw):
        raise SaveFormatError('CBS truncado')

    # Header fields after magic/d04/hlen:
    # decompressed size, file length, dirname, timestamps, mode, title...
    header_rest = raw[12:hlen]
    if len(header_rest) != hlen - 12:
        raise SaveFormatError('CBS truncado')

    fixed_fmt = '<LL32s8s8sLLLLLL'
    fixed_size = struct.calcsize(fixed_fmt)
    if len(header_rest) < fixed_size:
        raise SaveFormatError('CBS cabeçalho truncado')

    vals = struct.unpack_from(fixed_fmt, header_rest, 0)
    dlen, flen, dirname, created, modified, d44, d48, dirmode, d50, d54, d58 = vals

    # flen is inconsistent across CBS producers: it may be the complete
    # file size or the compressed-body size. Never require it blindly.
    available = len(raw) - hlen
    if flen == len(raw):
        body_len = available
    elif flen == available:
        body_len = flen
    elif flen == len(raw) - hlen:
        body_len = flen
    elif flen <= available:
        body_len = flen
    else:
        # Some files report a stale compressed length; consume the bytes
        # actually present, as the original mymc does.
        body_len = available

    compressed = raw[hlen:hlen + body_len]
    if not compressed:
        raise SaveFormatError('CBS sem dados')

    decrypted = _rc4_cbs(compressed)

    try:
        # Do not trust dlen: some CodeBreaker tools store an incorrect value.
        body = zlib.decompress(decrypted)
    except zlib.error:
        try:
            obj = zlib.decompressobj()
            body = obj.decompress(decrypted)
            body += obj.flush()
        except zlib.error as exc:
            raise SaveFormatError('CBS compressão inválida') from exc

    if dlen and len(body) < min(dlen, 64):
        raise SaveFormatError('CBS dados incompletos')

    files = []
    off = 0
    while off < len(body):
        if len(body) - off < 64:
            # Trailing bytes are only acceptable if they are all zero.
            if all(b == 0 for b in body[off:]):
                break
            raise SaveFormatError('CBS entrada truncada')

        file_created, file_modified, size, mode, _h06, _h08, _h0c, name = struct.unpack_from(
            '<8s8sLHHLL32s', body, off
        )
        off += 64
        if size > len(body) - off:
            raise SaveFormatError('CBS arquivo truncado')

        data = body[off:off + size]
        off += size
        files.append(ImportedFile(
            _sjis(name), data, mode, _tod(file_created), _tod(file_modified), 0
        ))

    if not files:
        raise SaveFormatError('CBS sem arquivos')

    return ImportedSave(
        _sjis(dirname), files, dirmode & 0xffff,
        _tod(created), _tod(modified), 0
    )
def load_any(path):
    raw=Path(path).read_bytes(); ext=Path(path).suffix.lower()
    if ext=='.psu':
        return _load_psu(raw)
    if ext=='.max':
        if len(raw)<0x5c or raw[:12]!=b'Ps2PowerSave': raise SaveFormatError('MAX Drive inválido')
        magic,crc,dirname,iconsysname,clen,dirlen,length=struct.unpack('<12sL32s32sLLL',raw[:0x5c])
        body=raw[0x5c:]
        # MAX Drive files are not reliably described by the header
        # clen/length fields.  Some producers set clen == length even when
        # the payload is LZARI-compressed (for example Naruto Ultimate Ninja 5).
        # The reliable test is the actual payload size: if it already equals
        # the declared decompressed length, it is raw; otherwise decode LZARI.
        if len(body) == length:
            data = body
        else:
            compressed = body
            if clen > 0 and clen <= len(body):
                # Older MAX writers include a 4-byte trailer in clen.
                candidate = body[:clen]
                try:
                    data = _lzari_decode(candidate, length)
                except Exception:
                    data = _lzari_decode(body[:max(0, clen-4)], length)
            else:
                data = _lzari_decode(compressed, length)
        off=0; files=[]
        for _ in range(dirlen):
            if off+36>len(data): raise SaveFormatError('MAX Drive truncado')
            size,name=struct.unpack_from('<L32s',data,off); off+=36
            chunk=data[off:off+size]; off+=size
            if len(chunk)!=size: raise SaveFormatError('MAX Drive arquivo truncado')
            off=(off+8+15)//16*16-8
            files.append(ImportedFile(_sjis(name),chunk))
        return ImportedSave(_sjis(dirname),files)
    if ext in ('.sps','.xps'):
        # X-Port uses the same SharkPort container family and metadata layout.
        return _load_sps_xps(raw)
    if ext=='.cbs': return _load_cbs(raw)
    raise SaveFormatError('Formato não suportado. Use .PSU, .MAX, .SPS, .XPS ou .CBS.')

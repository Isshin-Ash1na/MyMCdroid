# MyMCdroid 2.2.0 — Expanded Save Preview 4

## Correção principal

As miniaturas não carregam mais uma página vazia ao abrir ou fechar o render ampliado. Somente o contexto gráfico é suspenso e restaurado, preservando a página, os dados e o estado visual.

## Roteiro de testes

1. Abra um Memory Card com várias miniaturas visíveis.
2. Abra e feche o render ampliado repetidamente.
3. Observe as miniaturas durante o fechamento: não deve aparecer texto branco.
4. Confirme que os ícones retornam sem troca de Game Save.
5. Repita usando o X, botão Voltar e toque externo.
6. Alterne rapidamente entre diferentes Game Saves.
7. Role a lista antes e depois de usar a visualização ampliada.
8. Confirme que apenas um modal pode permanecer aberto.
9. Teste também a entrada e a saída suave do modo em lote.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

# MyMCdroid 2.2.0 — Batch Focus Preview 1

## Alteração

- Ao ativar o modo em lote, somente **Exportar Save Games** e **Remover Save Games** permanecem na barra de ações.
- Abrir Memory Card, Exportar Todos os Save Games, Criar Memory Card, Formatar Memory Card e Fechar Memory Card são ocultados e desativados durante o modo em lote.
- O botão **Importar Save Games** também é ocultado e desativado.
- Ao encerrar o modo em lote, as ações disponíveis para o estado atual do Memory Card retornam com a animação da barra.
- Selecionar ou desmarcar outros Game Saves não reinicia as animações da barra.
- O Manual foi atualizado em português e inglês.

## Testes recomendados

1. Segure um Game Save por 1 segundo para ativar o modo em lote.
2. Confirme que somente Exportar Save Games e Remover Save Games permanecem visíveis.
3. Selecione e desmarque outros Game Saves; a barra não deve repetir a animação.
4. Toque no Game Save inicial para encerrar o modo.
5. Confirme que Abrir, Exportar Todos, Criar, Formatar, Fechar e Importar retornam conforme sua disponibilidade.

O pacote do projeto não inclui APK, AAB, caches ou diretórios de compilação.

# myMC Android — v1.4

A UI Android funcional foi adicionada para o fluxo já validado de leitura/exportação:
- SAF para abrir `.ps2`;
- cópia da imagem para cache (origem nunca é escrita);
- listagem dos saves via Python/Chaquopy;
- selecção de save;
- SAF para escolher destino `.psu`;
- exportação via núcleo Python original/portado.

A importação destrutiva continua desactivada até o teste em dispositivo.

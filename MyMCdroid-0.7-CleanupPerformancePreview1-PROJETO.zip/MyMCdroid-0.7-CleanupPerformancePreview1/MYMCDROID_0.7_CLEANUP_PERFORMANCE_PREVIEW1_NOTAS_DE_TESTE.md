# MyMCdroid 0.7 — Cleanup & Performance Preview 1

Prévia criada a partir da base oficial 0.6. Não contém APK compilado.

## Testes recomendados

1. Abra Memory Cards de 8, 16, 32 e 64 MB e confirme a lista e o espaço livre.
2. Importe um novo Game Save e sobrescreva um existente com o mesmo Serial ID + Região.
3. Faça importação em lote nos formatos PSU, MAX, CBS, SPS e XPS.
4. Exporte e reimporte cada formato, incluindo Game Save em pasta.
5. Abra dois Memory Cards e teste transferir um, vários e todos os Game Saves.
6. Confirme miniaturas, render ampliado, animações e seleção em lote.
7. Abra Manual, Configurações e Sobre nos idiomas Brasileiro e Inglês.
8. Compare a fluidez ao abrir um Memory Card com muitos Game Saves e ao verificar o espaço livre.

## Observação

O código legado e os testes continuam no projeto, em `reference/` e `tools/`, mas não são mais incluídos no pacote do aplicativo.

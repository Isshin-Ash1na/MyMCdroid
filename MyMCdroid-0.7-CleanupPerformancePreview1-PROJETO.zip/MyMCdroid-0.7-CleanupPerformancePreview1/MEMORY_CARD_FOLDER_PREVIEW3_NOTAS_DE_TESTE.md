# MyMCdroid 2.2.0 — Memory Card Folder Preview 3

## Correção de compatibilidade com ARMSX2

- A estrutura foi comparada com um Memory Card em pasta criado pelo próprio ARMSX2.
- O arquivo `_pcsx2_superblock` agora possui o bloco completo de 8.192 bytes esperado pelo ARMSX2/PCSX2.
- O formato anterior de 512 bytes fazia o emulador considerar o Memory Card não formatado antes mesmo de procurar os Game Saves.
- O arquivo `_pcsx2_index` agora é gravado no formato compacto utilizado pela amostra real do ARMSX2.
- O leitor aceita tanto o índice compacto atual quanto o índice em blocos das versões anteriores.
- Memory Cards de 512 bytes criados pelas previews anteriores são atualizados automaticamente para 8.192 bytes na próxima importação, remoção, formatação ou outra gravação feita pelo MyMCdroid.
- A pasta física do Game Save continua compatível com o filtro por Serial ID e os metadados originais permanecem preservados.

## Validação realizada

- A amostra `MemoryCard.zip`, criada no ARMSX2 com Onimusha 3, foi reconhecida como:
  - título: `ＯＮＩＭＵＳＨＡ３`;
  - Serial ID: `SLUS-20694`;
  - região: `NTSC-U`;
  - pasta física: `BASLUS-20694`;
  - cinco arquivos do Game Save.
- O arquivo real `onimusha-3-demon-siege.7376.max` foi importado em um novo Memory Card de teste.
- O resultado gerou o mesmo conjunto de nomes e tamanhos de arquivos da amostra do ARMSX2.
- `icon.sys` e os três ícones de Onimusha 3 ficaram idênticos aos arquivos da amostra.
- Foram aprovados os testes de criar, importar, exportar, sobrescrever, remover e formatar Memory Card em pasta.
- O round-trip continua coberto para `.PSU`, `.MAX`, `.CBS`, `.SPS` e `.XPS`.

## Teste sugerido no ARMSX2

1. Crie um novo **Memory Card em pasta (PCSX2)** no MyMCdroid.
2. Escolha a pasta-pai e defina o nome do cartão.
3. Importe o Game Save de Onimusha 3.
4. Feche o Memory Card no MyMCdroid.
5. No ARMSX2, selecione diretamente a pasta `.ps2` criada como Folder Memory Card.
6. Reinicie o jogo para reaplicar o filtro do Memory Card.
7. Confirme que o Game Save aparece e pode ser carregado.

Não abra o mesmo Memory Card para gravação simultânea nos dois aplicativos.

Este pacote contém somente o projeto-fonte. O APK compilado não está incluído.

# Prévia em teste

`MyMCdroid 0.7 — Cleanup & Performance Preview 1`

Criada a partir da base oficial aprovada `MyMCdroid 0.6 — Directional Outline Icons`.
A versão 0.6 continua sendo a base oficial até a aprovação desta prévia.

Escopo desta prévia:

- reorganização conservadora do código e dos arquivos de apoio;
- remoção de classes e recursos Android comprovadamente sem referências;
- testes Python e código legado preservados fora do pacote do aplicativo;
- cache de estruturas FAT somente leitura durante cada operação;
- reutilização do módulo Python durante a sessão do aplicativo;
- leitura parcial de cabeçalhos de importação e detecção de cartão apagado em blocos;
- redução de releituras de metadados mantendo a regra Serial ID + Região;
- interface, Manual, Sobre, múltiplos Memory Cards, formato pasta e PSU/MAX/CBS/SPS/XPS preservados.

# MyMCdroid 2.2.0 — Memory Card Folder Preview 1

## Novidade

- Criação e abertura de Memory Cards em pasta no padrão utilizado pelo PCSX2.
- Seleção da pasta pelo seletor seguro do Android, sem solicitar acesso amplo ao armazenamento.
- Listagem, visualização 3D, importação, sobrescrita, exportação, remoção e formatação também disponíveis nesse tipo de Memory Card.
- Importação e sobrescrita continuam identificando o Game Save por Serial ID + Região.
- Compatibilidade mantida com `.PSU`, `.MAX`, `.CBS`, `.SPS` e `.XPS`.
- Arquivos `.PS2` de 8 MB, 16 MB, 32 MB e 64 MB continuam funcionando sem alteração no fluxo existente.
- O painel identifica o novo tipo como **Memory Card em pasta** e informa **Capacidade: Dinâmica**.
- Manual e interface atualizados em Português (Brasil) e Inglês.

## Roteiro de teste

1. Toque em **Criar Memory Card**, escolha **Memory Card em pasta (PCSX2)** e selecione ou crie uma pasta vazia.
2. Importe Game Saves nos cinco formatos suportados e confirme a renderização dos ícones.
3. Sobrescreva um Game Save existente e confirme que não foi criada uma entrada duplicada.
4. Exporte um Game Save em cada formato e reimporte os arquivos exportados.
5. Teste a remoção individual, a remoção em lote e **Formatar Memory Card**.
6. Feche o Memory Card no MyMCdroid, abra a mesma pasta em um emulador compatível e valide os Game Saves.
7. Feche ou ejete o Memory Card no emulador antes de voltar a alterá-lo no MyMCdroid, evitando gravações simultâneas na mesma pasta.

## Observação do Android

Em versões recentes do Android, o sistema pode impedir que um aplicativo abra diretamente a pasta privada de outro aplicativo, especialmente dentro de `Android/data`. Nesse caso, copie o Memory Card em pasta para um local acessível pelo seletor de pastas ou use um provedor de armazenamento que exponha essa pasta. Essa restrição pertence ao Android e não remove a compatibilidade do formato.

## Verificações realizadas

- Compilação Kotlin/Android concluída com sucesso.
- Superblock PCSX2 validado com 512 bytes, sem os bytes extras de ECC de imagens `.PS2` brutas.
- Criação, abertura e leitura do Memory Card em pasta.
- Importação nova e sobrescrita preservando conteúdo e metadados disponíveis.
- Exportação e reimportação em `.PSU`, `.MAX`, `.CBS`, `.SPS` e `.XPS`.
- Remoção individual e formatação completa.
- Teste adicional com um Game Save `.MAX` real de Onimusha 2.

Este pacote contém somente o projeto-fonte. O APK compilado não está incluído.

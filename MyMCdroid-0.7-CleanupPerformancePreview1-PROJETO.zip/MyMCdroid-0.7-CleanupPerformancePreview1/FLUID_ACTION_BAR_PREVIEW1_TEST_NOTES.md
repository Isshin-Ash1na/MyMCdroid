# MyMCdroid 2.2.0 — Fluid Action Bar Preview 1

## Alterações

- Os botões **Formatar Memory Card** e **Fechar Memory Card** levam 1 segundo para desaparecer quando deixam de estar disponíveis.
- As funções são desabilitadas imediatamente no início da animação de saída, impedindo novos acionamentos durante o desaparecimento.
- Os botões somente voltam a aceitar toques depois que a animação de entrada termina.
- As opções em lote utilizam a mesma regra de segurança e duração.
- O espaço ocupado pelos grupos é expandido ou recolhido progressivamente, movimentando **Abrir Memory Card** e **Criar Memory Card** de forma suave.
- Animações interrompidas podem inverter a direção sem salto ou repetição visual.

## Roteiro de testes

1. Abra um Memory Card e observe a entrada de **Formatar Memory Card** e **Fechar Memory Card**.
2. Durante a entrada, tente tocar repetidamente nesses botões: eles só devem responder depois que estiverem completamente visíveis.
3. Feche o Memory Card e confirme que os dois botões permanecem visíveis durante a saída de 1 segundo, mas não aceitam novos toques.
4. Ative e desative o modo em lote e observe a entrada e a saída de **Exportar Save Games** e **Remover Save Games**.
5. Alterne rapidamente o modo em lote para confirmar que a animação muda de direção sem piscar ou repetir.
6. Abra e feche Memory Cards repetidamente e confira o movimento contínuo de toda a barra.
7. Confirme que **Abrir Memory Card** e **Criar Memory Card** continuam disponíveis e se reposicionam suavemente.

O pacote de testes deve conter somente o projeto-fonte, sem APK ou AAB compilado.

# Base oficial — MyMCdroid 2.2.0 Idioma Preview 2

Base aprovada em 9 de agosto de 2026, substituindo a **MyMCdroid 2.2.0 — Fluid Action Bar Preview 1** como ponto de partida oficial.

## Identificação

- Nome da base: **MyMCdroid 2.2.0 — Idioma Preview 2**
- Versão interna: `2.2.0-IdiomaPreview2`
- Código da versão: `35`
- Pacote aprovado: `MyMCdroid-2.2.0-IdiomaPreview2.zip`

## Estado consolidado

- Todas as funcionalidades, correções de desempenho, animações, identidade visual, Manual e conteúdo da aba Sobre das bases anteriores permanecem preservados.
- **Português (Brasil)** é o idioma padrão do aplicativo.
- **English (United States)** está disponível na aba da engrenagem.
- Os idiomas são identificados pelas bandeiras do Brasil e dos Estados Unidos.
- A preferência de idioma permanece salva entre os usos do aplicativo.
- Tela principal, barra de ações, diálogos, avisos, progresso, Manual e Sobre possuem recursos em português e inglês.
- O Memory Card aberto é restaurado após a troca de idioma.
- Foi corrigida a `ClassCastException` que fechava o aplicativo ao tocar no botão **Informações**.
- O pacote oficial contém somente o projeto-fonte, sem APK, AAB ou diretórios de compilação.

Todas as próximas alterações deverão partir desta base.

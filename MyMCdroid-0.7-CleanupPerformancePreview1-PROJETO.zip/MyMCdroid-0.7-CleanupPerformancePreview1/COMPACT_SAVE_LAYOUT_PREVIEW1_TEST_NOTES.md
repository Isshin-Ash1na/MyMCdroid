# MyMCdroid 2.2.0 — Compact Save Layout Preview 1

## Pontos principais para teste

1. Toque no ícone do Memory Card e confirme que as ações aparecem horizontalmente.
2. Abra ou crie um Memory Card e confirme que o painel com nome, saves, espaço livre e Importar surge ao lado do ícone.
3. Confirme que a lista de saves não é deslocada quando o painel aparece ou desaparece.
4. Selecione saves diferentes e confirme que somente o ícone 3D selecionado rotaciona.
5. Confirme que Exportar e Excluir aparecem juntos somente no save selecionado.
6. Teste a importação e a sobrescrita de saves PSU, MAX, CBS, SPS e XPS.

## Observação

Este pacote contém somente o projeto para Android Studio. Nenhum APK compilado foi incluído.

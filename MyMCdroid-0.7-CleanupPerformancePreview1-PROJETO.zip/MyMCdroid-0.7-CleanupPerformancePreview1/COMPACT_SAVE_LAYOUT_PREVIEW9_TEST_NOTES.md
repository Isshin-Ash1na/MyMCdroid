# MyMCdroid 2.2.0 — Compact Save Layout Preview 9

## Regra principal

A seleção de um Game Save não deve alterar, recarregar, apagar ou substituir a renderização dos demais.

## Teste de alternância rápida

1. Abra um Memory Card com vários Game Saves e aguarde o carregamento inicial dos ícones.
2. Memorize ou fotografe os ícones associados a algumas linhas.
3. Alterne rapidamente entre vários Game Saves durante pelo menos dois minutos.
4. Misture toques na linha e diretamente no ícone 3D.
5. Role a lista para cima e para baixo durante as alternâncias.
6. Confirme que somente o Game Save anterior para de girar e o novo começa a girar.
7. Confirme que os demais ícones permanecem estáticos e associados às linhas corretas.
8. Toque repetidamente no Game Save já selecionado e confirme que nada reinicia.
9. Verifique que Exportar e Apagar animam somente na nova seleção.

## Mudança técnica desta versão

- A seleção não atualiza mais toda a lista.
- Somente as linhas anterior e atual recebem mudanças visuais.
- Novos payloads são vinculados diretamente apenas às linhas correspondentes.
- As proteções de geração, contexto WebGL e reutilização de recursos permanecem ativas.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

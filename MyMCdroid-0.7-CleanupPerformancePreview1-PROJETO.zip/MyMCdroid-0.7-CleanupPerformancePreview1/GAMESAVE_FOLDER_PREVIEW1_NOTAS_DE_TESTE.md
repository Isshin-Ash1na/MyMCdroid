# MyMCdroid 0.3 — Game Save em Pasta Preview 1

## Alterações principais

- Importação de Game Saves em pastas compatíveis com ARMSX2 e PCSX2.
- Exportação individual, em lote e total no formato Pasta.
- Preservação dos arquivos internos, datas, modos e atributos do Game Save.
- Sobrescrita continua identificando Game Saves por Serial ID e Região.
- Formatos PSU, MAX, CBS, SPS e XPS permanecem disponíveis.
- `_pcsx2_meta` somente é criado quando nomes, modos ou atributos especiais exigem metadados adicionais.
- Pastas antigas que já possuem `_pcsx2_meta` ou `_pcsx2_meta_directory` continuam sendo aceitas.

## Testes sugeridos

1. Abra ou crie um Memory Card em imagem e importe uma pasta de Game Save do ARMSX2/PCSX2.
2. Confirme nome, ícone, arquivos internos, data, hora e tamanho no MyMCdroid.
3. Exporte o Game Save no formato Pasta e copie a pasta resultante para um Memory Card em pasta do emulador.
4. Confirme o reconhecimento no ARMSX2, AetherSX2/NetherSX2 ou PCSX2.
5. Importe novamente a pasta exportada e verifique a sobrescrita do Game Save existente.
6. Repita a exportação usando as opções em lote e Exportar Todos os Save Games.
7. Verifique que um Game Save comum contém `_pcsx2_index`, mas não cria `_pcsx2_meta` sem necessidade.

## Validações realizadas

- Compilação Android `compileDebugKotlin`: aprovada.
- Estrutura de recursos em português e inglês: aprovada.
- Importação e exportação usando o Memory Card real fornecido do ARMSX2: aprovada.
- Comparação byte a byte dos arquivos internos após o ciclo pasta → Memory Card → pasta: aprovada.
- Regressão de PSU, MAX, CBS, SPS e XPS: aprovada.

Este ZIP contém somente o projeto-fonte. O APK compilado não está incluído.

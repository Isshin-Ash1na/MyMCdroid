# MyMCdroid 2.2.0 — Compact Save Layout Preview 6

## Manual

Confira os textos:

- Criar Memory Card: “Cria um novo Memory Card vazio após confirmação.”
- Sair do App: “Fecha completamente o MyMCdroid após confirmação.”
- Exportar Save Game: “Aparece ao selecionar um Save Game e permite exportá-lo no formato .PSU.”
- Apagar Save Game: “Aparece ao selecionar um Save Game e permite removê-lo permanentemente após confirmação.”

Verifique também a padronização das demais descrições para “Game Save” e “Save Games”.

## Apagar todos os Save Games

1. Confira o ícone vermelho depois de abrir ou criar um Memory Card.
2. O desenho deve apresentar uma lixeira vermelha com contorno azul-escuro e “X” branco.
3. Verifique sua legibilidade no botão e no Manual.
4. Confirme que a função continua exigindo duas confirmações.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

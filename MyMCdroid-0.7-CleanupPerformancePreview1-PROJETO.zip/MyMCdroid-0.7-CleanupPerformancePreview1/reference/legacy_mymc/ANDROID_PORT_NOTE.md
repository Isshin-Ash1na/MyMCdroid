# Código original de referência

Esta pasta preserva a implementação desktop histórica do `mymc`, escrita para Python 2.

Ela não é importada nem empacotada pelo aplicativo Android. O núcleo ativo e compatível com Python 3 está em `app/src/main/python`, enquanto os testes de regressão ficam em `tools/python_tests`.

# MyMCdroid 2.2.0 — Expanded Save Preview 1

## Roteiro de testes

1. Abra um Memory Card e selecione um Game Save.
2. Toque novamente no ícone 3D do Game Save selecionado.
3. Confirme que o modal ampliado mostra o ícone, nome, Serial ID e região.
4. Pause a rotação e arraste horizontalmente para girar o modelo manualmente.
5. Retome a rotação e feche pelo X, botão Voltar e toque externo.
6. Confirme que abrir e fechar o modal não altera os renders da lista.
7. No modo em lote, confirme que tocar no ícone apenas marca ou desmarca o Game Save.
8. Ative e encerre o modo em lote várias vezes e verifique se os botões desaparecem em uma única animação.
9. Repita alternando rapidamente entre diferentes Game Saves.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

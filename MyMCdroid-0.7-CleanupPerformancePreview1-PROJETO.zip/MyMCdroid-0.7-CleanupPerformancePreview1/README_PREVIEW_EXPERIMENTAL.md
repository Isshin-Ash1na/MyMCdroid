# myMC Android — v1.1 experimental selected-save preview

Base: mymc Android v1.0 (Serial ID + região + overwrite).

This build intentionally keeps the preview isolated from application startup:
- no OpenGL/EGL initialization in `onCreate()`;
- the preview view is created as a normal Android `View`;
- selecting a save updates only the preview and never blocks delete/export;
- if preview code fails, save-card operations remain usable.

The v1.0 ZIP remains the stable rollback point.

On a different computer, Android Studio should recreate `local.properties` with the local Android SDK path. Do not copy the old machine's `local.properties`.


## v1.1.4 — fundo PS2
- Fundo da caixa de renderização alterado para cinza claro, inspirado no gerenciador de Memory Card do PS2.
- Texto do preview ajustado para manter contraste.

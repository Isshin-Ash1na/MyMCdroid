# MyMCdroid 2.2.0 — Static Icon Cache Preview 1

Revisão Fix 2: preserva a correção do daemon da Fix 1 e converte `parsePayload` para corpo de bloco compatível com o compilador Kotlin 2.0.21 usado pelo projeto.

Build de teste em código-fonte, sem APK compilado.

## Alterações

- Miniaturas da lista passam a ser imagens estáticas geradas localmente e mantidas em cache.
- Apenas o Game Save selecionado usa o renderizador 3D animado; a visualização ampliada continua independente.
- A seleção, a rolagem e a abertura/fechamento do render ampliado não recriam os ícones das outras linhas.
- Ícone de ampliar 3D alterado para branco.
- No modo em lote, permanecem visíveis: Abrir Memory Card, Criar Memory Card, Fechar Memory Card e Importar Save Games.
- No modo em lote, somem apenas: Exportar todos os Save Games, Formatar Memory Card e as ações individuais Exportar/Remover Game Save.
- O toque no ícone do Memory Card volta a retrair e restaurar, em conjunto, a barra de funções e a lista de Game Saves.
- Manual reorganizado por cores: brancos, azuis, verdes, laranja e vermelhos; Sair do App é o último item.

## Testes prioritários

1. Abra um Memory Card com muitos Game Saves e role rapidamente a lista várias vezes.
2. Alterne rapidamente entre miniaturas e confirme que os demais ícones não piscam, somem ou são trocados.
3. Abra e feche repetidamente a visualização 3D ampliada.
4. Ative o modo em lote e confirme que Abrir, Criar, Fechar e Importar continuam disponíveis.
5. Toque no ícone do Memory Card duas vezes e confira a retração/restauração sincronizada da barra e dos Game Saves.
6. Confira a ordem cromática do Manual nos idiomas Brasileiro e Inglês.

## Observação

Se um Game Save não possuir PS2ICON válido, a miniatura mantém o fundo azul estável, sem texto de erro sobre a lista.

# Regra de sobrescrita por jogo

A importação agora considera a identidade do save como:

**Serial ID normalizado + região**

Os prefixos usados por MAX Drive, SharkPort/X-Port e CodeBreaker (por exemplo `BASLUS-`, `BASCUS-`, `BESLES-`, `BESCES-`, `BISLPS-` e `BISLPM-`) são normalizados para o Serial ID do jogo (`SLUS-`, `SCUS-`, `SLES-`, `SCES-`, `SLPS-` e `SLPM-`).

Assim, um save importado como `BASCUS-97481GOWII` e outro importado como `God Of War II` são considerados o mesmo jogo quando ambos resultam em `SCUS-97481 / NTSC-U`.

Quando já existem vários saves com o mesmo Serial ID + região, a nova importação remove todos os correspondentes e grava somente o save importado. Isso evita duplicações causadas pela mistura de `.CBS`, `.SPS`, `.XPS`, `.MAX` e `.PSU`.

Serial/região vazios ou desconhecidos **não** são usados para sobrescrever outros saves.

# MyMCdroid 2.2.0 Layout Preview 3 — Ícones

Base: Layout Preview 2.

## Alterações
- O antigo ícone de Fechar Memory Card foi reciclado como novo ícone de Criar Memory Card.
- O novo ícone de Fechar Memory Card utiliza a folha/cartão do antigo Criar MC.
- O símbolo `+` foi substituído por um `X` centralizado.
- Cores, dimensões, espessura visual e funções dos botões foram preservadas.
- Nenhuma outra alteração de layout ou funcionalidade foi realizada.

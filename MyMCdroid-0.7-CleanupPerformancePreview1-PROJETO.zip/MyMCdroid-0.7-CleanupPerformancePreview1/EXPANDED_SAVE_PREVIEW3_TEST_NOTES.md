# MyMCdroid 2.2.0 — Expanded Save Preview 3

## Roteiro de testes

1. Selecione um Game Save e toque rapidamente três ou mais vezes no ícone.
2. Confirme que apenas uma visualização ampliada é aberta.
3. Feche o modal e confirme que uma nova visualização pode ser aberta normalmente.
4. Verifique se todas as miniaturas retornam após fechar o modal.
5. Ative o modo em lote e observe Abrir e Criar deslocando-se suavemente.
6. Selecione e desmarque vários Game Saves; a barra não deve repetir sua animação.
7. Encerre o modo em lote e confirme o retorno suave dos botões à posição original.
8. Repita rapidamente a ativação e o encerramento do modo em lote.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

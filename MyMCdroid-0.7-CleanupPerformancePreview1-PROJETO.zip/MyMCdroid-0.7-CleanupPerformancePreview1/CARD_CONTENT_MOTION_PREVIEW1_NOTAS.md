# Card Content Motion Preview 1

Prévia baseada na base oficial `2.2.0-StaticIconCachePreview1-Fix2`.

## Alteração

- Retração e aparição da barra de funções e dos Game Saves sincronizadas ao tocar no ícone do Memory Card.
- A altura da barra deixa de mudar durante o movimento visível, evitando o salto de layout.
- Game Saves mantêm entrada e saída sequenciais, com duração e interpolação suavizadas.
- Cliques repetidos e rolagem ficam temporariamente bloqueados durante a transição.
- O carregamento tardio de miniaturas respeita o estado retraído e não reabre a lista sozinho.

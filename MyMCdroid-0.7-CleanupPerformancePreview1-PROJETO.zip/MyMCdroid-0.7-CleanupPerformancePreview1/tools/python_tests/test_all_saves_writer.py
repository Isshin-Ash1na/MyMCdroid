from pathlib import Path
import hashlib, shutil, tempfile
from mymc_core import open_card
from mymc_export import export_psu
from ps2_writer import WritableCard

CARD=Path('/mnt/data/mcd001 (1).ps2')
card=open_card(CARD)
results=[]
with tempfile.TemporaryDirectory(prefix='mymc-all-') as td:
    td=Path(td)
    for idx,save in enumerate(card.saves(),1):
        psu=td/f'{idx}.psu'; dst=td/f'{idx}.ps2'
        export_psu(card,save,psu); shutil.copy2(CARD,dst)
        expected={x['name']:hashlib.sha256(card.extract_file(x['first_cluster'],x['size'])).hexdigest() for x in card.save_files(save)}
        WritableCard(CARD,dst).import_psu(psu,f'RT_{idx:02d}')
        c2=open_card(dst); imported=next(s for s in c2.saves() if s.name==f'RT_{idx:02d}')
        actual={x['name']:hashlib.sha256(c2.extract_file(x['first_cluster'],x['size'])).hexdigest() for x in c2.save_files(imported)}
        ok=(expected==actual and not c2.check())
        results.append((save.name,len(expected),ok))
        if not ok: raise SystemExit(f'FAILED {save.name}')
print(f'{sum(x[2] for x in results)}/{len(results)} saves passed')
for x in results: print(x)

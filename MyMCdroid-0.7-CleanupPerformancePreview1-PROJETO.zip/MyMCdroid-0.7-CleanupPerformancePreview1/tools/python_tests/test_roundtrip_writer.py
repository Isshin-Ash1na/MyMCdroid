from pathlib import Path
import hashlib, shutil, tempfile
from mymc_core import open_card
from mymc_export import export_psu
from ps2_writer import WritableCard
from ps2_ecc import ecc_check_page, ECC_CHECK_FAILED

CARD=Path('/mnt/data/mcd001 (1).ps2')
SAVE='BASLUS-20694'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

card=open_card(CARD)
save=next(s for s in card.saves() if s.name==SAVE)
expected={x['name']:hashlib.sha256(card.extract_file(x['first_cluster'],x['size'])).hexdigest()
          for x in card.save_files(save)}
source_hash=sha(CARD)

with tempfile.TemporaryDirectory() as td:
    td=Path(td); psu=td/'save.psu'; dst=td/'copy.ps2'
    export_psu(card,save,psu)
    shutil.copy2(CARD,dst)
    before=sha(dst)
    imported=WritableCard(CARD,dst).import_psu(psu,'ROUNDTRIP_TEST')
    c2=open_card(dst)
    imported_save=next(s for s in c2.saves() if s.name=='ROUNDTRIP_TEST')
    actual={x['name']:hashlib.sha256(c2.extract_file(x['first_cluster'],x['size'])).hexdigest()
            for x in c2.save_files(imported_save)}
    fat_errors=c2.check()
    # Check ECC only on physical pages changed by the writer.
    src=Path(CARD).read_bytes(); mod=Path(dst).read_bytes()
    raw_page=528; page=512; changed=[]; ecc_failed=[]
    for n in range(len(src)//raw_page):
        a=n*raw_page; b=a+raw_page
        if src[a:b] != mod[a:b]:
            changed.append(n)
            data=bytearray(mod[a:a+page]); spare=bytearray(mod[a+page:b])
            r,_,_=ecc_check_page(data,spare)
            if r==ECC_CHECK_FAILED: ecc_failed.append(n)
    result={
      'imported_files': imported,
      'file_hashes_equal': expected==actual,
      'fat_errors': fat_errors,
      'changed_physical_pages': len(changed),
      'ecc_failed_pages': ecc_failed,
      'source_unchanged': sha(CARD)==source_hash,
      'destination_was_source_copy': before==source_hash,
      'roundtrip_ok': expected==actual and not fat_errors and not ecc_failed and sha(CARD)==source_hash,
    }
    print(result)
    if not result['roundtrip_ok']:
        raise SystemExit(1)

"""Regression checks for PCSX2-compatible folder Memory Cards."""
from __future__ import annotations

import tempfile
import shutil
import json
from pathlib import Path

from folder_card import (
    DIRECTORY_META_NAME,
    FILE_META_DIR,
    INDEX_NAME,
    MAGIC,
    SUPERBLOCK_BLOCK_SIZE,
    SUPERBLOCK_NAME,
    FolderCardWriter,
    _load_index,
    create_folder_card,
    load_folder_save,
    write_folder_save,
)
from mymc_core import open_card
from mymc_api import (
    _folder_card_host_name,
    create_card,
    export_save_folder,
    import_save_any,
    list_save_files,
    read_save_file,
    replace_save_file,
    transfer_saves,
)
from mymc_export import export_any
from ps2_writer import valid_tod
from save_formats import ImportedFile, ImportedSave, load_any


SAVE_NAME = "BASLUS-99998FOLDER"
SECOND_SAVE_NAME = "BASLUS-88888FOLDER"
CREATED = (9, 8, 7, 6, 5, 2024)
MODIFIED = (19, 18, 17, 16, 7, 2025)
FILES = [
    ImportedFile(
        "icon.sys",
        b"PS2D" + bytes(range(64)),
        created=CREATED,
        modified=MODIFIED,
        attr=0x10203040,
    ),
    ImportedFile(
        "DATA.BIN",
        bytes(range(256)) * 9,
        created=CREATED,
        modified=MODIFIED,
        attr=0x50607080,
    ),
]
SOURCE = ImportedSave(
    SAVE_NAME,
    FILES,
    created=CREATED,
    modified=MODIFIED,
    attr=0x12345678,
)
STANDARD_FILES = [
    ImportedFile("icon.sys", b"PS2D" + bytes(range(64)), created=CREATED, modified=MODIFIED),
    ImportedFile("DATA.BIN", bytes(range(64)) * 11, created=CREATED, modified=MODIFIED),
]
STANDARD_SOURCE = ImportedSave(
    SAVE_NAME,
    STANDARD_FILES,
    created=CREATED,
    modified=MODIFIED,
)


def assert_folder_save(
    card_path: Path,
    expected_data: dict[str, bytes],
    exact_times: bool = False,
):
    card = open_card(card_path)
    assert getattr(card, "is_folder_card", False)
    assert card.check() == []
    assert card.stats()["dynamic"] is True
    matching = [save for save in card.saves() if save.name == SAVE_NAME]
    assert len(matching) == 1
    save = matching[0]
    entries = card.save_files(save)
    actual = {
        entry["name"]: card.extract_file(entry["first_cluster"], entry["size"])
        for entry in entries
    }
    assert actual == expected_data
    assert all(valid_tod(entry["created"]) for entry in entries)
    assert all(valid_tod(entry["modified"]) for entry in entries)
    if exact_times:
        assert all(entry["created"] == CREATED for entry in entries)
        assert all(entry["modified"] == MODIFIED for entry in entries)

    save_folder = card_path / SAVE_NAME
    assert (save_folder / INDEX_NAME).is_file()
    if exact_times:
        assert (save_folder / DIRECTORY_META_NAME).stat().st_size == 512
        assert (save_folder / FILE_META_DIR / "icon.sys").stat().st_size == 512
    return card, save


def run():
    expected_data = {item.name: item.data for item in FILES}
    with tempfile.TemporaryDirectory(prefix="mymcdroid_folder_card_test_") as temp:
        root = Path(temp)
        blank = root / "blank-folder-card"
        create_folder_card(blank)
        superblock = (blank / SUPERBLOCK_NAME).read_bytes()
        assert len(superblock) == SUPERBLOCK_BLOCK_SIZE
        assert superblock.startswith(MAGIC)
        assert superblock[512:] == b"\xff" * (SUPERBLOCK_BLOCK_SIZE - 512)

        # Match the compact one-line index emitted by current ARMSX2 builds.
        armsx2_index = root / "armsx2-index"
        armsx2_index.write_text(
            "{$ROOT: {timeCreated: 1700000000,timeModified: 1700000001},"
            "BASLUS-20694: {order: 1,timeCreated: 1700000002,"
            "timeModified: 1700000003}}\n",
            encoding="utf-8",
        )
        parsed = _load_index(armsx2_index)
        assert parsed["$ROOT"]["timeCreated"] == 1700000000
        assert parsed["BASLUS-20694"]["order"] == 1

        # Normal folders created by PCSX2/ARMSX2 do not contain _pcsx2_meta.
        # MyMCdroid must emit the same minimal structure and still import it.
        standard_export = root / SAVE_NAME
        write_folder_save(
            standard_export,
            STANDARD_SOURCE.files,
            STANDARD_SOURCE.name,
            save_metadata=STANDARD_SOURCE,
            host_directory_name=SAVE_NAME,
        )
        assert (standard_export / INDEX_NAME).is_file()
        assert not (standard_export / DIRECTORY_META_NAME).exists()
        assert not (standard_export / FILE_META_DIR).exists()
        loaded_standard = load_folder_save(standard_export)
        assert loaded_standard.name == SAVE_NAME
        assert {
            item.name: item.data for item in loaded_standard.files
        } == {item.name: item.data for item in STANDARD_FILES}

        standard_card = root / "standard-folder-card"
        FolderCardWriter(blank, standard_card).import_files(
            STANDARD_SOURCE.files,
            STANDARD_SOURCE.name,
            save_metadata=STANDARD_SOURCE,
        )
        standard_card_save = standard_card / SAVE_NAME
        assert not (standard_card_save / DIRECTORY_META_NAME).exists()
        assert not (standard_card_save / FILE_META_DIR).exists()

        standard_blank_image = root / "standard-blank.ps2"
        standard_imported_image = root / "standard-imported.ps2"
        create_card(str(standard_blank_image), 8)
        folder_import_result = json.loads(import_save_any(
            str(standard_blank_image),
            str(standard_export),
            str(standard_imported_image),
        ))
        assert folder_import_result["files"] == len(STANDARD_FILES)
        assert [
            item.name for item in open_card(standard_imported_image).saves()
        ] == [SAVE_NAME]

        # Android's multi-folder picker selects the parent directory. The app
        # sorts its child folders and feeds them through this same transaction
        # one by one, so each commit becomes the source for the next import.
        second_export = root / SECOND_SAVE_NAME
        second_source = ImportedSave(
            SECOND_SAVE_NAME,
            [
                ImportedFile(
                    item.name,
                    item.data + b"-second",
                    created=item.created,
                    modified=item.modified,
                )
                for item in STANDARD_FILES
            ],
            created=CREATED,
            modified=MODIFIED,
        )
        write_folder_save(
            second_export,
            second_source.files,
            second_source.name,
            save_metadata=second_source,
            host_directory_name=SECOND_SAVE_NAME,
        )
        batch_second_image = root / "batch-second.ps2"
        second_result = json.loads(import_save_any(
            str(standard_imported_image),
            str(second_export),
            str(batch_second_image),
        ))
        assert second_result["files"] == len(STANDARD_FILES)
        assert sorted(
            item.name for item in open_card(batch_second_image).saves()
        ) == sorted([SAVE_NAME, SECOND_SAVE_NAME])

        exported_again = root / "exported-again"
        folder_export_result = json.loads(export_save_folder(
            str(standard_imported_image),
            SAVE_NAME,
            str(exported_again),
        ))
        assert folder_export_result["folder_name"] == SAVE_NAME
        assert not (exported_again / DIRECTORY_META_NAME).exists()
        assert not (exported_again / FILE_META_DIR).exists()
        assert {
            item.name: item.data for item in load_folder_save(exported_again).files
        } == {item.name: item.data for item in STANDARD_FILES}

        legacy = root / "legacy-short-superblock"
        shutil.copytree(blank, legacy)
        legacy_superblock = legacy / SUPERBLOCK_NAME
        legacy_superblock.write_bytes(legacy_superblock.read_bytes()[:512])
        upgraded = root / "upgraded-short-superblock"
        FolderCardWriter(legacy, upgraded)
        assert (upgraded / SUPERBLOCK_NAME).stat().st_size == SUPERBLOCK_BLOCK_SIZE

        seeded = root / "seeded-folder-card"
        FolderCardWriter(blank, seeded).import_files(
            SOURCE.files,
            SOURCE.name,
            save_metadata=SOURCE,
        )
        card, save = assert_folder_save(seeded, expected_data, exact_times=True)
        assert (seeded / SAVE_NAME / INDEX_NAME).read_text(
            encoding="utf-8"
        ).startswith("{$ROOT:")

        # ARMSX2/PCSX2 filter physical folder names before reading the logical
        # name from metadata. Friendly container names therefore receive a
        # serial-bearing host folder while remaining unchanged in the UI.
        friendly_name = "Friendly Game Save"
        filtered_host = _folder_card_host_name(friendly_name, "SLUS-99998")
        assert "SLUS-99998" in filtered_host
        filtered = root / "filtered-folder-card"
        FolderCardWriter(blank, filtered).import_files(
            SOURCE.files,
            friendly_name,
            save_metadata=SOURCE,
            host_directory_name=filtered_host,
        )
        filtered_card = open_card(filtered)
        assert [item.name for item in filtered_card.saves()] == [friendly_name]
        assert filtered_card.save_path(friendly_name).name == filtered_host

        for format_name in ("psu", "max", "cbs", "sps", "xps"):
            container = root / f"roundtrip.{format_name}"
            export_any(card, save, container, format_name)
            imported = load_any(container)
            assert imported.name == SAVE_NAME
            assert {item.name: item.data for item in imported.files} == expected_data

            reimported = root / f"reimported-{format_name}"
            FolderCardWriter(blank, reimported).import_files(
                imported.files,
                imported.name,
                save_metadata=imported,
            )
            assert_folder_save(reimported, expected_data)

            overwritten = root / f"overwritten-{format_name}"
            FolderCardWriter(reimported, overwritten).import_files(
                imported.files,
                imported.name,
                replace_existing=True,
                replace_names=[imported.name],
                save_metadata=imported,
            )
            assert_folder_save(overwritten, expected_data)

        removed = root / "removed-folder-card"
        assert FolderCardWriter(seeded, removed).delete_save(SAVE_NAME) == SAVE_NAME
        assert open_card(removed).saves() == []

        formatted = root / "formatted-folder-card"
        assert FolderCardWriter(seeded, formatted).delete_all_saves() == 1
        assert open_card(formatted).saves() == []

        transferred = root / "transferred-folder-card"
        result = json.loads(transfer_saves(
            str(seeded),
            str(blank),
            json.dumps([SAVE_NAME]),
            str(transferred),
        ))
        assert result["count"] == 1
        assert [item.name for item in open_card(transferred).saves()] == [SAVE_NAME]
        assert_folder_save(transferred, expected_data, exact_times=True)
        assert [item.name for item in open_card(seeded).saves()] == [SAVE_NAME]

        blank_image = root / "blank-image.ps2"
        image_with_save = root / "image-with-save.ps2"
        create_card(str(blank_image), 8)
        image_result = json.loads(transfer_saves(
            str(seeded),
            str(blank_image),
            json.dumps([SAVE_NAME]),
            str(image_with_save),
        ))
        assert image_result["count"] == 1
        assert [item.name for item in open_card(image_with_save).saves()] == [SAVE_NAME]

        folder_from_image = root / "folder-from-image"
        reverse_result = json.loads(transfer_saves(
            str(image_with_save),
            str(blank),
            json.dumps([SAVE_NAME]),
            str(folder_from_image),
        ))
        assert reverse_result["count"] == 1
        assert_folder_save(folder_from_image, expected_data, exact_times=True)

        listed = json.loads(list_save_files(str(seeded), SAVE_NAME))
        assert [item["name"] for item in listed] == ["DATA.BIN", "icon.sys"]
        assert read_save_file(str(seeded), SAVE_NAME, "DATA.BIN") == expected_data["DATA.BIN"]
        replacement = root / "replacement.bin"
        replacement.write_bytes(b"replacement-data" * 37)
        replaced_folder = root / "replaced-folder-card"
        replace_save_file(
            str(seeded), SAVE_NAME, "DATA.BIN", str(replacement), str(replaced_folder)
        )
        replaced_card = open_card(replaced_folder)
        replaced_save = next(item for item in replaced_card.saves() if item.name == SAVE_NAME)
        replaced_files = {
            item["name"]: replaced_card.extract_file(item["first_cluster"], item["size"])
            for item in replaced_card.save_files(replaced_save)
        }
        assert replaced_files["DATA.BIN"] == replacement.read_bytes()
        assert replaced_files["icon.sys"] == expected_data["icon.sys"]

        replaced_image = root / "replaced-image.ps2"
        replace_save_file(
            str(image_with_save), SAVE_NAME, "DATA.BIN", str(replacement), str(replaced_image)
        )
        assert read_save_file(str(replaced_image), SAVE_NAME, "DATA.BIN") == replacement.read_bytes()

    print("folder card: create/import/export/overwrite/delete/format/transfer OK")


if __name__ == "__main__":
    run()

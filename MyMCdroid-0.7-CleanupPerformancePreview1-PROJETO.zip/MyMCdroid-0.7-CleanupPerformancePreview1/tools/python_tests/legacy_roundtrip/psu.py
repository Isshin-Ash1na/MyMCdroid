from __future__ import annotations
import struct
from dataclasses import dataclass

ENTRY_SIZE = 512
CLUSTER = 1024
DF_FILE = 0x10
DF_DIR = 0x20
DF_EXISTS = 0x8000

@dataclass
class PSUFile:
    name: str
    size: int
    data: bytes

class PSUError(ValueError):
    pass

def _name(b: bytes) -> str:
    return b.split(b"\0", 1)[0].decode("shift_jis", "replace")

def _ent(b: bytes):
    if len(b) != ENTRY_SIZE:
        raise PSUError("PSU entry truncada")
    mode, unused, size, tod, unknown, cluster, _, _, name = struct.unpack(
        "<HHL8sLL8sL28x448s", b)
    return mode, size, _name(name), tod

def load_ems(path):
    with open(path, "rb") as f:
        raw = f.read()
    off = 0
    def take(n):
        nonlocal off
        if off + n > len(raw):
            raise PSUError("PSU truncado")
        x = raw[off:off+n]
        off += n
        return x

    root = _ent(take(ENTRY_SIZE))
    dot = _ent(take(ENTRY_SIZE))
    dotdot = _ent(take(ENTRY_SIZE))
    if root[1] < 2:
        raise PSUError("Número de entradas inválido")
    if not (root[0] & DF_DIR) or not (root[0] & DF_EXISTS):
        raise PSUError("Directório raiz inválido")
    files = []
    for _ in range(root[1] - 2):
        mode, size, name, tod = _ent(take(ENTRY_SIZE))
        if mode & DF_DIR:
            raise PSUError("PSU contém subdirectório")
        if not (mode & DF_FILE) or not (mode & DF_EXISTS):
            raise PSUError("Entrada de ficheiro inválida")
        data = take(size)
        off += (-size) % CLUSTER
        if off > len(raw):
            raise PSUError("Padding do PSU truncado")
        files.append(PSUFile(name, size, data))
    if off != len(raw):
        raise PSUError("Dados extra no fim do PSU")
    return root[1] - 2, files

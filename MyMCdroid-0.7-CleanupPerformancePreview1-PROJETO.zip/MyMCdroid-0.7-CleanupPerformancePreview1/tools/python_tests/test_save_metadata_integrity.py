"""Regression checks for PS2 Browser date/time and size compatibility."""
from __future__ import annotations

import tempfile
from pathlib import Path

from mymc_core import open_card
from mymc_export import export_any
from ps2_formatter import create_memory_card
from ps2_writer import FAT_END, WritableCard, unpack_ent, valid_tod
from save_formats import ImportedFile, ImportedSave, load_any


SAVE_NAME = "BASLUS-99999METADATA"
CREATED = (9, 8, 7, 6, 5, 2024)
MODIFIED = (19, 18, 17, 16, 7, 2025)
FILES = [
    ImportedFile(
        "icon.sys", b"PS2D" + bytes(range(64)),
        created=CREATED, modified=MODIFIED, attr=0x10203040,
    ),
    ImportedFile(
        "DATA.BIN", bytes(range(256)) * 9,
        created=CREATED, modified=MODIFIED, attr=0x50607080,
    ),
]
SOURCE = ImportedSave(
    SAVE_NAME, FILES, created=CREATED, modified=MODIFIED, attr=0x12345678
)


def assert_save_structure(card_path: Path, expected_name: str, expected_data: dict):
    assert open_card(card_path).check() == []
    reader = WritableCard(card_path, card_path.with_suffix(".unused"))
    root_count = unpack_ent(reader.read_alloc0())[2]
    root = reader.read_dir(reader.root_cluster, root_count)
    matches = [(index, entry) for index, entry in enumerate(root)
               if entry[8] == expected_name and entry[0] & 0x8000]
    assert len(matches) == 1
    root_index, save = matches[0]
    assert save[5] == 0
    assert valid_tod(save[3]) and valid_tod(save[6])

    children = reader.read_dir(save[4], save[2])
    assert children[0][8] == "."
    assert (children[0][4], children[0][5]) == (reader.root_cluster, root_index)
    assert children[1][8] == ".."
    assert (children[1][4], children[1][5]) == (0, 0)

    actual = {}
    for entry in children[2:]:
        assert entry[5] == 0
        assert valid_tod(entry[3]) and valid_tod(entry[6])
        clusters = (entry[2] + reader.cluster_size - 1) // reader.cluster_size
        assert len(reader.chain(entry[4])) == clusters
        actual[entry[8]] = reader.read_file(entry[4], entry[2]) if entry[4] != FAT_END else b""
    assert actual == expected_data
    return save, children


def run():
    expected_data = {item.name: item.data for item in FILES}
    with tempfile.TemporaryDirectory(prefix="mymcdroid_metadata_test_") as temp:
        folder = Path(temp)
        blank = folder / "blank.ps2"
        seeded = folder / "seeded.ps2"
        create_memory_card(str(blank))
        WritableCard(blank, seeded).import_files(
            SOURCE.files, SOURCE.name, save_metadata=SOURCE
        )
        save, children = assert_save_structure(seeded, SAVE_NAME, expected_data)
        assert save[3] == CREATED and save[6] == MODIFIED
        assert save[7] == SOURCE.attr
        assert children[2][3] == CREATED and children[2][6] == MODIFIED
        assert children[2][7] == FILES[0].attr

        card = open_card(seeded)
        card_save = next(item for item in card.saves() if item.name == SAVE_NAME)
        for format_name in ("psu", "max", "cbs", "sps", "xps"):
            container = folder / f"roundtrip.{format_name}"
            export_any(card, card_save, container, format_name)
            imported = load_any(container)
            assert imported.name == SAVE_NAME
            assert {item.name: item.data for item in imported.files} == expected_data

            first = folder / f"first-{format_name}.ps2"
            create_memory_card(str(blank))
            WritableCard(blank, first).import_files(
                imported.files, imported.name, save_metadata=imported
            )
            assert_save_structure(first, SAVE_NAME, expected_data)

            overwritten = folder / f"overwrite-{format_name}.ps2"
            WritableCard(first, overwritten).import_files(
                imported.files, imported.name, replace_existing=True,
                replace_names=[imported.name], save_metadata=imported
            )
            assert_save_structure(overwritten, SAVE_NAME, expected_data)

    print("save metadata integrity: PSU/MAX/CBS/SPS/XPS import and overwrite OK")


if __name__ == "__main__":
    run()

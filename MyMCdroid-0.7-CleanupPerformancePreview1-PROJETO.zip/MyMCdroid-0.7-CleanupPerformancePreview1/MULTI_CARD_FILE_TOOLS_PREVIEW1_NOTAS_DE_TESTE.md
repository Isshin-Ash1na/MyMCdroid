# MyMCdroid 2.2.0 — MultiCard File Tools Preview 1

## Alterações deste teste

- Seletor visível para alternar entre dois ou mais Memory Cards abertos.
- Troca de Memory Card também por gesto horizontal para a esquerda ou direita.
- Animações de saída e entrada preservadas durante a troca de Memory Card.
- Lista dos arquivos internos do Game Save abaixo do render 3D ampliado.
- Exportação individual do arquivo interno selecionado.
- Substituição individual do arquivo interno selecionado, preservando os demais arquivos e os metadados do Game Save.
- Controles de rotação e animação reorganizados no mesmo padrão visual de reproduzir/pausar.
- Janela de render ampliado deslocada para cima e redimensionada para acomodar os novos comandos.
- Manual atualizado em Português Brasileiro e Inglês.

## Roteiro rápido de teste

1. Abra dois ou mais Memory Cards e confirme que o seletor mostra todos eles.
2. Alterne pelos nomes do seletor e também arrastando a tela para os lados.
3. Selecione um Game Save e abra seu ícone 3D ampliado.
4. Confira a lista de arquivos internos e selecione um item.
5. Exporte esse arquivo e compare o conteúdo/tamanho com o original.
6. Substitua um arquivo por outro arquivo de teste e reabra o Game Save.
7. Confirme que somente o item escolhido mudou e que os demais arquivos continuam presentes.
8. Teste os controles de pausar/retomar rotação e animação.
9. Repita a substituição em um Memory Card `.PS2` e em um Memory Card no modo pasta.

> Esta entrega contém somente o projeto-fonte. Nenhum APK compilado foi incluído.

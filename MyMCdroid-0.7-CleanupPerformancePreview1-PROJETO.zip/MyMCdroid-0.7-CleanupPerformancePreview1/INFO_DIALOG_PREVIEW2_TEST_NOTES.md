# MyMCdroid 2.2.0 — Info Dialog Preview 2

## Alterações

- Cabeçalho reorganizado para impedir sobreposição entre Sobre e Fechar.
- Ordem preservada: Manual → Engrenagem → Sobre → Fechar.
- As três abas ocupam uma área flexível própria.
- Fechar possui espaço exclusivo à direita.
- Botão Fechar reduzido para 36dp, sem caixa ou contorno.
- Ícone Fechar alinhado ao topo direito.
- Animação suave e centralizada da janela de Informações preservada.

## Roteiro de teste

1. Abra Informações em uma tela estreita e confirme que Sobre e Fechar não se sobrepõem.
2. Verifique se Fechar aparece discreto, sem caixa, no canto superior direito.
3. Alterne Manual, Engrenagem e Sobre.
4. Teste o fechamento pelo X e pelo botão Voltar.
5. Repita em retrato e paisagem.

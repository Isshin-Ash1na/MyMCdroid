# Problemas conhecidos — Static Icon Cache Preview 1

## SICP1-001 — Validação em aparelho

- Estado: correção estrutural implementada e aguardando teste no dispositivo.
- Objetivo: confirmar que as miniaturas estáticas eliminam completamente o piscar causado pelos vários contextos WebGL.

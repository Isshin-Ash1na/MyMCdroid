# MyMCdroid 2.2.0 — Memory Card Folder Preview 2

> Nota histórica: esta preview ainda utilizava um `_pcsx2_superblock` de 512
> bytes. Esse formato foi substituído pelo bloco correto de 8.192 bytes na
> Memory Card Folder Preview 3 após comparação com uma amostra real do ARMSX2.

## Correções desta versão

- **Criar Memory Card em pasta** agora solicita primeiro a pasta-pai onde o cartão será criado.
- Em seguida, uma caixa MyMCdroid permite escolher o nome do novo Memory Card.
- A extensão `.ps2` é adicionada automaticamente ao nome da pasta, seguindo a identificação utilizada por ARMSX2 e PCSX2.
- O aplicativo cria uma subpasta nova e não transforma mais a pasta selecionada no próprio Memory Card.
- A criação é bloqueada quando já existe uma pasta com o mesmo nome, evitando sobrescrita acidental.
- Se a preparação falhar, a subpasta incompleta é removida com segurança.
- Diretórios físicos de Game Saves com nomes amigáveis recebem um prefixo interno contendo o Serial ID.
- O nome original continua preservado nos metadados e na interface do MyMCdroid.
- O prefixo interno permite que o filtro de Game Saves do ARMSX2/PCSX2 encontre o conteúdo correspondente ao jogo.

## Teste sugerido no ARMSX2

1. No MyMCdroid, escolha **Criar Memory Card** e depois **Memory Card em pasta (PCSX2)**.
2. Selecione a pasta onde deseja guardar seus Memory Cards.
3. Digite um nome, por exemplo `MemoryCardARMSX2`. O resultado deverá ser a subpasta `MemoryCardARMSX2.ps2`.
4. Importe Game Saves e feche o Memory Card no MyMCdroid.
5. No ARMSX2, adicione ou selecione essa subpasta como um **Folder Memory Card**.
6. Reinicie o jogo para que o ARMSX2 reaplique a configuração e o filtro do Memory Card.
7. Confirme que o jogo reconhece o Game Save correspondente ao seu Serial ID e região.

Não mantenha o mesmo Memory Card aberto para gravação nos dois aplicativos simultaneamente.

## Verificações internas

- Criação e validação do superblock de 512 bytes.
- Importação, exportação, sobrescrita, remoção e formatação.
- Round-trip nos formatos `.PSU`, `.MAX`, `.CBS`, `.SPS` e `.XPS`.
- Nome físico compatível com filtro por serial e nome lógico preservado.
- Validação de recursos XML com o compilador de recursos do Android.

Este pacote contém somente o projeto-fonte. O APK compilado não está incluído.

# Compatibilidade Kotlin — Fix 2

Corrige o erro de compilação em `Ps2IconSnapshotRenderer.kt`:

`Returns are prohibited for functions with an expression body.`

A função `parsePayload` agora utiliza corpo de bloco. Os retornos antecipados usados para escolher o primeiro PS2ICON válido permanecem com o mesmo comportamento, mas são aceitos pelo Kotlin 2.0.21 configurado no projeto.

# Base oficial — MyMCdroid 2.2.0 Compact Save Layout Preview 6

Status: aprovado

Definida como base oficial em 05/08/2026.

## Recursos consolidados

- Otimizações de importação e sobrescrita fora da interface principal.
- Compatibilidade com PSU, MAX, CBS, SPS e XPS.
- Sobrescrita identificada por Serial ID e região.
- Botões Abrir e Criar sempre visíveis e centralizados.
- Botões Fechar e Apagar Todos exibidos após a abertura ou criação do Memory Card.
- Caixa permanente com nome, quantidade de Save Games e espaço livre.
- Botão Importar contextual.
- Lista alfabética com nome em verde, região e tamanho.
- Ícones 3D individuais, seleção pelo ícone e recuperação automática de renderização.
- Exportar e Apagar exibidos somente no Game Save selecionado.
- Função Apagar todos os Save Games com duas confirmações e gravação segura.
- Manual e Sobre preservados com a identidade visual aprovada.

Todas as próximas implementações devem partir desta base, salvo orientação expressa em contrário.

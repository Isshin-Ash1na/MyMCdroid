# MyMCdroid 2.2.0 — MultiCard File Tools Preview 2

## Alteração desta revisão

- O arquivo interno selecionado na visualização ampliada agora recebe fundo azul-escuro, contorno ciano e nome verde.
- Somente um arquivo interno permanece selecionado por vez.
- O destaque da seleção é preservado durante a rolagem da lista.
- Os botões **Exportar arquivo** e **Substituir arquivo** continuam disponíveis somente quando houver um arquivo selecionado.

## Teste rápido

1. Abra um Memory Card e amplie o render de um Game Save.
2. Toque em um arquivo da lista e confira o destaque visual.
3. Selecione outro arquivo e confirme que a seleção anterior desaparece.
4. Role a lista e confirme que o arquivo permanece selecionado.
5. Teste **Exportar arquivo** e **Substituir arquivo** com o item destacado.

> Esta entrega contém somente o projeto-fonte. Nenhum APK compilado foi incluído.

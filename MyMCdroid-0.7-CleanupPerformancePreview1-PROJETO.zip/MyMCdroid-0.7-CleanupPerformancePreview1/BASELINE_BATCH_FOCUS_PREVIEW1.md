# Base oficial — MyMCdroid 2.2.0 Batch Focus Preview 1

Base aprovada em 9 de agosto de 2026, substituindo a **MyMCdroid 2.2.0 — Icon Render Recovery Preview 1** como ponto de partida oficial.

## Identificação

- Nome da base: **MyMCdroid 2.2.0 — Batch Focus Preview 1**
- Versão interna: `2.2.0-BatchFocusPreview1`
- Código da versão: `39`
- Pacote aprovado: `MyMCdroid-2.2.0-BatchFocusPreview1-PROJETO.zip`

## Estado consolidado

- Todas as funcionalidades, correções de desempenho, idiomas, Manual, Sobre e identidade visual das bases anteriores permanecem preservados.
- Ao ativar o modo em lote, somente **Exportar Save Games** e **Remover Save Games** permanecem na barra de ações.
- Abrir, Exportar Todos, Criar, Formatar, Fechar e Importar ficam ocultos e desativados durante o modo em lote.
- As ações disponíveis retornam com animação ao encerrar o modo em lote.
- Selecionar ou desmarcar outros Game Saves não reinicia a animação da barra.
- O Manual registra o comportamento do modo em lote em português e inglês.
- O pacote oficial contém somente o projeto-fonte, sem APK, AAB, caches ou diretórios de compilação.

## Pendências registradas para a próxima sessão

1. Continuar a investigação do piscar simultâneo das miniaturas 3D. As tentativas atuais de estabilização permanecem na base, mas o comportamento ainda ocorre no dispositivo de teste.
2. Alterar para branco o ícone usado para ampliar a visualização 3D.

Todas as próximas alterações deverão partir desta base, preservando essas pendências até sua resolução e aprovação.

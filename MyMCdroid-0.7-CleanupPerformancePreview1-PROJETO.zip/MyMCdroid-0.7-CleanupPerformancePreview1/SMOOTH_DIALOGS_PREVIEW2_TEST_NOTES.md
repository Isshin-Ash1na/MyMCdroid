# MyMCdroid 2.2.0 — Smooth Dialogs Preview 2

## Correção principal

- O diálogo agora usa um tema próprio sem animação lateral do sistema.
- Largura, altura e gravidade central são definidas antes da exibição.
- O painel permanece invisível durante a primeira medição da janela.
- O fade e a escala começam somente após a janela estar centralizada.
- A correção substitui o ajuste da Preview 1, que ainda dimensionava a janela depois de sua exibição.

## Roteiro de teste

1. Teste Abrir e Criar Memory Card repetidamente.
2. Teste Fechar Memory Card, Excluir, Formatar e Sobrescrever.
3. Observe o primeiro quadro de cada popup: ele deve surgir no centro, sem vir da direita.
4. Teste Sim, Não, toque fora do diálogo e o botão Voltar.
5. Repita em dispositivos ou emuladores com versões diferentes do Android.

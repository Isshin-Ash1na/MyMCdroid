# MyMCdroid 2.2.0 — Icon Render Stability Preview 1

## Correção

- A miniatura não reaplica mais o mesmo conteúdo quando o render já está confirmado.
- A recuperação do WebGL agora verifica o resultado já recuperado, sem reconstruir o ícone uma segunda vez.
- Ao retornar para a tela, cada miniatura somente verifica seu estado; ela só é redesenhada se o contexto gráfico realmente tiver sido perdido.
- Ao fechar o render ampliado, as miniaturas são retomadas e verificadas sem uma reaplicação duplicada.
- Linhas não selecionadas não solicitam mais uma renderização extra ao saírem da área visível.
- As tentativas de recuperação permanecem isoladas por Game Save.

## Testes recomendados

1. Abra um Memory Card com muitos Game Saves e mantenha a lista parada por alguns segundos.
2. Role lentamente para baixo e para cima, verificando se os ícones permanecem estáveis.
3. Role rapidamente em ambas as direções.
4. Selecione diferentes Game Saves em sequência.
5. Abra e feche repetidamente o render ampliado.
6. Confirme que somente o ícone selecionado rotaciona e que os demais não piscam.

O pacote do projeto não inclui APK, AAB, caches ou diretórios de compilação.

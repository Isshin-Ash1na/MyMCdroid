# Base oficial — MyMCdroid 2.2.0 Fluid Action Bar Preview 1

Base aprovada em 6 de agosto de 2026.

## Identificação

- Nome da base: **MyMCdroid 2.2.0 — Fluid Action Bar Preview 1**
- Base anterior incorporada: **MyMCdroid 2.2.0 — Import Button Alignment Preview 1**
- Pacote aprovado: `MyMCdroid-2.2.0-FluidActionBarPreview1-Testes.zip`

## Estado consolidado

- Todas as funcionalidades e correções das bases anteriores permanecem preservadas.
- **Formatar Memory Card** e **Fechar Memory Card** possuem entrada e saída fluidas com duração de 1 segundo.
- As funções são desabilitadas imediatamente quando deixam de estar disponíveis, embora os ícones permaneçam visíveis durante a animação de saída.
- As opções em lote seguem a mesma duração e regra de segurança.
- **Abrir Memory Card** e **Criar Memory Card** reposicionam-se progressivamente conforme os outros grupos aparecem ou desaparecem.
- Animações interrompidas podem inverter a direção sem saltos ou repetição visual.
- O botão **Importar Save Games** permanece centralizado e protegido contra deslocamentos residuais.
- A proposta **PS2 Neon Glyph** ainda não integra o aplicativo e permanece reservada para implementação futura.

Todas as próximas alterações deverão partir desta base.

# MyMCdroid 2.2.0 — Import Button Alignment Preview 1

## Correção

- O botão **Importar Save Games** permanece centralizado na área reservada do painel do Memory Card.
- Animações interrompidas ou repetidas não podem mais deixar deslocamento horizontal residual.
- A entrada continua ocorrendo suavemente da direita para a esquerda.
- O botão oculto volta sempre à posição-base antes de uma nova animação.

## Roteiro de testes

1. Abra e feche diferentes Memory Cards repetidamente.
2. Crie um Memory Card e aguarde a entrada do botão **Importar Save Games**.
3. Alterne rapidamente entre abrir, fechar e criar Memory Cards.
4. Importe um ou vários Save Games e confira o alinhamento após a atualização da lista.
5. Entre e saia do modo em lote enquanto o Memory Card permanece aberto.
6. Confirme que o botão continua centralizado e não invade a moldura direita do painel.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

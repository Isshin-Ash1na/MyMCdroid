# MyMCdroid 2.2.0 — Compact Save Layout Preview 3

## Interface

1. Abrir, Criar e Fechar devem permanecer visíveis abaixo da logo desde a inicialização.
2. A caixa azul do Memory Card deve permanecer visível, com o ícone apenas ilustrativo.
3. Importar deve aparecer com animação somente após abrir ou criar um Memory Card.
4. O nome de cada save deve aparecer em verde, acompanhado de região e tamanho.
5. A lista deve estar em ordem alfabética pelo título exibido.
6. A barra de rolagem deve usar o novo acabamento azul.
7. Tocar na linha ou diretamente no ícone 3D deve selecionar o save.
8. O ícone selecionado deve girar mais rapidamente; os demais permanecem estáticos.

## Ícones 3D para conferir

- Mortal Kombat: Shaolin Monks
- God of War II
- Need for Speed Carbon
- Resident Evil 4 — System Data
- Shinobido: Way of the Ninja
- Shadow of Rome
- Resident Evil 4 — New Round
- God Hand
- Crash Bandicoot: The Wrath of Cortex
- Onimusha
- Onimusha 3

Os ícones agora são carregados em lotes menores e o decodificador de texturas RLE foi corrigido.

## Memory Card cheio

Quando não houver espaço livre, deve aparecer: “Memory Card cheio, apague algum save game para obter espaço”.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

# MyMCdroid 2.2.0 — Sobre o Aplicativo (Preview 1)

## Alterações

- O modal de Ajuda agora possui as abas **MANUAL** e **SOBRE**.
- A aba **MANUAL** mantém o conteúdo e os ícones da base UI Colors Preview 1.
- A aba **SOBRE** reúne versão, descrição, Prompteiro, informações de desenvolvimento, referências, créditos, agradecimentos e aviso legal.
- O modal, o botão X, o fundo escurecido e as animações foram preservados.

## Verificação sugerida

1. Abra o Centro de Ajuda pelo botão de exclamação.
2. Confirme que a aba MANUAL abre inicialmente e mantém todos os sete itens.
3. Alterne entre MANUAL e SOBRE sem fechar o modal.
4. Role todo o conteúdo da aba SOBRE.
5. Feche pelo botão X, pelo botão Voltar e pelo toque fora do modal.

# MyMCdroid 0.4 — MultiFolder Import Preview 1

## Alterações

- Ícones Transferir Game Save, Transferir Save Games e Transferir Todos os Save Games agora usam a mesma cor laranja do botão Fechar Memory Card.
- Botão Importar Save Games centralizado verticalmente dentro da caixa do Memory Card.
- Nova opção **Várias pastas de Game Saves**.
- Importação sequencial das subpastas encontradas dentro de uma pasta-mãe.
- Game Saves em pasta processados em ordem alfabética.
- Confirmação individual quando um Game Save existente precisar ser sobrescrito.
- Manual atualizado em português e inglês.
- Versão do aplicativo avançada de 0.3 para 0.4.

## Como testar várias pastas

1. Abra ou crie um Memory Card.
2. Toque em Importar Save Games.
3. Selecione **Várias pastas de Game Saves**.
4. Escolha uma pasta-mãe que contenha uma subpasta para cada Game Save.
5. Confirme que os Game Saves são importados em sequência e aparecem na lista.
6. Repita o teste contendo um Game Save já existente e confirme a sobrescrita.
7. Teste a mesma pasta-mãe em Memory Cards no formato imagem e pasta.

## Estrutura esperada

```text
Pasta selecionada/
├── BASLUS-00001/
│   ├── _pcsx2_index
│   ├── icon.sys
│   └── arquivos do Game Save
└── BESLES-00002/
    ├── _pcsx2_index
    ├── icon.sys
    └── arquivos do Game Save
```

## Validações realizadas

- Importação sequencial de duas pastas em um Memory Card: aprovada.
- Regressão de criação, importação, exportação, sobrescrita, remoção, formatação e transferência: aprovada.
- Regressão dos formatos PSU, MAX, CBS, SPS e XPS: aprovada.
- Recursos Android e correspondência entre português e inglês: aprovados.
- Compilação de recursos com AAPT2: aprovada.

Este pacote contém apenas o projeto-fonte. O APK compilado não está incluído.

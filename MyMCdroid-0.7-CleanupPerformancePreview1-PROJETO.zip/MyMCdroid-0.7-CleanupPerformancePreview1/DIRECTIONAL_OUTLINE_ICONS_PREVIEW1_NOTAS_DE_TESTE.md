# MyMCdroid 0.6 — Directional Outline Icons

Versão aprovada e definida como base oficial em 14/08/2026. APK compilado não incluído.

## Alterações

- Manual, Configurações e Sobre agora usam ícones brancos;
- Importar Save Games usa seta verde apontando para baixo;
- Exportar Game Save usa uma seta azul apontando para cima;
- Exportar Save Games usa duas setas azuis apontando para cima;
- Exportar Todos os Save Games usa três setas azuis apontando para cima;
- Transferir Game Save usa uma seta laranja apontando para a direita;
- Transferir Save Games usa duas setas laranja apontando para a direita;
- Transferir Todos os Save Games usa três setas laranja apontando para a direita;
- todos os ícones alterados utilizam uma única cor e não possuem preenchimento;
- os mesmos vetores são reutilizados automaticamente no Manual.

## Testes sugeridos

1. Abrir a caixa de informações e conferir os três ícones brancos.
2. Abrir ou criar um Memory Card e conferir o ícone verde de importação.
3. Selecionar um Game Save e verificar Exportar e Transferir.
4. Ativar as opções em lote e conferir os ícones com duas setas.
5. Conferir as opções “todos” com três setas.
6. Comparar os ícones da interface com seus equivalentes no Manual.

A versão 0.6 é a nova base oficial do projeto.

# MyMCdroid 2.2.0 — Contextual Actions Preview 1

## Alterações

- A lista de saves fica recortada dentro de sua própria área e não cobre a visualização 3D.
- Adicionado desvanecimento vertical nas bordas da lista.
- Exportar e Excluir ficam invisíveis nos saves não selecionados.
- Ao selecionar um save, Exportar e Excluir aparecem da direita para a esquerda.
- Importar fica invisível sem um Memory Card aberto.
- Ao abrir, criar ou formatar um Memory Card, Importar aparece da direita para a esquerda.
- Ao fechar o Memory Card, Importar desaparece suavemente.
- O Manual foi atualizado com os novos comportamentos.

## Roteiro de teste

1. Role a lista rapidamente para cima e para baixo e confirme que nenhum save cobre a caixa 3D.
2. Confirme que Exportar e Excluir aparecem somente na linha selecionada.
3. Selecione saves diferentes e observe a animação lateral dos botões.
4. Inicie sem Memory Card e confirme que Importar está oculto.
5. Abra, crie ou formate um Memory Card e confirme a entrada animada de Importar.
6. Feche o Memory Card e confirme que Importar desaparece.
7. Verifique que os textos não mudam bruscamente de posição durante as animações.

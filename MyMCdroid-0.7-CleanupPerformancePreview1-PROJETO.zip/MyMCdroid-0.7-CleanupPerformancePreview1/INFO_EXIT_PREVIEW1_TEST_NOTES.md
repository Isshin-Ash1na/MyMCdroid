# MyMCdroid 2.2.0 — Info Exit Preview 1

## Alterações

- Criar Memory Card agora usa a cor verde das ações positivas.
- Fechar Memory Card agora usa a cor vermelha das ações de encerramento/destrutivas.
- Informações ocupa o antigo local de Sair do App no cabeçalho principal.
- Sair do App foi movido para a janela de Informações.
- Ordem interna: Manual → Engrenagem → Sobre → Sair do App → X.
- Cabeçalho interno redimensionado e espaçamentos reduzidos.
- O pequeno X foi reduzido para 32dp.
- Sair fecha Informações suavemente antes de abrir a confirmação.
- Manual atualizado para indicar a nova localização de Sair.

## Roteiro de teste

1. Confirme que o cabeçalho principal exibe Informações no antigo local de Sair.
2. Abra Informações e valide a ordem dos cinco ícones.
3. Verifique se não há sobreposição em telas estreitas.
4. Toque em Sair e confirme a transição para o popup de confirmação.
5. Abra o menu do Memory Card e confira Criar em verde e Fechar em vermelho.
6. Teste o pequeno X da janela de Informações.

# MyMCdroid 2.2.0 — Floating Card Menu Preview 1

## Alterações

- O menu do Memory Card agora é flutuante e não participa do fluxo vertical da tela.
- A visualização 3D permanece fixa quando o menu é aberto.
- Abrir, Criar e Fechar não recolhem o menu.
- O menu fecha somente com um novo toque no ícone do Memory Card.
- O ícone acionador recebeu uma pequena caixa azul para indicar que é clicável.
- Adicionada ao Manual a entrada Menu Memory Card.
- Informações permanece imediatamente antes de Sair do App.

## Roteiro de teste

1. Observe a posição da caixa 3D antes de abrir o menu.
2. Toque no ícone azul do Memory Card e confirme que a caixa 3D não se move.
3. Teste Abrir, Criar e Fechar; o menu deve permanecer aberto.
4. Toque novamente no ícone do Memory Card e confirme o recolhimento.
5. Verifique se todos os botões flutuantes continuam clicáveis.
6. Abra o Manual e confira a descrição Menu Memory Card.
7. Repita em telas estreitas e em diferentes versões do Android.

# Base oficial — MyMCdroid 2.2.0 Static Icon Cache Preview 1 Fix 2

Definida como base oficial em 09/08/2026.

## Identificação

- Version Code: `42`
- Version Name: `2.2.0-StaticIconCachePreview1-Fix2`
- Pacote-fonte aprovado: `MyMCdroid-2.2.0-StaticIconCachePreview1-Fix2-PROJETO.zip`
- APK não incluído no pacote-fonte.

## Funcionalidades consolidadas

- Miniaturas estáticas em cache para a lista de Game Saves.
- Um único renderizador WebGL ativo no Game Save selecionado.
- Renderização ampliada preservada e independente.
- Ícone de ampliar 3D na cor branca.
- Modo em lote preserva Abrir, Criar, Fechar e Importar Save Games.
- No modo em lote, ficam ocultos Exportar todos os Save Games, Formatar Memory Card e as ações individuais Exportar/Remover Game Save.
- Toque no ícone do Memory Card retrai e restaura conjuntamente a barra de funções e a lista de Game Saves.
- Manual organizado pela sequência de cores: branco, azul, verde, laranja e vermelho, com Sair do App como último item.
- Interface e Manual preservados nos idiomas Brasileiro e Inglês.
- Compilador Kotlin executado no processo do Gradle para evitar encerramento inesperado do daemon.
- `Ps2IconSnapshotRenderer.parsePayload` compatível com Kotlin 2.0.21.

## Regra para as próximas versões

Todas as próximas alterações devem partir desta revisão e preservar as funcionalidades consolidadas, salvo solicitação expressa em contrário.

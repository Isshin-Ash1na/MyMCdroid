# MyMCdroid 2.2.0 — Icon Render Recovery Preview 1

## Correções desta versão

- Removida a perda forçada do contexto WebGL das miniaturas ao abrir o render ampliado.
- Adicionada verificação automática após cada renderização.
- Se o contexto gráfico falhar, o renderizador tenta se recuperar e reaplica o ícone.
- Em último caso, somente o visualizador afetado é recarregado uma vez, sem interferir nos demais Game Saves.
- O WebGL agora é iniciado somente quando existe um ícone para renderizar, reduzindo o uso simultâneo de recursos gráficos.
- Ícones **Criar Memory Card** e **Formatar Memory Card** restaurados para a arte anterior.
- Ícones **Remover Game Save** e **Remover Save Games** restaurados para a arte anterior, simples e dupla.
- Ícones **Abrir Memory Card** e **Fechar Memory Card** ajustados para proporção quadrada.

## Testes recomendados

1. Abra um Memory Card com muitos Game Saves e percorra toda a lista lentamente.
2. Volte ao início da lista e confirme que as miniaturas continuam renderizadas.
3. Alterne rapidamente entre diferentes Game Saves.
4. Abra e feche repetidamente a visualização ampliada.
5. Confirme que fechar o render ampliado não apaga nem faz outras miniaturas piscarem.
6. Feche e abra novamente o mesmo Memory Card e compare os ícones renderizados.
7. Verifique a arte restaurada de Criar, Formatar e Remover.
8. Verifique que Abrir e Fechar possuem desenho visualmente quadrado.

O pacote do projeto não inclui APK, AAB, caches ou diretórios de compilação.

# MyMCdroid 2.2.0 — Info Tabs Preview 1

## Alterações visuais

- A pequena aba **Manual** agora exibe somente um ícone de livro aberto.
- A pequena aba **Sobre** agora exibe somente um ícone de perfil.
- Os ícones seguem as cores azul e ciano e o desenho visual do MyMCdroid.
- Todo o conteúdo das abas Manual e Sobre foi preservado.

## Alterações de fluxo e texto

- Abrir Memory Card agora pede confirmação antes do seletor de arquivos.
- Criar Memory Card agora pede confirmação antes do seletor de destino.
- As referências a Memory Card foram padronizadas no masculino.

## Roteiro de teste

1. Abra o centro de informações pelo botão **!**.
2. Confirme que as duas abas superiores exibem apenas ícones.
3. Alterne várias vezes entre livro e perfil e valide o destaque da aba ativa.
4. Confira que o conteúdo completo do Manual e da seção Sobre continua presente.
5. Teste em retrato e paisagem, observando tamanho, centralização e nitidez dos ícones.
6. Toque em Abrir e Criar Memory Card e valide os novos diálogos de confirmação.

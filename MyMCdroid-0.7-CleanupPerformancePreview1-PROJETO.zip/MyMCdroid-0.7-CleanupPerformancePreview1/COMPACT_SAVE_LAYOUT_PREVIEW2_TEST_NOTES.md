# MyMCdroid 2.2.0 — Compact Save Layout Preview 2

## Pontos para teste

1. Toque no ícone do Memory Card e confirme que Abrir, Criar e Fechar surgem ao lado, da esquerda para a direita.
2. Toque novamente no ícone e confirme que as três ações são recolhidas suavemente.
3. Abra ou crie um Memory Card e confirme que uma caixa azul aparece abaixo dos controles.
4. Confira na caixa azul o nome do Memory Card, a quantidade de saves, o espaço livre e o botão Importar.
5. Confirme que o ícone 3D de cada save aparece sem moldura própria.
6. Selecione um save e confirme que somente seu ícone rotaciona, agora de maneira mais perceptível.
7. Teste Importar, Exportar, Excluir, Abrir, Criar e Fechar Memory Card.
8. Verifique a importação e sobrescrita de PSU, MAX, CBS, SPS e XPS.

## Conteúdo do pacote

Projeto-fonte para Android Studio, sem APK, AAB ou diretórios de compilação.

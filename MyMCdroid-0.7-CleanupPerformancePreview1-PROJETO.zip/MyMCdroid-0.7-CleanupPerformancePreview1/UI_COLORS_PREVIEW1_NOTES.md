# MyMCdroid 2.2.0 UI Colors Preview 1

Base: MyMCdroid 2.2.0 Manual Preview 1.

## Alterações
- Sair do App: novo ícone de energia vermelho.
- Apagar Save Game: ícone vermelho.
- Importar Save Game: ícone verde.
- Manual atualizado para exibir os mesmos ícones e cores.
- Botão X de fechar o Manual preservado em azul.

## Preservado
- Abrir MC, Criar MC, Fechar MC, Exportar Save e Manual permanecem em azul.
- Layout, preview 3D e todas as funcionalidades permanecem inalterados.

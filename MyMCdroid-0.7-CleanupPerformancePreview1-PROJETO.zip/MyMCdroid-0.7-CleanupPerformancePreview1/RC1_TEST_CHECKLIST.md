# MyMCdroid 2.1.0 RC1 — Checklist

## Memory Card
- [ ] Abrir Memory Card com saves
- [ ] Abrir Memory Card vazia
- [ ] Criar Memory Card
- [ ] Fechar Memory Card
- [ ] Trocar de Memory Card e confirmar preview vazio

## Saves
- [ ] Importar PSU
- [ ] Importar MAX
- [ ] Importar CBS
- [ ] Importar SPS
- [ ] Importar XPS
- [ ] Confirmar sobrescrita por Serial ID + Região
- [ ] Cancelar sobrescrita e confirmar que o cartão não mudou
- [ ] Exportar PSU
- [ ] Apagar Save

## Interface
- [ ] Diálogo Fechar App
- [ ] Diálogo Fechar MC
- [ ] Diálogo Apagar Save
- [ ] Diálogo Sobrescrever Save
- [ ] Toasts personalizados
- [ ] Exportar Save com seta para cima
- [ ] Fonte do painel de detalhes
- [ ] Sem indicador circular na lista

## Render
- [ ] Preview 3D
- [ ] Texturas
- [ ] Iluminação
- [ ] Preview limpo ao fechar/trocar MC
- [ ] Sem nome/Serial sobre o render

## Estabilidade
- [ ] Sem crash na inicialização
- [ ] Sem crash ao importar/exportar/apagar
- [ ] Uso repetido sem estados residuais

# MyMCdroid 2.2.0 — Memory Card Batch UI Preview 1

## Testes principais

1. Abra ou crie um Memory Card e confirme o destaque verde do painel.
2. Aguarde 2 segundos e confira a aparição sincronizada de Importar, Formatar, Fechar e da lista de Save Games.
3. Toque no ícone do Memory Card para recolher e reabrir a lista sequencialmente.
4. Selecione vários arquivos PSU, MAX, CBS, SPS ou XPS e confirme o processamento em sequência.
5. Teste um lote contendo Game Saves novos e existentes, incluindo confirmação e cancelamento de sobrescrita.
6. Confira a ordem Abrir, Criar, Formatar e Fechar, além das novas orientações dos ícones Importar e Exportar.
7. Feche o Memory Card e confira o recolhimento da lista após 2 segundos.

O pacote contém somente o projeto-fonte. Nenhum APK compilado foi incluído.

# Base oficial — MyMCdroid 2.2.0 Animated Icon Preview 1

Definida como base oficial em 09/08/2026.

## Identificação

- Version Code: `44`
- Version Name: `2.2.0-AnimatedIconPreview1`
- Pacote-fonte aprovado: `MyMCdroid-2.2.0-AnimatedIconPreview1-PROJETO.zip`
- APK não incluído no pacote-fonte.

## Base herdada

Esta versão parte da base `2.2.0-CardContentMotionPreview1` e preserva:

- miniaturas estáticas em cache e renderizador WebGL isolado;
- estabilidade das miniaturas durante seleção e visualização ampliada;
- retração e aparição fluidas da barra de funções e dos Game Saves;
- funções unitárias, em lote e de exportação completa;
- idiomas Brasileiro e Inglês;
- importação e exportação nos formatos PSU, MAX, CBS, SPS e XPS;
- interface Sobre, Manual e identidade visual consolidada.

## Alteração consolidada

- Reprodução da animação original armazenada nos arquivos PS2ICON somente na visualização 3D ampliada.
- Leitura de todas as formas do modelo e das curvas de peso por tempo.
- Preservação da primeira chave de animação armazenada no cabeçalho de cada trilha.
- Interpolação suave das formas com atualização dinâmica do modelo 3D.
- Controle branco independente para pausar ou continuar a animação original.
- Rotação automática, pausa de rotação e giro manual preservados e independentes da animação do modelo.
- Limites de segurança para formas, vértices, trilhas e chaves malformadas.
- Miniaturas e render da lista mantidos sem processamento adicional de animação.
- Manual atualizado em Português Brasileiro e Inglês.

## Validação consolidada

- Onimusha 2: 8 formas e ciclo de 120 quadros reconhecidos.
- Onimusha 3: 6 formas e ciclo de 161 quadros reconhecidos.
- Urban Reign: 6 formas e ciclo de 60 quadros reconhecidos.
- Sintaxe JavaScript, recursos Android e classes Kotlin alteradas validados.

## Regra para as próximas versões

Todas as próximas alterações devem partir desta revisão e preservar as funcionalidades consolidadas, salvo solicitação expressa em contrário.

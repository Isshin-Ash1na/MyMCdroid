# MyMCdroid 2.2.0 — Save Typography Preview 1

## Alterações

- Nome dos saves reduzido de 15sp para 14sp.
- Fonte alterada para sans-serif-medium.
- Espaçamento entre letras reduzido de 0.10 para 0.02.
- Títulos limitados a duas linhas com reticências quando necessário.
- Entrelinha ajustada para uma leitura mais natural.
- Serial ID e região permanecem como informações secundárias.

## Roteiro de teste

1. Abra um Memory Card com títulos curtos e longos.
2. Compare o peso visual dos nomes com os botões e demais textos da tela.
3. Confira títulos com acentos e caracteres japoneses.
4. Verifique o corte com reticências em nomes que ultrapassem duas linhas.
5. Teste a lista com e sem um save selecionado.

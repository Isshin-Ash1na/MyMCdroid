# MyMCdroid 0.3 — Preview 1

## Alterações desta versão

- Aplicativo e aba Sobre renomeados para a versão 0.3.
- Marca atualizada: **MyMC** em azul e **droid** em verde.
- Os nomes em **Fontes e Referências Utilizadas** agora são links clicáveis para suas páginas oficiais.
- Seletor visível e gesto horizontal para alternar entre Memory Cards abertos.
- Lista dos arquivos internos abaixo do render 3D ampliado.
- Exportação e substituição individual do arquivo interno selecionado.
- Arquivo interno selecionado destacado com fundo azul-escuro, contorno ciano e nome verde.
- Controles de rotação e animação reorganizados no mesmo padrão visual.

## Teste rápido

1. Abra a aba Sobre e confirme a versão **MyMCdroid 0.3**.
2. Toque em cada nome de fonte ou referência e confira a abertura da página correspondente.
3. Verifique **MyMC** em azul e **droid** em verde no cabeçalho.
4. Abra dois Memory Cards e alterne pelo seletor e pelo gesto lateral.
5. Amplie um ícone 3D, selecione um arquivo interno e confira seu destaque.
6. Teste a exportação e a substituição do arquivo interno selecionado.

> Esta entrega contém somente o projeto-fonte. Nenhum APK compilado foi incluído.

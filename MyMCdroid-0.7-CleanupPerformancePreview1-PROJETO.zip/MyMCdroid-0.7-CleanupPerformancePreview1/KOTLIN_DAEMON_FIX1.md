# Correção de inicialização do compilador Kotlin

Esta revisão executa o compilador Kotlin dentro do processo do Gradle, evitando a falha em que o daemon Kotlin informa que está pronto e encerra imediatamente.

Configuração aplicada em `gradle.properties`:

- `kotlin.compiler.execution.strategy=in-process`
- limite de dois trabalhadores simultâneos;
- 2 GB de memória para o processo do Gradle;
- limite explícito de 768 MB para Metaspace.

## Primeira compilação no Android Studio

1. Abra o projeto e aguarde o Gradle Sync terminar.
2. Use **Build > Clean Project**.
3. Use **Build > Rebuild Project**.

Se o Android Studio ainda estiver mantendo um daemon antigo, feche o programa completamente, abra novamente o projeto e execute o Rebuild. Não é necessário apagar o código-fonte nem os Memory Cards de teste.

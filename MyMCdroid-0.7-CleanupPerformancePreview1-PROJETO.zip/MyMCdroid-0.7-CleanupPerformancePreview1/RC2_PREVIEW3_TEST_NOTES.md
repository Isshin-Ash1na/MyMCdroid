# MyMCdroid 2.1.0 RC2 Preview3

Base: RC1 aprovada.

## Implementado
- Correção da translucidez dos ícones PS2.
- Sala wireframe completa.
- Parede traseira mais distante.
- Quinas com brilho reduzido.
- Linhas verticais completas nas paredes esquerda e direita.
- Sem linhas soltas.

## Preservado
- Câmera, escala, rotação, iluminação, texturas, parser e funções da RC1.

## Testes
1. Profundidade
2. Paredes laterais completas
3. Destaque do modelo
4. Compatibilidade
5. Performance

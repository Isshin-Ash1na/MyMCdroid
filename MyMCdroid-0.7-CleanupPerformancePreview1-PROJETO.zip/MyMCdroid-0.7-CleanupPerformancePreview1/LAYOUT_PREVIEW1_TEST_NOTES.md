# MyMCdroid 2.2.0 Layout Preview 1

Base visual e funcional: MyMCdroid 2.1.0 RC2 Preview3 aprovada.

## Reorganização
- Botões principais apenas com os ícones já estabelecidos.
- Barra de ações abaixo do logotipo.
- Novo botão de exclamação no mesmo padrão visual; função definitiva pendente.
- Apenas o botão Importar foi realocado para dentro da caixa do Memory Card.
- Nome, quantidade de saves e espaço livre exibidos na caixa do Memory Card.
- Preview 3D centralizado.
- Painel Detalhes do Save removido.
- Cada save possui os próprios botões Exportar e Excluir.
- Miniaturas removidas da lista.
- Área útil do nome do save ampliada.

## Funcionalidade preservada
Abrir, criar e fechar Memory Card; importar, exportar e excluir saves; seleção e preview 3D.

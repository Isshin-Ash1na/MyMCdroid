# Base oficial — MyMCdroid 2.2.0 Memory Card Folder Preview 3

Definida como base oficial em 11/08/2026.

## Identificação

- Version Code: `48`
- Version Name: `2.2.0-MemoryCardFolderPreview3`
- Pacote-fonte aprovado: `MyMCdroid-2.2.0-MemoryCardFolderPreview3.zip`
- SHA-256 do pacote aprovado: `70E0789D40ECF805474E153FD41371247609E8DE2A9DE7B16DD314555C007619`
- APK e AAB não incluídos no pacote-fonte.

## Base herdada

Esta revisão preserva integralmente a interface, o Manual, a aba Sobre, os idiomas Brasileiro e Inglês, as animações, a renderização 3D, as miniaturas estáticas, as opções unitárias e em lote e a identidade visual consolidada.

Também permanecem consolidados:

- importação e exportação nos formatos PSU, MAX, CBS, SPS e XPS;
- sobrescrita por Serial ID e região;
- importação sequencial de múltiplos Game Saves;
- exportação unitária, em lote e de todos os Game Saves;
- criação de Memory Cards em arquivo com 8 MB, 16 MB, 32 MB e 64 MB;
- abertura, criação, importação, exportação, sobrescrita, remoção e formatação de Memory Cards em pasta;
- escolha da pasta-pai e do nome do novo Memory Card em pasta;
- nomes físicos de Game Saves compatíveis com o filtro por Serial ID do ARMSX2/PCSX2;
- preservação dos nomes lógicos, datas, horas, atributos e demais metadados dos Game Saves.

## Correção consolidada para ARMSX2

- O `_pcsx2_superblock` passou a conter o bloco completo de 8.192 bytes esperado por ARMSX2 e PCSX2.
- O formato anterior de 512 bytes deixava a leitura incompleta e fazia o emulador considerar o Memory Card não formatado antes de indexar os Game Saves.
- O `_pcsx2_index` passou a ser gravado no formato compacto observado em um Memory Card criado pelo próprio ARMSX2.
- O leitor aceita o índice compacto atual e o formato em blocos das versões anteriores.
- Memory Cards de 512 bytes criados pelas previews anteriores são atualizados automaticamente na próxima operação de gravação realizada pelo MyMCdroid.
- Os metadados auxiliares continuam compatíveis e preservam os dados originais dos Game Saves importados.

## Validação consolidada

- A amostra real `MemoryCard.zip`, criada pelo ARMSX2, foi reconhecida corretamente.
- Onimusha 3 identificado como título `ＯＮＩＭＵＳＨＡ３`, Serial ID `SLUS-20694` e região `NTSC-U`.
- A pasta física `BASLUS-20694` e seus cinco arquivos foram reconhecidos.
- Uma nova importação do arquivo real `onimusha-3-demon-siege.7376.max` gerou o mesmo conjunto de nomes e tamanhos da amostra do ARMSX2.
- `icon.sys` e os três arquivos de ícone ficaram idênticos aos da amostra.
- A criação, importação, exportação, sobrescrita, remoção e formatação de Memory Cards em pasta passaram nos testes de regressão.
- O ZIP aprovado foi extraído e testado novamente, sem APK, AAB, arquivos de build ou caches.

## Regra para as próximas versões

Todas as próximas alterações devem partir desta revisão e preservar as funcionalidades consolidadas, salvo solicitação expressa em contrário.

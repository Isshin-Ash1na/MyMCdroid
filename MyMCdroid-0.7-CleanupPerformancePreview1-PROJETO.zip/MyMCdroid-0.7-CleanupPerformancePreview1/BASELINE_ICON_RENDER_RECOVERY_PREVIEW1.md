# Base oficial — MyMCdroid 2.2.0 Icon Render Recovery Preview 1

Base aprovada em 9 de agosto de 2026, substituindo a **MyMCdroid 2.2.0 — Idioma Preview 2** como ponto de partida oficial.

## Identificação

- Nome da base: **MyMCdroid 2.2.0 — Icon Render Recovery Preview 1**
- Versão interna: `2.2.0-IconRenderRecoveryPreview1`
- Código da versão: `37`
- Pacote aprovado: `MyMCdroid-2.2.0-IconRenderRecoveryPreview1-PROJETO.zip`

## Estado consolidado

- Todas as funcionalidades, correções de desempenho, animações, Manual, Sobre e identidade visual das bases anteriores permanecem preservados.
- Português (Brasil) continua sendo o idioma padrão, com English (United States) disponível nas configurações.
- A caixa do Memory Card permanece abaixo da logo, com a barra de ações em sua sequência contextual aprovada.
- A função **Exportar Todos os Save Games** permanece disponível para Memory Cards com mais de um Game Save e oferece PSU, MAX, CBS, SPS e XPS.
- Os ícones **Criar Memory Card**, **Formatar Memory Card** e **Remover Game Save** utilizam a arte restaurada aprovada.
- **Remover Save Games** utiliza duas representações do ícone singular.
- Os ícones **Abrir Memory Card** e **Fechar Memory Card** possuem proporção visual quadrada.
- O renderizador WebGL não força mais a perda do contexto gráfico ao abrir a visualização ampliada.
- Cada miniatura verifica o próprio resultado e executa recuperação automática sem alterar o render dos demais Game Saves.
- O WebGL é iniciado somente quando existe um ícone para renderizar, reduzindo o uso simultâneo de recursos gráficos.
- O pacote oficial contém somente o projeto-fonte, sem APK, AAB, caches ou diretórios de compilação.

Todas as próximas alterações deverão partir desta base.

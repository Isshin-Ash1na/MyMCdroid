# Análise dos formatos MAX / SPS / XPS / CBS

Foram analisados 24 ficheiros reais enviados para teste: 6 MAX, 6 SPS, 6 XPS e 6 CBS.

## Correções

- MAX Drive: corrigida a detecção de compressão LZARI. Alguns produtores colocam `clen == length` mesmo quando o payload está comprimido. A decisão agora usa o tamanho real do payload.
- MAX Drive: o ficheiro `naruto-shippuden-ultimate-ninja-5.27638.max`, que anteriormente falhava com `MAX Drive arquivo truncado`, agora é lido correctamente.
- Serial ID: a pesquisa passou a aceitar apenas prefixos de serial PS2 conhecidos, evitando falsos positivos como `ABESLES-55605`.
- Serial ID: procura também nos nomes dos ficheiros internos do save, além do cabeçalho do container.
- Visualização: quando o importador conhece o Serial ID, guarda uma pequena cache interna associada ao conteúdo do save. Assim, se o nome do save no Memory Card for apenas `God Of War II`, o Serial ID não é perdido após o import.
- A cache não altera os ficheiros do Memory Card e não cria ficheiros extras dentro do save.

## Teste completo

Todos os 24 ficheiros foram importados para Memory Cards de teste e depois relidos pelo `list_saves`.

**Resultado: 24/24 PASS.**

Exemplos confirmados:

- God of War II: SCUS-97481 / NTSC-U 🇺🇸
- God of War II PAL: SCES-54206 / PAL 🇪🇺
- Onimusha 3: SLUS-20694 / NTSC-U 🇺🇸
- Onimusha 3 JP: SLPM-65413 / NTSC-J 🇯🇵
- Tenchu Fatal Shadows: SLUS-21129 / NTSC-U 🇺🇸
- Tenchu Kurenai: SLPS-25384 / NTSC-J 🇯🇵
- Need for Speed Most Wanted: SLUS-21351 / NTSC-U 🇺🇸
- Guitar Hero III: SLUS-21672 / NTSC-U 🇺🇸
- Naruto JP: SLPS-25837 / NTSC-J 🇯🇵
- Naruto Ultimate Ninja 5 PAL: SLES-55605 / PAL 🇪🇺

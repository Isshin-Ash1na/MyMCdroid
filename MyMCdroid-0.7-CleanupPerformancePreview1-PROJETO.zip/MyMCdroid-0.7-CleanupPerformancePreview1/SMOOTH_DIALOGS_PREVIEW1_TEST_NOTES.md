# MyMCdroid 2.2.0 — Smooth Dialogs Preview 1

## Alteração

- Removida a animação lateral padrão do Android nos diálogos de confirmação.
- Entrada centralizada com fade, escala de 98% para 100% e deslocamento vertical de 6dp.
- Entrada com 240ms e fechamento com 160ms.
- Curva de movimento suave com desaceleração no final.
- Aplicação compartilhada nos diálogos de abrir, criar, fechar, excluir, formatar e sobrescrever.

## Roteiro de teste

1. Acione Abrir e Criar Memory Card e observe se o popup nasce centralizado.
2. Teste Fechar Memory Card e Fechar aplicativo.
3. Teste Excluir save, Formatar e Sobrescrever.
4. Em todos os casos, confira se não há deslocamento vindo da direita.
5. Toque em Sim, Não e use o botão Voltar para validar a saída suave.
6. Repita em retrato e paisagem.

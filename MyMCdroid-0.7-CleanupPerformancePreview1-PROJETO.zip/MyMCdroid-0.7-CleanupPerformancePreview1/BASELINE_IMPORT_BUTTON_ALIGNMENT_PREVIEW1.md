# Base oficial — MyMCdroid 2.2.0 Import Button Alignment Preview 1

Base aprovada em 6 de agosto de 2026.

## Identificação

- Nome da base: **MyMCdroid 2.2.0 — Import Button Alignment Preview 1**
- Base anterior incorporada: **MyMCdroid 2.2.0 — Expanded Save Preview 4**
- Pacote aprovado: `MyMCdroid-2.2.0-ImportButtonAlignmentPreview1-Testes.zip`

## Estado consolidado

- Todas as funcionalidades e correções da base anterior permanecem preservadas.
- O botão **Importar Save Games** possui área fixa e centralizada no painel do Memory Card.
- Animações interrompidas ou repetidas não deixam deslocamento horizontal residual no botão.
- A entrada do botão continua ocorrendo suavemente da direita para a esquerda.
- A proposta **PS2 Neon Glyph** não integra esta base e permanece reservada para uma implementação futura.

Todas as próximas alterações deverão partir desta base.

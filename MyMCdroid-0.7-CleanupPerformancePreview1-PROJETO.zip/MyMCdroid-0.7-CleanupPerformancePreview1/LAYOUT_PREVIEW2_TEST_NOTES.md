# MyMCdroid 2.2.0 Layout Preview 2

Base: Layout Preview 1.

## Correção
- Restaurado o destaque visual do save selecionado.
- Fundo do cartão selecionado ligeiramente mais claro.
- Contorno ciano de 2 dp.
- Sem marcador circular.
- Botões Exportar e Excluir permanecem inalterados.

## Mantido
Todo o novo layout e todas as funções da Layout Preview 1.

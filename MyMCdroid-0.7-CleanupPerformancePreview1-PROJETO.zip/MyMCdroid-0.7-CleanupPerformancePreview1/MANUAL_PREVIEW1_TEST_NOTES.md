# MyMCdroid 2.2.0 Manual Preview 1

Base: MyMCdroid 2.2.0 Layout Preview 3 — Ícones.

## Implementado
- Botão de exclamação abre o Manual.
- Modal centralizado com fundo escurecido.
- Fechamento pelo X, botão Voltar ou toque fora da janela.
- Fade e leve zoom na abertura/fechamento.
- Conteúdo rolável.
- Mesmos ícones oficiais do aplicativo.
- Explicações de Sair, Abrir MC, Criar MC, Fechar MC, Importar, Exportar e Apagar.

## Preservado
Todo o layout, preview 3D, funções e iconografia da base oficial.

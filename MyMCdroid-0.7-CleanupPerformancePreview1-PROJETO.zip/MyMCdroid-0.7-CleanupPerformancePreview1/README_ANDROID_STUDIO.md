# MyMCdroid — Android Studio

Abra no Android Studio a pasta que contém `settings.gradle.kts` e aguarde a sincronização do Gradle.

O projeto oferece dois tipos de Memory Card:

- arquivo `.PS2` de 8 MB, 16 MB, 32 MB ou 64 MB;
- Memory Card em pasta compatível com PCSX2.

Os testes Python autocontidos podem ser executados a partir da raiz do projeto:

    python app/src/main/python/test_save_metadata_integrity.py
    python app/src/main/python/test_folder_card.py

O pacote-fonte não contém APK compilado. Para gerar um APK de teste no Android Studio, use **Build > Build APK(s)**.

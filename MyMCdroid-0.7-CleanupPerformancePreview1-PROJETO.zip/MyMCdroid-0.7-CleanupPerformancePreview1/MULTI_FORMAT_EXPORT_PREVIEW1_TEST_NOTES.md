# MyMCdroid 2.2.0 — Multi Format Export Preview 1

## Roteiro de testes

1. Confirme que as animações e a ativação do modo em lote usam espera de 1 segundo.
2. Ative o modo em lote e confira que os botões aparecem somente uma vez, independentemente da quantidade selecionada.
3. Exporte um Game Save em PSU, MAX, CBS, SPS e XPS.
4. Exporte vários Save Games nos cinco formatos e confira os nomes `Nome - Serial ID`.
5. Reimporte os arquivos gerados e compare os conteúdos dos Game Saves.
6. Crie Memory Cards de 8 MB, 16 MB, 32 MB e 64 MB e abra novamente cada arquivo.
7. Confira o painel ampliado, a quantidade de Save Games e `Espaço Livre : 48KB` em linha separada.
8. Confira a terminologia Remover em toda a interface e no Manual.
9. Teste o novo ícone de importação com duas setas verdes apontando para a esquerda.
10. Confira o novo item Ativar Opções em Lote no Manual.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

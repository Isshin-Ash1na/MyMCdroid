# Base oficial — MyMCdroid 2.2.0 Card Content Motion Preview 1

Definida como base oficial em 09/08/2026.

## Identificação

- Version Code: `43`
- Version Name: `2.2.0-CardContentMotionPreview1`
- Pacote-fonte aprovado: `MyMCdroid-2.2.0-CardContentMotionPreview1-PROJETO.zip`
- APK não incluído no pacote-fonte.

## Base herdada

Esta versão parte da base `2.2.0-StaticIconCachePreview1-Fix2` e preserva:

- miniaturas estáticas em cache;
- renderizador WebGL único no Game Save selecionado;
- renderização 3D ampliada;
- correções do modo em lote;
- idiomas Brasileiro e Inglês;
- compatibilidade com Kotlin 2.0.21;
- compilação Kotlin dentro do processo do Gradle;
- suporte de importação e exportação nos formatos PSU, MAX, CBS, SPS e XPS.

## Alteração consolidada

- Retração e aparição sincronizadas da barra de funções e dos Game Saves ao tocar no ícone do Memory Card.
- A altura da barra permanece estável durante a parte visível da animação, eliminando saltos do layout.
- Entrada e saída sequenciais dos Game Saves com interpolação mais suave.
- Cliques repetidos e rolagem bloqueados enquanto a transição está em andamento.
- Carregamento tardio das miniaturas respeita o estado retraído.
- Animações de abertura e fechamento do Memory Card utilizam o mesmo movimento suavizado.

## Regra para as próximas versões

Todas as próximas alterações devem partir desta revisão e preservar as funcionalidades consolidadas, salvo solicitação expressa em contrário.

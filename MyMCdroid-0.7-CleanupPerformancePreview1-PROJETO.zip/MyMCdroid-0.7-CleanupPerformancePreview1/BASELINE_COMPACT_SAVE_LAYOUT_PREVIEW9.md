# Base oficial — MyMCdroid 2.2.0 Compact Save Layout Preview 9

Status: aprovado

Definida como base oficial em 06/08/2026, substituindo a Compact Save Layout Preview 6.

## Recursos consolidados

- Otimizações de importação e sobrescrita fora da interface principal.
- Compatibilidade com PSU, MAX, CBS, SPS e XPS.
- Sobrescrita identificada por Serial ID e região.
- Botões contextuais do Memory Card e função Apagar todos os Save Games.
- Lista alfabética com nome, região e tamanho dos Game Saves.
- Ícones 3D individuais com reutilização segura de buffers e texturas WebGL.
- Recuperação após perda do contexto gráfico.
- Proteção contra respostas atrasadas em linhas recicladas.
- Game Save já selecionado não pode ser selecionado novamente.
- A seleção altera somente as linhas anterior e atual.
- A seleção de um Game Save não recarrega nem interfere nos renderizadores dos demais.
- Exportar e Apagar aparecem somente no Game Save selecionado.
- Manual, Sobre e identidade visual preservados.

Todas as próximas implementações devem partir desta base, salvo orientação expressa em contrário.

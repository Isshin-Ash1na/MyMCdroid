# MyMCdroid 2.2.0 — Multi Format Export Preview 2

## Correção principal

O fluxo de gravação no armazenamento do Android agora fecha e descarrega corretamente o buffer, além de verificar o tamanho final quando o provedor de documentos oferece essa informação.

## Roteiro de testes

1. Não reutilize arquivos exportados pela Preview 1, pois eles podem estar truncados.
2. Exporte novamente o mesmo Game Save em PSU, MAX, CBS, SPS e XPS.
3. Importe cada um dos cinco arquivos em um Memory Card diferente.
4. Repita usando Exportar Save Games no modo em lote.
5. Confira se os arquivos múltiplos usam `Nome do Game Save - Serial ID`.
6. Teste arquivos maiores que 256 KB, especialmente o Game Save de God of War II.
7. Confirme que nenhuma exportação informa sucesso quando o tamanho gravado estiver incompleto.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

# MyMCdroid 2.2.0 — Save Metadata Preview 1

## Objetivo

Corrigir a data, a hora e o tamanho exibidos pelo navegador do sistema do PS2 após importar ou sobrescrever um Game Save pelo MyMCdroid.

## Correções incluídas

- Preservação das datas de criação e modificação disponíveis em `.PSU`, `.CBS`, `.SPS` e `.XPS`.
- Data válida do momento da importação para `.MAX`, formato que não armazena esses metadados.
- Normalização automática de datas ausentes ou inválidas no padrão interno do PS2, em UTC+9.
- Preservação do modo e dos atributos dos arquivos quando o formato de origem os fornece.
- Correção dos vínculos internos `.` e `..` dos diretórios dos Game Saves.
- Correção dos campos reservados das entradas de diretório e arquivos.
- Memory Cards novos passam a ser formatados com uma data válida.
- Importação e sobrescrita por Serial ID + Região usam o mesmo tratamento de metadados.
- Validação de datas, contagem de entradas, vínculos, tamanhos e cadeias de armazenamento antes da gravação final.

## Testes sugeridos no PS2/PCSX2

1. Criar um Memory Card novo pelo MyMCdroid.
2. Importar um Game Save de cada formato: `.PSU`, `.MAX`, `.CBS`, `.SPS` e `.XPS`.
3. Abrir cada Game Save no navegador do sistema do PS2.
4. Confirmar que data, hora e tamanho em KB são exibidos normalmente.
5. Sobrescrever um Game Save existente e repetir a verificação.
6. Confirmar que o jogo reconhece e carrega normalmente o Game Save.

## Verificações automatizadas realizadas

- Importação nova nos cinco formatos.
- Sobrescrita nos cinco formatos.
- Comparação integral dos arquivos antes e depois da operação.
- Verificação de datas válidas em diretórios e arquivos.
- Verificação dos vínculos `.` e `..`.
- Verificação das cadeias FAT e ausência de erros no sistema de arquivos.
- Teste adicional com um Game Save `.MAX` real de Onimusha 2.

Este pacote contém somente o projeto-fonte. O APK compilado não está incluído.

# MyMCdroid 2.2.0 — Multi Save Selection Preview 1

## Roteiro de testes

1. Abra um Memory Card e pressione um Game Save continuamente por 2 segundos.
2. Confirme que as ações individuais desaparecem e as ações múltiplas entram pela direita.
3. Toque em outros Game Saves para selecioná-los e toque novamente para desmarcá-los.
4. Exporte a seleção e confirme a criação de um arquivo PSU separado para cada Game Save.
5. Apague vários Save Games e confirme que somente os itens selecionados foram removidos.
6. Toque no Game Save que iniciou o modo para encerrar a seleção múltipla.
7. Confirme que os botões múltiplos desaparecem e que as ações individuais voltam a funcionar.
8. Verifique rolagem, ícones 3D e alternância rápida entre diferentes Game Saves.

O pacote contém somente o projeto-fonte. Nenhum APK ou AAB compilado foi incluído.

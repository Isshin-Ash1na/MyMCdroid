# MyMCdroid 2.2.0 — Hidden Card Menu Preview 1

## Alterações

- Removida a barra fixa com Abrir, Criar e Fechar Memory Card.
- O ícone ao lado do nome do Memory Card agora abre e fecha um menu vertical.
- Abrir, Criar e Fechar aparecem empilhados de cima para baixo.
- O menu utiliza animação curta de expansão e recolhimento.
- Ao escolher uma ação, o menu recolhe antes do diálogo de confirmação.
- Informações foi movido para imediatamente antes de Sair do App.
- O Manual foi atualizado para refletir o novo fluxo.

## Roteiro de teste

1. Inicie o aplicativo e confirme que as ações do Memory Card estão ocultas.
2. Toque no ícone do Memory Card e valide a abertura vertical do menu.
3. Toque novamente no ícone e valide o recolhimento.
4. Teste Abrir, Criar e Fechar, confirmando que o menu some antes do popup.
5. Confira Informações à esquerda de Sair do App.
6. Repita com e sem um Memory Card aberto.
7. Teste em telas estreitas e em diferentes orientações.

# MyMCdroid 2.2.0 — Idioma Preview 2

## Alterações

- Nova opção **Idioma** na aba da engrenagem.
- **Português (Brasil)** com bandeira do Brasil, definido como idioma padrão.
- **English (United States)** com bandeira dos Estados Unidos.
- Preferência de idioma salva para os próximos usos.
- Tradução da tela principal, barra de ações, diálogos, avisos, progresso, Manual e Sobre.
- O Memory Card aberto é restaurado após a troca de idioma.
- Corrigido o fechamento inesperado ao tocar no botão de Informações.
- Identidade visual e funcionalidades atuais preservadas.

## Roteiro rápido de testes

1. Inicie o aplicativo e confirme que o primeiro idioma é Português (Brasil).
2. Toque várias vezes em **Informações** e confirme que a janela abre sem fechar o aplicativo.
3. Abra **Informações → engrenagem** e selecione **English (United States)**.
4. Verifique a tela principal, Manual, Sobre, confirmações, importação, exportação e remoção.
5. Feche e abra o aplicativo e confirme que o inglês continua selecionado.
6. Volte para **Português (Brasil)** e confirme a tradução completa.
7. Repita a troca com um Memory Card aberto e confirme que ele é recarregado.

Este pacote contém somente o projeto-fonte. APK, AAB e diretórios de compilação não estão incluídos.

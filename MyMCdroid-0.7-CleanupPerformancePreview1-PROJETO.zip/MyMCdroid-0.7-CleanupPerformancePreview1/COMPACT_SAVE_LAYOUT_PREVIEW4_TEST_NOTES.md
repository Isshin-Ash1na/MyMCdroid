# MyMCdroid 2.2.0 — Compact Save Layout Preview 4

## Interface

1. Confirme que a caixa do Memory Card não encosta nem sobrepõe a moldura dos botões superiores.
2. Verifique a nova moldura azul e ciano ao redor de cada ícone 3D.
3. O botão Fechar Memory Card deve aparecer em âmbar.
4. O Manual não deve mais apresentar a entrada “Menu Memory Card”.

## Renderização 3D

1. Abra um Memory Card e percorra toda a lista de saves.
2. Confira se os ícones continuam visíveis depois de rolar a lista para cima e para baixo.
3. Feche e abra o mesmo Memory Card e compare os ícones apresentados.
4. A versão inclui repetição por lote, nova tentativa individual, reaplicação ao retornar à tela e recuperação do contexto gráfico.

## Apagar todos os saves

1. O novo botão vermelho deve aparecer depois de Fechar Memory Card.
2. Sem cartão aberto, deve informar que não há Memory Card.
3. Em cartão vazio, deve informar que não existem saves.
4. Em cartão com saves, devem aparecer duas confirmações antes da operação.
5. Cancele cada confirmação separadamente e confirme que nada é alterado.
6. Em uma cópia de teste, conclua a operação e confirme que todos os saves foram removidos.
7. Feche e abra novamente o arquivo para confirmar que a remoção foi gravada.

## Conteúdo

Projeto-fonte para Android Studio, sem APK, AAB, caches ou arquivos de compilação.

# MyMCdroid 0.8 — Neon Memory Audio Preview 1

## Áudio
- Novo pacote sonoro original com dez efeitos de interface.
- Sons de abertura, importação, exportação, transferência, remoção, confirmação e cancelamento.
- Troca de Memory Card com panorama coerente com a direção do movimento.
- Transições de funções e scroll com controle contra repetição excessiva.
- Sons operacionais executados apenas depois do sucesso da operação.

## Configurações
- Nova opção Sons da Interface, ativada por padrão.
- Controle de volume próprio, com valor inicial de 70%.
- Respeito ao modo silencioso e ao volume de mídia do Android.

# MyMCdroid 0.7 — Cleanup & Performance Preview 1

## Correção consolidada na base 0.7
- Removida somente a linha azul interna do ícone Abrir Memory Card, preservando cor, tamanho e forma externa.

## Organização e tamanho
- Código legado de referência foi retirado do pacote do aplicativo e preservado em `reference/`.
- Testes e utilitários de desenvolvimento foram movidos para `tools/python_tests/`.
- Classes, layouts, drawables, animações, estilos, cores e textos sem uso foram removidos.

## Desempenho
- O módulo Python principal é reutilizado durante a sessão, evitando buscas repetidas.
- Clusters indiretos/FAT já decodificados são reutilizados durante cada leitura do Memory Card.
- A verificação de imagem apagada agora é feita em blocos e cartões válidos não são lidos integralmente duas vezes.
- A identificação do Serial ID lê apenas o cabeçalho necessário dos contêineres.
- Cache e entradas de metadados são compartilhados durante listagens e comparações.

## Compatibilidade preservada
- Regra de sobrescrita por Serial ID + Região.
- PSU, MAX, CBS, SPS, XPS e Game Save em pasta.
- Múltiplos Memory Cards, transferências, renderização 3D, Manual, Sobre e identidade visual da versão 0.6.

# MyMCdroid 0.6 — Directional Outline Icons

## Iconografia
- Manual, Configurações e Sobre em branco.
- Importação orientada para baixo.
- Exportações orientadas para cima.
- Transferências orientadas para a direita.
- Uma única cor e ausência de preenchimento nos ícones alterados.

## Origem
- Criada diretamente a partir da base oficial 0.4 e aprovada como nova base oficial.

# MyMCdroid 2.1.0 RC1

## Interface
- Diálogos personalizados MyMCdroid com fundo escurecido e fade.
- Toasts personalizados MyMCdroid.
- Ícone de Exportar Save corrigido para seta apontando para cima.
- Tipografia ampliada no painel Detalhes do Save.
- Mensagens de operações removidas do painel permanente da Memory Card.

## Estado
- Preview, seleção e detalhes são limpos ao fechar ou trocar a Memory Card.
- Preview e detalhes são limpos depois de apagar um save.
- Novo Memory Card abre sem seleção automática.

## Mensagens
- “Save Game Overwritten” substituído por “Save Game Sobrescrito”.

## Fora desta RC
- Ambiente wireframe do preview 3D.
- Tela Sobre o Aplicativo.
- Recursos adicionais.

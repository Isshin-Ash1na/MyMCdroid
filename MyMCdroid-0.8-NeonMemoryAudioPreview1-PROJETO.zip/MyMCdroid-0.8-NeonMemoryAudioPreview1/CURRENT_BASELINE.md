# Prévia em teste

`MyMCdroid 0.8 — Neon Memory Audio Preview 1`

Criada diretamente a partir da base oficial aprovada `MyMCdroid 0.7 — Cleanup & Performance Fix1`. A versão 0.7 permanece como base oficial até a aprovação desta prévia.

Escopo desta prévia:

- pacote sonoro original MyMCdroid Neon Memory com dez efeitos compactos;
- sons de abertura, importar, exportar, transferir, remover, confirmar e cancelar;
- sons direcionais na troca entre Memory Cards;
- efeitos sutis para transições de funções e scroll, com limite de repetição;
- reprodução de operações somente depois de sua conclusão real;
- opção para ativar/desativar sons e controlar o volume em Configurações;
- respeito ao modo silencioso e ao volume de mídia;
- interface, idiomas, Manual, Sobre, formatos e funções da base 0.7 preservados.

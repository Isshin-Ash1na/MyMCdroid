package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

object SavePreviewDialog {
    data class FileItem(val name: String, val size: Long)

    fun show(
        context: Context,
        title: String,
        serial: String,
        region: String,
        payload: String,
        files: List<FileItem>,
        onExportFile: (String) -> Unit,
        onReplaceFile: (String) -> Unit,
        onClosed: () -> Unit,
    ) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_save_preview, null)
        dialog.setContentView(view)
        val panel = view.findViewById<View>(R.id.expandedPreviewPanel)
        val preview = view.findViewById<SavePreviewView>(R.id.expandedPreview)
        val rotation = view.findViewById<ImageButton>(R.id.expandedPreviewRotation)
        val animationControl = view.findViewById<LinearLayout>(R.id.expandedPreviewAnimationControl)
        val iconAnimation = view.findViewById<ImageButton>(R.id.expandedPreviewAnimation)
        val fileList = view.findViewById<ListView>(R.id.expandedPreviewFiles)
        val fileListEmpty = view.findViewById<TextView>(R.id.expandedPreviewFilesEmpty)
        val exportFile = view.findViewById<Button>(R.id.expandedPreviewExportFile)
        val replaceFile = view.findViewById<Button>(R.id.expandedPreviewReplaceFile)
        view.findViewById<TextView>(R.id.expandedPreviewTitle).text = title
        view.findViewById<TextView>(R.id.expandedPreviewSerial).text = serial
        view.findViewById<TextView>(R.id.expandedPreviewRegion).text = region

        val labels = files.map { item ->
            "${item.name}  •  ${formatSize(item.size)}"
        }
        fileList.adapter = ArrayAdapter(
            context,
            R.layout.save_file_list_item,
            R.id.saveFileName,
            labels,
        )
        fileList.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
        fileListEmpty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        var selectedFile: String? = null
        fun updateFileActions() {
            val enabled = selectedFile != null
            exportFile.isEnabled = enabled
            replaceFile.isEnabled = enabled
            exportFile.alpha = if (enabled) 1f else 0.45f
            replaceFile.alpha = if (enabled) 1f else 0.45f
        }
        fileList.setOnItemClickListener { _, _, position, _ ->
            selectedFile = files.getOrNull(position)?.name
            fileList.setItemChecked(position, true)
            updateFileActions()
        }
        updateFileActions()

        preview.setCompactMode(false)
        preview.setInteractive(true)
        preview.setIconAnimationEnabled(true)
        preview.setOnRenderReadyListener {
            preview.queryIconAnimationAvailability { available ->
                if (!available || animationControl.visibility == View.VISIBLE) {
                    return@queryIconAnimationAvailability
                }
                animationControl.alpha = 0f
                animationControl.visibility = View.VISIBLE
                animationControl.animate().alpha(1f).setDuration(180L).start()
            }
        }
        preview.setPayload(payload)
        preview.setRotationEnabled(true)
        var rotating = true
        rotation.setOnClickListener {
            rotating = !rotating
            preview.setRotationEnabled(rotating)
            rotation.setImageResource(
                if (rotating) R.drawable.ic_rotation_pause else R.drawable.ic_rotation_play
            )
            rotation.contentDescription = context.getString(
                if (rotating) R.string.pause_rotation else R.string.continue_rotation
            )
        }
        var iconAnimating = true
        iconAnimation.setOnClickListener {
            iconAnimating = !iconAnimating
            preview.setIconAnimationPlaying(iconAnimating)
            iconAnimation.setImageResource(
                if (iconAnimating) R.drawable.ic_animation_pause else R.drawable.ic_animation_play
            )
            iconAnimation.contentDescription = context.getString(
                if (iconAnimating) R.string.pause_icon_animation
                else R.string.continue_icon_animation
            )
        }

        var closing = false
        var callbackSent = false
        var afterClose: (() -> Unit)? = null
        fun close(after: (() -> Unit)? = null) {
            if (closing) return
            closing = true
            if (after == null) MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            afterClose = after
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            panel.animate().alpha(0f).scaleX(0.985f).scaleY(0.985f)
                .translationY(5f * context.resources.displayMetrics.density)
                .setDuration(160L).withEndAction { dialog.dismiss() }.start()
        }
        exportFile.setOnClickListener {
            selectedFile?.let { fileName -> close { onExportFile(fileName) } }
        }
        replaceFile.setOnClickListener {
            selectedFile?.let { fileName -> close { onReplaceFile(fileName) } }
        }
        view.findViewById<ImageButton>(R.id.expandedPreviewClose).setOnClickListener { close() }
        dialog.setOnCancelListener { close() }
        dialog.setOnDismissListener {
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            preview.suspendRenderer()
            if (!callbackSent) {
                callbackSent = true
                onClosed()
            }
            afterClose?.also { action ->
                afterClose = null
                action()
            }
        }

        val density = context.resources.displayMetrics.density
        val width = (context.resources.displayMetrics.widthPixels * 0.92f).toInt()
        val height = (context.resources.displayMetrics.heightPixels * 0.92f).toInt()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            attributes = attributes.apply {
                dimAmount = 0.72f
                windowAnimations = 0
                y = (12f * density).toInt()
            }
        }
        panel.alpha = 0f
        panel.scaleX = 0.98f
        panel.scaleY = 0.98f
        panel.translationY = 6f * density
        dialog.show()
        dialog.window?.setLayout(width, height)
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f)).setDuration(240L).start()
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024L -> String.format(
            java.util.Locale.US,
            "%.1f MB",
            bytes / (1024.0 * 1024.0),
        )
        bytes >= 1024L -> "${(bytes + 1023L) / 1024L} KB"
        else -> "$bytes B"
    }
}

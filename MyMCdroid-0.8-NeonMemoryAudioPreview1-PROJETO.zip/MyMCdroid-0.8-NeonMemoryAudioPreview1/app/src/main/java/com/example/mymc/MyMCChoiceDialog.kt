package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object MyMCChoiceDialog {
    fun show(
        context: Context,
        title: String,
        options: List<String>,
        onCancel: (() -> Unit)? = null,
        onChoose: (Int) -> Unit
    ) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_mymc_choice, null)
        dialog.setContentView(view)
        dialog.setCancelable(true)
        dialog.setOnCancelListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            onCancel?.invoke()
        }
        view.findViewById<TextView>(R.id.choiceTitle).text = title
        val choices = view.findViewById<LinearLayout>(R.id.choiceOptions)
        val density = context.resources.displayMetrics.density
        options.forEachIndexed { index, label ->
            val button = Button(context).apply {
                text = label
                isAllCaps = false
                setTextColor(context.getColor(R.color.ps2_text))
                textSize = 15f
                setBackgroundResource(R.drawable.mymc_dialog_button_yes)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (46 * density).toInt()
                ).apply { if (index > 0) topMargin = (7 * density).toInt() }
            }
            choices.addView(button)
            button.setOnClickListener {
                MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
                dismiss(dialog, view) { onChoose(index) }
            }
        }
        val width = (context.resources.displayMetrics.widthPixels * 0.86f).toInt()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
            attributes = attributes.apply { dimAmount = 0.72f; windowAnimations = 0 }
        }
        val panel = view.findViewById<View>(R.id.choicePanel)
        panel.alpha = 0f; panel.scaleX = 0.98f; panel.scaleY = 0.98f
        dialog.show()
        dialog.window?.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f)).setDuration(220L).start()
    }

    private fun dismiss(dialog: Dialog, view: View, after: () -> Unit) {
        view.findViewById<View>(R.id.choicePanel).animate().alpha(0f).scaleX(0.985f).scaleY(0.985f)
            .setDuration(150L).withEndAction { dialog.dismiss(); after() }.start()
    }
}

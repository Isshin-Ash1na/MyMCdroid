package com.example.mymc

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

object ManualDialog {
    fun show(context: Context, onCloseApp: () -> Unit) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)

        val view = LayoutInflater.from(context).inflate(R.layout.dialog_manual, null)
        dialog.setContentView(view)
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(true)
        dialog.setOnCancelListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
        }

        val panel = view.findViewById<View>(R.id.manualPanel)
        val offset = 6f * context.resources.displayMetrics.density
        val smoothInterpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
        panel.alpha = 0f
        panel.scaleX = 0.98f
        panel.scaleY = 0.98f
        panel.translationY = offset

        fun dismissAnimated(after: (() -> Unit)? = null) {
            panel.animate()
                .alpha(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .translationY(offset * 0.65f)
                .setInterpolator(smoothInterpolator)
                .setDuration(160)
                .withEndAction {
                    if (dialog.isShowing) dialog.dismiss()
                    after?.invoke()
                }
                .start()
        }

        view.findViewById<ImageButton>(R.id.manualClose).setOnClickListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            dismissAnimated()
        }

        val manualTab = view.findViewById<ImageButton>(R.id.manualTab)
        val settingsTab = view.findViewById<ImageButton>(R.id.settingsTab)
        val aboutTab = view.findViewById<ImageButton>(R.id.aboutTab)
        val closeApp = view.findViewById<ImageButton>(R.id.infoCloseApp)
        val manualContent = view.findViewById<View>(R.id.manualContent)
        val settingsContent = view.findViewById<View>(R.id.settingsContent)
        val aboutContent = view.findViewById<View>(R.id.aboutContent)
        val languageBrazil = view.findViewById<View>(R.id.languageBrazil)
        val languageEnglish = view.findViewById<View>(R.id.languageEnglish)
        val brazilSelected = view.findViewById<View>(R.id.languageBrazilSelected)
        val englishSelected = view.findViewById<View>(R.id.languageEnglishSelected)
        val soundsSwitch = view.findViewById<Switch>(R.id.interfaceSoundsSwitch)
        val soundsVolume = view.findViewById<SeekBar>(R.id.interfaceSoundsVolume)
        val soundsVolumeLabel = view.findViewById<TextView>(R.id.interfaceSoundsVolumeLabel)
        val aboutSources = view.findViewById<TextView>(R.id.aboutSources)
        aboutSources.text = context.getText(R.string.about_sources)
        aboutSources.movementMethod = LinkMovementMethod.getInstance()
        aboutSources.linksClickable = true
        aboutSources.highlightColor = Color.TRANSPARENT

        fun updateLanguageSelection() {
            val portuguese = AppLanguage.current(context) == AppLanguage.PORTUGUESE_BRAZIL
            languageBrazil.setBackgroundResource(
                if (portuguese) R.drawable.manual_header else R.drawable.manual_item
            )
            languageEnglish.setBackgroundResource(
                if (portuguese) R.drawable.manual_item else R.drawable.manual_header
            )
            brazilSelected.visibility = if (portuguese) View.VISIBLE else View.INVISIBLE
            englishSelected.visibility = if (portuguese) View.INVISIBLE else View.VISIBLE
        }

        var selectedTab = 0
        fun selectTab(tab: Int) {
            if (tab != selectedTab) MyMCSound.playFunctionTransition(context)
            selectedTab = tab
            manualContent.visibility = if (tab == 0) View.VISIBLE else View.GONE
            settingsContent.visibility = if (tab == 1) View.VISIBLE else View.GONE
            aboutContent.visibility = if (tab == 2) View.VISIBLE else View.GONE
            manualTab.setBackgroundResource(
                if (tab == 0) R.drawable.manual_header else R.drawable.ps2_button
            )
            settingsTab.setBackgroundResource(
                if (tab == 1) R.drawable.manual_header else R.drawable.ps2_button
            )
            aboutTab.setBackgroundResource(
                if (tab == 2) R.drawable.manual_header else R.drawable.ps2_button
            )
            manualTab.isSelected = tab == 0
            settingsTab.isSelected = tab == 1
            aboutTab.isSelected = tab == 2
            if (tab == 1) updateLanguageSelection()
        }

        fun changeLanguage(languageTag: String) {
            if (AppLanguage.current(context) == languageTag) return
            MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
            AppLanguage.set(context, languageTag)
            dismissAnimated { (context as? Activity)?.recreate() }
        }

        var updatingSoundControls = false
        fun updateSoundControls() {
            updatingSoundControls = true
            val enabled = MyMCSound.isEnabled(context)
            val volume = MyMCSound.volumePercent(context)
            soundsSwitch.isChecked = enabled
            soundsVolume.progress = volume
            soundsVolume.isEnabled = enabled
            soundsVolume.alpha = if (enabled) 1f else 0.45f
            soundsVolumeLabel.alpha = if (enabled) 1f else 0.55f
            soundsVolumeLabel.text = context.getString(R.string.interface_sounds_volume, volume)
            updatingSoundControls = false
        }

        soundsSwitch.setOnCheckedChangeListener { _, enabled ->
            if (updatingSoundControls) return@setOnCheckedChangeListener
            if (enabled) {
                MyMCSound.setEnabled(context, true)
                MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
            } else {
                MyMCSound.play(context, MyMCSound.Effect.CANCEL)
                MyMCSound.setEnabled(context, false)
            }
            updateSoundControls()
        }
        soundsVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                soundsVolumeLabel.text = context.getString(
                    R.string.interface_sounds_volume,
                    progress,
                )
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val volume = seekBar?.progress ?: return
                MyMCSound.setVolumePercent(context, volume)
                MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
            }
        })
        updateSoundControls()

        manualTab.setOnClickListener { selectTab(0) }
        settingsTab.setOnClickListener { selectTab(1) }
        aboutTab.setOnClickListener { selectTab(2) }
        languageBrazil.setOnClickListener { changeLanguage(AppLanguage.PORTUGUESE_BRAZIL) }
        languageEnglish.setOnClickListener { changeLanguage(AppLanguage.ENGLISH_US) }
        closeApp.setOnClickListener { dismissAnimated(onCloseApp) }
        selectTab(0)

        val dialogWidth = (context.resources.displayMetrics.widthPixels * 0.92f).toInt()
        val dialogHeight = (context.resources.displayMetrics.heightPixels * 0.86f).toInt()
        dialog.window?.apply {
            setWindowAnimations(0)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
            attributes = attributes.apply {
                width = dialogWidth
                height = dialogHeight
                gravity = Gravity.CENTER
                dimAmount = 0.68f
                windowAnimations = 0
            }
        }

        dialog.show()
        dialog.window?.setLayout(dialogWidth, dialogHeight)
        panel.post {
            panel.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setInterpolator(smoothInterpolator)
                .setDuration(240)
                .start()
        }
    }
}

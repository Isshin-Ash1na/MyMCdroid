package com.example.mymc

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.EnumMap
import java.util.concurrent.ConcurrentHashMap

/** Low-latency controller for the original MyMCdroid Neon Memory sound pack. */
object MyMCSound {
    enum class Effect {
        APP_OPEN,
        IMPORT,
        EXPORT,
        TRANSFER,
        REMOVE,
        CONFIRM,
        CANCEL,
        CARD_TRANSITION,
        FUNCTION_TRANSITION,
        SCROLL_TICK,
    }

    private const val PREFERENCES = "mymcdroid_preferences"
    private const val ENABLED_KEY = "interface_sounds_enabled"
    private const val VOLUME_KEY = "interface_sounds_volume"
    private const val DEFAULT_VOLUME = 70

    private val resourceIds = mapOf(
        Effect.APP_OPEN to R.raw.sound_app_open,
        Effect.IMPORT to R.raw.sound_import,
        Effect.EXPORT to R.raw.sound_export,
        Effect.TRANSFER to R.raw.sound_transfer,
        Effect.REMOVE to R.raw.sound_remove,
        Effect.CONFIRM to R.raw.sound_confirm,
        Effect.CANCEL to R.raw.sound_cancel,
        Effect.CARD_TRANSITION to R.raw.sound_card_transition,
        Effect.FUNCTION_TRANSITION to R.raw.sound_function_transition,
        Effect.SCROLL_TICK to R.raw.sound_scroll_tick,
    )
    private val soundIds = EnumMap<Effect, Int>(Effect::class.java)
    private val loadedIds = ConcurrentHashMap.newKeySet<Int>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var soundPool: SoundPool? = null
    private var applicationContext: Context? = null
    private var lastScrollAt = 0L
    private var lastFunctionTransitionAt = 0L

    @Synchronized
    fun initialize(context: Context) {
        if (soundPool != null) return
        applicationContext = context.applicationContext
        try {
            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val pool = SoundPool.Builder()
                .setAudioAttributes(attributes)
                .setMaxStreams(4)
                .build()
            pool.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0) loadedIds += sampleId
            }
            resourceIds.forEach { (effect, resourceId) ->
                soundIds[effect] = pool.load(context, resourceId, 1)
            }
            soundPool = pool
        } catch (_: Exception) {
            // Audio must remain optional and never block memory-card functions.
            soundPool = null
            soundIds.clear()
            loadedIds.clear()
        }
    }

    fun isEnabled(context: Context): Boolean = preferences(context)
        .getBoolean(ENABLED_KEY, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        preferences(context).edit().putBoolean(ENABLED_KEY, enabled).apply()
    }

    fun volumePercent(context: Context): Int = preferences(context)
        .getInt(VOLUME_KEY, DEFAULT_VOLUME)
        .coerceIn(0, 100)

    fun setVolumePercent(context: Context, volume: Int) {
        preferences(context).edit()
            .putInt(VOLUME_KEY, volume.coerceIn(0, 100))
            .apply()
    }

    fun play(context: Context, effect: Effect, pan: Float = 0f, level: Float = 1f) {
        initialize(context)
        playLoaded(effect, pan, level, allowRetry = true)
    }

    fun playCardTransition(context: Context, direction: Int) {
        val pan = if (direction >= 0) 0.48f else -0.48f
        play(context, Effect.CARD_TRANSITION, pan)
    }

    fun playFunctionTransition(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastFunctionTransitionAt < 140L) return
        lastFunctionTransitionAt = now
        play(context, Effect.FUNCTION_TRANSITION, level = 0.72f)
    }

    fun playScrollTick(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastScrollAt < 90L) return
        lastScrollAt = now
        play(context, Effect.SCROLL_TICK, level = 0.34f)
    }

    private fun playLoaded(effect: Effect, pan: Float, level: Float, allowRetry: Boolean) {
        val context = applicationContext ?: return
        if (!isEnabled(context) || !mayPlay(context)) return
        val pool = soundPool ?: return
        val soundId = soundIds[effect] ?: return
        if (soundId !in loadedIds) {
            if (allowRetry) {
                mainHandler.postDelayed({ playLoaded(effect, pan, level, false) }, 180L)
            }
            return
        }
        val master = volumePercent(context) / 100f
        if (master <= 0f) return
        val clampedPan = pan.coerceIn(-1f, 1f)
        val base = (master * level.coerceIn(0f, 1f)).coerceIn(0f, 1f)
        val left = base * if (clampedPan > 0f) 1f - clampedPan else 1f
        val right = base * if (clampedPan < 0f) 1f + clampedPan else 1f
        try {
            pool.play(soundId, left, right, 1, 0, 1f)
        } catch (_: Exception) {
            // A device audio failure must not interfere with the requested action.
        }
    }

    private fun mayPlay(context: Context): Boolean {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return true
        return audio.ringerMode == AudioManager.RINGER_MODE_NORMAL &&
            audio.getStreamVolume(AudioManager.STREAM_MUSIC) > 0
    }

    private fun preferences(context: Context) =
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
}

# MyMCdroid 2.1.0 RC1

## Interface
- Diálogos personalizados MyMCdroid com fundo escurecido e fade.
- Toasts personalizados MyMCdroid.
- Ícone de Exportar Save corrigido para seta apontando para cima.
- Tipografia ampliada no painel Detalhes do Save.
- Mensagens de operações removidas do painel permanente da Memory Card.

## Estado
- Preview, seleção e detalhes são limpos ao fechar ou trocar a Memory Card.
- Preview e detalhes são limpos depois de apagar um save.
- Novo Memory Card abre sem seleção automática.

## Mensagens
- “Save Game Overwritten” substituído por “Save Game Sobrescrito”.

## Fora desta RC
- Ambiente wireframe do preview 3D.
- Tela Sobre o Aplicativo.
- Recursos adicionais.

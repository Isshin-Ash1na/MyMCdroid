# Base oficial atual

`MyMCdroid 2.2.0 — Memory Card Folder Preview 3`

Consulte `BASELINE_MEMORY_CARD_FOLDER_PREVIEW3.md` para a especificação consolidada.

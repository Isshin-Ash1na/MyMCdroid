# Núcleo Python original

Os ficheiros em `legacy_mymc/` são uma cópia do código fornecido pelo utilizador.
O código original é Python 2 e não é executado directamente pelo Android/Python 3.

Próximo passo do port:
1. Converter os módulos de dados para Python 3.13 sem alterar a semântica.
2. Criar testes de equivalência para FAT, superblock, ECC e saves.
3. Expor uma API pequena ao Kotlin.
4. Implementar a UI Android em cima dessa API.

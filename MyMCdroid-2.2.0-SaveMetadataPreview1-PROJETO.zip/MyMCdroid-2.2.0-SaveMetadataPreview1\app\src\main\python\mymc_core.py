"""
mymc_core.py - Python 3 read-only core for the Android port.

This module follows the on-card layout used by the original mymc/ps2mc.py.
It deliberately starts read-only: opening and listing a card must be correct
before any write operation is enabled.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass
from pathlib import Path

MAGIC = b"Sony PS2 Memory Card Format "
FAT_ALLOCATED = 0x80000000
FAT_END = 0xFFFFFFFF
DIRENT_SIZE = 512

DIRENT_FMT = "<HHL8sLL8sL28x448s"
DIRENT_STRUCT = struct.Struct(DIRENT_FMT)
TOD_STRUCT = struct.Struct("<xBBBBBH")
SUPER_FMT = "<28s12sHHHHLLLLLL8x128s128sbbxx"
SUPER_STRUCT = struct.Struct(SUPER_FMT)


@dataclass(frozen=True)
class CardInfo:
    version: str
    page_size: int
    pages_per_cluster: int
    pages_per_erase_block: int
    clusters_per_card: int
    alloc_offset: int
    alloc_end: int
    root_cluster: int
    good_block1: int
    good_block2: int
    file_size: int


@dataclass(frozen=True)
class SaveEntry:
    index: int
    name: str
    size: int
    first_cluster: int
    mode: int
    is_dir: bool


def _tod(raw: bytes):
    return TOD_STRUCT.unpack(raw)


def _decode_name(raw: bytes) -> str:
    return raw.split(b"\0", 1)[0].decode("shift_jis", "replace")


def _dirent(raw: bytes):
    e = list(DIRENT_STRUCT.unpack(raw))
    e[3] = _tod(e[3])
    e[6] = _tod(e[6])
    e[8] = _decode_name(e[8])
    return e


class PS2MemoryCard:
    """Read-only PS2 memory-card filesystem."""

    def __init__(self, filename: str | Path):
        self.path = Path(filename)
        self._data = self.path.read_bytes()
        if len(self._data) < 0x154:
            raise ValueError("Ficheiro demasiado pequeno para um Memory Card PS2.")

        sb = SUPER_STRUCT.unpack(self._data[:0x154])
        if not sb[0].startswith(MAGIC):
            raise ValueError("Não é uma imagem de memory card PS2.")

        self.version = sb[1].split(b"\0", 1)[0].decode("ascii", "replace")
        self.page_size = sb[2]
        self.pages_per_cluster = sb[3]
        self.pages_per_erase_block = sb[4]
        self.clusters_per_card = sb[6]
        self.alloc_offset = sb[7]
        self.alloc_end = sb[8]
        self.root_cluster = sb[9]
        self.good_block1 = sb[10]
        self.good_block2 = sb[11]
        self.ifc_list = list(struct.unpack("<32I", sb[12]))
        self.bad_blocks = list(struct.unpack("<32I", sb[13]))

        # PS2 pages have 4 ECC bytes per 128 bytes of page data.
        self.spare_size = ((self.page_size + 127) // 128) * 4
        self.raw_page_size = self.page_size + self.spare_size
        self.cluster_size = self.page_size * self.pages_per_cluster
        self.entries_per_cluster = self.cluster_size // 4

        if self.page_size not in (512, 1024):
            raise ValueError(f"Tamanho de página não suportado: {self.page_size}")
        if self.pages_per_cluster not in (1, 2):
            raise ValueError(f"Páginas por cluster inválidas: {self.pages_per_cluster}")

    @property
    def info(self) -> CardInfo:
        return CardInfo(
            self.version, self.page_size, self.pages_per_cluster,
            self.pages_per_erase_block, self.clusters_per_card,
            self.alloc_offset, self.alloc_end, self.root_cluster,
            self.good_block1, self.good_block2, len(self._data)
        )

    def read_page(self, n: int) -> bytes:
        off = n * self.raw_page_size
        page = self._data[off:off + self.page_size]
        if len(page) != self.page_size:
            raise ValueError(f"Leitura além do EOF na página {n}.")
        # ECC verification is deliberately isolated for the next milestone.
        # Data extraction remains available while the ECC implementation is
        # ported and tested against the original ps2mc_ecc.py.
        return page

    def read_cluster(self, n: int) -> bytes:
        first_page = n * self.pages_per_cluster
        return b"".join(
            self.read_page(first_page + i)
            for i in range(self.pages_per_cluster)
        )

    def _read_u32_cluster(self, n: int):
        raw = self.read_cluster(n)
        return struct.unpack("<%dI" % self.entries_per_cluster, raw)

    def lookup_fat(self, n: int) -> int:
        if n < 0 or n >= self.alloc_end:
            raise ValueError(f"FAT index fora do intervalo: {n}")

        fat_offset = n % self.entries_per_cluster
        indirect_index = n // self.entries_per_cluster
        indirect_offset = indirect_index % self.entries_per_cluster
        double_index = indirect_index // self.entries_per_cluster

        indirect_cluster_num = self.ifc_list[double_index]
        indirect = self._read_u32_cluster(indirect_cluster_num)
        fat_cluster_num = indirect[indirect_offset]
        fat = self._read_u32_cluster(fat_cluster_num)
        return fat[fat_offset]

    def fat_chain(self, first: int, limit: int = 100000):
        chain = []
        seen = set()
        cluster = first
        while cluster != FAT_END:
            if cluster in seen:
                raise ValueError("Ciclo detectado na FAT.")
            seen.add(cluster)
            if len(chain) >= limit:
                raise ValueError("Cadeia FAT demasiado longa.")
            chain.append(cluster)
            value = self.lookup_fat(cluster)
            if value == FAT_END:
                break
            if not (value & FAT_ALLOCATED):
                raise ValueError(
                    f"Cadeia FAT contém cluster não alocado: {cluster}"
                )
            cluster = value & ~FAT_ALLOCATED
        return chain

    def read_alloc_cluster(self, n: int) -> bytes:
        return self.read_cluster(n + self.alloc_offset)

    def read_file(self, first_cluster: int, length: int) -> bytes:
        if length == 0:
            return b""
        if first_cluster == FAT_END:
            raise ValueError("Ficheiro não tem primeiro cluster.")
        chunks = []
        remaining = length
        for cluster in self.fat_chain(first_cluster):
            chunk = self.read_alloc_cluster(cluster)
            take = min(remaining, len(chunk))
            chunks.append(chunk[:take])
            remaining -= take
            if remaining == 0:
                break
        if remaining:
            raise ValueError("A cadeia FAT termina antes do tamanho indicado.")
        return b"".join(chunks)

    def root_entries(self):
        root = self.read_file(self.root_cluster, DIRENT_SIZE * 1)
        first = _dirent(root[:DIRENT_SIZE])
        count = first[2]
        raw = self.read_file(self.root_cluster, count * DIRENT_SIZE)
        return [_dirent(raw[i:i + DIRENT_SIZE])
                for i in range(0, len(raw), DIRENT_SIZE)]

    def saves(self):
        result = []
        for i, e in enumerate(self.root_entries()):
            mode = e[0]
            if i < 2:
                continue
            if (mode & 0x8000) and (mode & 0x20) and not (mode & 0x10):
                result.append(SaveEntry(
                    i, e[8], e[2], e[4], mode, True
                ))
        return result

    def directory_entries(self, first_cluster: int, entry_count: int):
        raw = self.read_file(first_cluster, entry_count * DIRENT_SIZE)
        return [_dirent(raw[i:i + DIRENT_SIZE])
                for i in range(0, len(raw), DIRENT_SIZE)]

    def check(self):
        """Validate directory/FAT chains without changing the image."""
        root = self.root_entries()
        used = set(self.fat_chain(self.root_cluster))
        errors = []

        for e in root[2:]:
            if not (e[0] & 0x8000):
                continue
            try:
                chain = self.fat_chain(e[4])
                used.update(chain)
                needed = (e[2] * DIRENT_SIZE + self.cluster_size - 1) // self.cluster_size
                if len(chain) < needed:
                    errors.append(f"{e[8]}: cadeia FAT demasiado curta")
                elif len(chain) > needed:
                    errors.append(f"{e[8]}: cadeia FAT demasiado longa")
            except Exception as exc:
                errors.append(f"{e[8]}: {exc}")

        return errors


    def save_files(self, save: SaveEntry):
        """Return file entries contained by a save directory."""
        entries = self.directory_entries(save.first_cluster, save.size)
        return [{
            "name": e[8], "size": e[2], "first_cluster": e[4],
            "mode": e[0], "is_directory": bool(e[0] & 0x20),
        } for e in entries if e[8] not in (".", "..") and e[8]]

    def extract_file(self, first_cluster: int, size: int) -> bytes:
        return self.read_file(first_cluster, size)


def open_card(filename):
    return PS2MemoryCard(filename)

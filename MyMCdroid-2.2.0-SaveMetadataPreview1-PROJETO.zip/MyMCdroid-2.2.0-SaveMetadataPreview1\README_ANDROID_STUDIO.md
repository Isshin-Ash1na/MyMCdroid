# myMC Android — Android Studio

Abra a pasta `v10` no Android Studio.

Esta versão mantém a interface em modo seguro para escrita. O escritor PSU foi validado
num round-trip real numa cópia da memory card, mas ainda não foi exposto à UI.

Teste Python local:

    PYTHONPATH=app/src/main/python python app/src/main/python/test_roundtrip_writer.py

O teste usa `/mnt/data/mcd001 (1).ps2` quando executado neste ambiente. Em Android, o
mesmo núcleo será chamado através da API Python/Chaquopy.

package com.example.mymc

import android.app.Activity
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.content.res.Configuration
import android.view.View
import android.view.animation.PathInterpolator
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.widget.ImageButton
import android.widget.ListView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private companion object {
        const val STATE_CARD_URI = "open_card_uri"
    }

    private lateinit var status: TextView
    private lateinit var cardName: TextView
    private lateinit var list: ListView
    private lateinit var adapter: SaveListAdapter
    private lateinit var importButton: ImageButton
    private lateinit var cardMenuButton: View
    private lateinit var cardInfoPanel: View
    private lateinit var cardActionsRow: View
    private lateinit var openCardActions: View
    private lateinit var allSaveActions: View
    private lateinit var multiExportActions: View
    private lateinit var createCardActions: View
    private lateinit var multiRemoveActions: View
    private lateinit var formatCardActions: View
    private lateinit var closeCardActions: View
    private lateinit var cardMenuPanel: android.view.ViewGroup
    private val saves = mutableListOf<String>()
    private val saveDisplay = mutableListOf<String>()
    private var cardFile: File? = null
    private var cardUri: Uri? = null
    private var selectedSave: String? = null
    private var importButtonAnimationToken = 0
    private var importButtonTargetVisible = false
    private var saveAnimationToken = 0
    private var saveListExpanded = false
    private var cardUiReady = false
    private var batchModeActive = false
    private var controlsExpanded = true
    private var cardContentTransitionActive = false
    private var controlsAnimationToken = 0
    private var saveListInteractionBlocked = false
    private var listPreparingPreviews = false
    private var rowPreviewsReady = true
    private var previewLoadToken = 0
    private var pendingExportAll = false
    private var pendingExportFormat = "psu"
    private var pendingCardSizeMb = 8
    private var expandedPreviewActive = false
    private val toolbarGroupAnimations = mutableMapOf<View, ValueAnimator>()
    private val toolbarVisibilityTargets = mutableMapOf<View, Boolean>()
    private val toolbarVisibilityTokens = mutableMapOf<View, Int>()
    private val pendingImports = ArrayDeque<Uri>()
    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val openCard = 100
    private val exportPsu = 101
    private val importPsu = 102
    private val deleteSave = 103
    private val createCard = 104
    private val exportMany = 105

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLanguage.wrap(newBase))
    }

    override fun onDestroy() {
        toolbarGroupAnimations.values.toList().forEach { it.cancel() }
        toolbarGroupAnimations.clear()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        cardUri?.let { outState.putString(STATE_CARD_URI, it.toString()) }
        super.onSaveInstanceState(outState)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Keep the currently opened Memory Card when switching portrait/landscape.
        hideNavigationBar()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        hideNavigationBar()
        status = findViewById(R.id.status)
        cardName = findViewById(R.id.cardName)
        updateCardName(null)
        list = findViewById(R.id.saves)
        importButton = findViewById(R.id.importPsu)
        cardMenuButton = findViewById(R.id.cardMenuButton)
        cardInfoPanel = findViewById(R.id.cardInfoPanel)
        cardActionsRow = findViewById(R.id.cardActionsRow)
        openCardActions = findViewById(R.id.openCardActions)
        allSaveActions = findViewById(R.id.allSaveActions)
        multiExportActions = findViewById(R.id.multiExportActions)
        createCardActions = findViewById(R.id.createCardActions)
        multiRemoveActions = findViewById(R.id.multiRemoveActions)
        formatCardActions = findViewById(R.id.formatCardActions)
        closeCardActions = findViewById(R.id.closeCardActions)
        cardMenuPanel = findViewById(R.id.cardMenuPanel)
        adapter = SaveListAdapter(
            this,
            saves,
            saveDisplay,
            onSelect = { position ->
                selectedSave = saves.getOrNull(position)
            },
            onExport = { position ->
                selectSaveAt(position)
                showExportFormatChoice { format -> chooseExportTarget(format) }
            },
            onDelete = { position ->
                selectSaveAt(position)
                deleteSelectedSave()
            },
            onMultiModeChanged = { active, positions ->
                setMultiSaveActionsVisible(active)
                if (active) {
                    status.text = getString(R.string.save_games_selected_count, positions.size)
                } else {
                    updatePermanentStatus()
                }
            },
            onExpandPreview = { position, payload ->
                if (expandedPreviewActive) {
                    Unit
                } else if (payload.isNullOrBlank()) {
                    MyMCToast.show(this, getString(R.string.preview_preparing))
                } else {
                    expandedPreviewActive = true
                    val lines = saveDisplay.getOrNull(position).orEmpty().split("\n")
                    adapter.suspendVisiblePreviews()
                    list.postDelayed({
                        if (isFinishing || isDestroyed) {
                            expandedPreviewActive = false
                            adapter.resumeVisiblePreviews()
                            return@postDelayed
                        }
                        try {
                            SavePreviewDialog.show(
                                this,
                                lines.getOrElse(0) { getString(R.string.game_save_default) },
                                lines.getOrElse(1) { getString(R.string.save_serial_format, "—") },
                                lines.getOrElse(2) { getString(R.string.save_region_fallback) },
                                payload
                            ) {
                                expandedPreviewActive = false
                                adapter.resumeVisiblePreviews()
                            }
                        } catch (e: Exception) {
                            expandedPreviewActive = false
                            adapter.resumeVisiblePreviews()
                            MyMCToast.show(this, getString(R.string.preview_open_failed), e.message, true)
                        }
                    }, 160L)
                }
            }
        )
        list.adapter = adapter
        list.setOnTouchListener { _, _ -> saveListInteractionBlocked || listPreparingPreviews }
        findViewById<ImageButton>(R.id.open).setOnClickListener {
            startToolbarAction()
            confirmOpenCard()
        }
        importButton.setOnClickListener {
            startToolbarAction()
            choosePsu()
        }
        findViewById<ImageButton>(R.id.exportAllSaves).setOnClickListener {
            startToolbarAction()
            showExportFormatChoice(onCancel = ::finishToolbarAction) { format ->
                chooseAllExportFolder(format)
            }
        }
        findViewById<ImageButton>(R.id.createCard).setOnClickListener {
            startToolbarAction()
            confirmCreateCard()
        }
        findViewById<ImageButton>(R.id.closeCard).setOnClickListener {
            startToolbarAction()
            confirmCloseCard()
        }
        findViewById<ImageButton>(R.id.deleteAllSaves).setOnClickListener {
            startToolbarAction()
            confirmDeleteAllSaves()
        }
        findViewById<ImageButton>(R.id.exportManySaves).setOnClickListener {
            startToolbarAction()
            showExportFormatChoice(onCancel = ::finishToolbarAction) { format ->
                chooseMultiExportFolder(format)
            }
        }
        findViewById<ImageButton>(R.id.deleteManySaves).setOnClickListener {
            startToolbarAction()
            confirmDeleteSelectedSaves()
        }
        cardMenuButton.setOnClickListener {
            setCardContentExpanded(!controlsExpanded)
        }
        findViewById<ImageButton>(R.id.infoButton).setOnClickListener {
            ManualDialog.show(this) { confirmCloseApp() }
        }
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        state?.getString(STATE_CARD_URI)?.let { savedUri ->
            cardUri = Uri.parse(savedUri)
            loadCard(cardUri!!)
        }
    }

    private fun hideNavigationBar() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.navigationBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideNavigationBar()
    }

    private fun showConfirmDialog(
        title: String,
        message: String? = null,
        onCancel: (() -> Unit)? = null,
        onConfirm: () -> Unit
    ) {
        MyMCDialog.show(this, title, message, onCancel = onCancel, onConfirm = onConfirm)
    }

    private fun clearSelectionState() {
        if (::adapter.isInitialized && adapter.isMultiMode()) adapter.exitMultiMode()
        selectedSave = null
        list.clearChoices()
        adapter.clearSelection()
    }

    private fun startToolbarAction() {
        saveListInteractionBlocked = true
    }

    private fun finishToolbarAction() {
        saveListInteractionBlocked = false
    }

    private fun setCardContentExpanded(expanded: Boolean) {
        if (cardContentTransitionActive || controlsExpanded == expanded) return
        controlsExpanded = expanded
        cardContentTransitionActive = true
        saveListInteractionBlocked = true
        cardMenuButton.isEnabled = false
        val token = ++controlsAnimationToken
        val density = resources.displayMetrics.density
        val params = cardActionsRow.layoutParams
        val fullHeight = (60f * density).toInt()
        val shouldAnimateSaves = cardFile != null && saves.isNotEmpty() &&
            (!expanded || (rowPreviewsReady && !listPreparingPreviews))
        var toolbarFinished = false
        var savesFinished = !shouldAnimateSaves

        fun finishWhenReady() {
            if (
                token != controlsAnimationToken ||
                !toolbarFinished || !savesFinished
            ) return
            if (!expanded) {
                params.height = 0
                cardActionsRow.layoutParams = params
                cardActionsRow.visibility = View.INVISIBLE
                cardActionsRow.alpha = 1f
                cardActionsRow.translationY = 0f
            } else {
                setToolbarGroupEnabled(cardMenuPanel, true)
            }
            cardContentTransitionActive = false
            saveListInteractionBlocked = false
            cardMenuButton.isEnabled = true
        }

        cardActionsRow.animate().cancel()
        setToolbarGroupEnabled(cardMenuPanel, false)
        if (expanded) {
            params.height = fullHeight
            cardActionsRow.layoutParams = params
            cardActionsRow.visibility = View.VISIBLE
            cardActionsRow.alpha = 0f
            cardActionsRow.translationY = -10f * density
            if (cardFile != null && cardUiReady) setImportButtonVisible(true)
        } else {
            setImportButtonVisible(false)
            cardActionsRow.alpha = 1f
            cardActionsRow.translationY = 0f
        }

        cardActionsRow.animate()
            .alpha(if (expanded) 1f else 0f)
            .translationY(if (expanded) 0f else -10f * density)
            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
            .setDuration(460L)
            .withEndAction {
                if (token != controlsAnimationToken) return@withEndAction
                toolbarFinished = true
                finishWhenReady()
            }
            .start()

        if (shouldAnimateSaves) {
            animateSaveRows(expanded, if (expanded) 45L else 0L) {
                if (token != controlsAnimationToken) return@animateSaveRows
                savesFinished = true
                finishWhenReady()
            }
        } else {
            finishWhenReady()
        }
    }

    private fun setMultiSaveActionsVisible(visible: Boolean) {
        if (batchModeActive == visible) return
        batchModeActive = visible
        if (visible) {
            setToolbarGroupVisible(allSaveActions, false)
            setToolbarGroupVisible(formatCardActions, false)
        }
        setToolbarGroupVisible(multiExportActions, visible)
        setToolbarGroupVisible(multiRemoveActions, visible, if (visible) 100L else 0L)
        if (!visible) {
            refreshToolbarAvailability()
            if (controlsExpanded && cardFile != null && cardUiReady) {
                setImportButtonVisible(true)
            }
        }
    }

    private fun setToolbarGroupEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) {
                setToolbarGroupEnabled(view.getChildAt(index), enabled)
            }
        }
    }

    private fun measureToolbarGroupWidth(group: View): Int {
        val params = group.layoutParams
        val originalWidth = params.width
        params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        val height = when {
            params.height > 0 -> params.height
            group.height > 0 -> group.height
            else -> (54f * resources.displayMetrics.density).toInt()
        }
        group.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
        )
        val measuredWidth = group.measuredWidth.coerceAtLeast(1)
        params.width = originalWidth
        return measuredWidth
    }

    private fun animateToolbarGroup(
        group: View,
        show: Boolean,
        isCurrent: () -> Boolean
    ) {
        toolbarGroupAnimations.remove(group)?.cancel()
        setToolbarGroupEnabled(group, false)

        val params = group.layoutParams
        if (!show && group.visibility != View.VISIBLE) {
            group.visibility = View.GONE
            group.alpha = 1f
            group.translationX = 0f
            params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            group.layoutParams = params
            return
        }

        val targetWidth = measureToolbarGroupWidth(group)
        val offset = 26f * resources.displayMetrics.density
        val startWidth = if (group.visibility == View.VISIBLE && group.width > 0) group.width else 0
        val startAlpha = if (group.visibility == View.VISIBLE) group.alpha else 0f
        val startTranslation = if (group.visibility == View.VISIBLE) group.translationX else offset
        val endWidth = if (show) targetWidth else 0
        val endAlpha = if (show) 1f else 0f
        val endTranslation = if (show) 0f else offset

        params.width = startWidth
        group.layoutParams = params
        group.alpha = startAlpha
        group.translationX = startTranslation
        group.visibility = View.VISIBLE

        var cancelled = false
        val animator = ValueAnimator.ofFloat(0f, 1f)
        animator.duration = 1000L
        animator.interpolator = if (show) {
            PathInterpolator(0.2f, 0f, 0f, 1f)
        } else {
            PathInterpolator(0.4f, 0f, 0.2f, 1f)
        }
        animator.addUpdateListener { valueAnimator ->
            val fraction = valueAnimator.animatedValue as Float
            params.width = (startWidth + (endWidth - startWidth) * fraction).toInt()
            group.alpha = startAlpha + (endAlpha - startAlpha) * fraction
            group.translationX = startTranslation + (endTranslation - startTranslation) * fraction
            group.layoutParams = params
            cardMenuPanel.requestLayout()
        }
        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (toolbarGroupAnimations[group] === animator) {
                    toolbarGroupAnimations.remove(group)
                }
                if (cancelled || !isCurrent()) return
                if (show) {
                    params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                    group.layoutParams = params
                    group.alpha = 1f
                    group.translationX = 0f
                    group.visibility = View.VISIBLE
                    setToolbarGroupEnabled(group, true)
                } else {
                    group.visibility = View.GONE
                    params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                    group.layoutParams = params
                    group.alpha = 1f
                    group.translationX = 0f
                    setToolbarGroupEnabled(group, false)
                }
                cardMenuPanel.requestLayout()
            }
        })
        toolbarGroupAnimations[group] = animator
        animator.start()
    }

    private fun selectedMultiSaveNames(): List<String> =
        adapter.selectedMultiPositions().sorted().mapNotNull { saves.getOrNull(it) }

    private fun selectSaveAt(position: Int) {
        if (position !in saves.indices) return
        selectedSave = saves[position]
        adapter.selectPosition(position)
    }

    private fun updatePermanentStatus() {
        val file = cardFile
        if (file == null) {
            setImportButtonVisible(false)
            refreshToolbarAvailability()
            cardInfoPanel.setBackgroundResource(R.drawable.ps2_panel)
            status.text = getString(R.string.no_memory_card_open)
            return
        }
        cardInfoPanel.setBackgroundResource(R.drawable.card_info_selected_green)
        try {
            val api = Python.getInstance().getModule("mymc_api")
            val stats = org.json.JSONObject(api.callAttr("card_stats", file.absolutePath).toString())
            val freeBytes = stats.optLong("free_bytes", 0L)
            val freeKb = freeBytes / 1024L
            status.text = if (freeBytes <= 0L) {
                getString(R.string.save_games_found_full, saves.size)
            } else {
                getString(R.string.save_games_found_free, saves.size, freeKb)
            }
        } catch (_: Exception) {
            status.text = getString(R.string.save_games_found_count, saves.size)
        }
        refreshToolbarAvailability()
    }

    private fun setImportButtonVisible(visible: Boolean) {
        val shouldShow = visible
        importButtonTargetVisible = shouldShow
        val token = ++importButtonAnimationToken
        val offset = 18f * resources.displayMetrics.density
        importButton.animate().cancel()
        importButton.clearAnimation()
        if (shouldShow) {
            importButton.isClickable = true
            if (importButton.visibility != View.VISIBLE) {
                importButton.alpha = 0f
                importButton.translationX = offset
                importButton.visibility = View.VISIBLE
            }
            importButton.animate()
                .alpha(1f)
                .translationX(0f)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .setDuration(520)
                .withEndAction {
                    if (token == importButtonAnimationToken && importButtonTargetVisible) {
                        importButton.alpha = 1f
                        importButton.translationX = 0f
                        importButton.visibility = View.VISIBLE
                        importButton.isClickable = true
                    }
                }
                .start()
        } else {
            importButton.isClickable = false
            if (importButton.visibility != View.VISIBLE) {
                importButton.visibility = View.INVISIBLE
                importButton.alpha = 0f
                importButton.translationX = 0f
                return
            }
            importButton.animate()
                .alpha(0f)
                .translationX(offset)
                .setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
                .setDuration(520)
                .withEndAction {
                    if (token == importButtonAnimationToken && !importButtonTargetVisible) {
                        importButton.translationX = 0f
                        importButton.alpha = 0f
                        importButton.visibility = View.INVISIBLE
                        importButton.isClickable = false
                    }
                }
                .start()
        }
    }

    private fun setToolbarGroupVisible(group: View, visible: Boolean, delayMs: Long = 0L) {
        if (toolbarVisibilityTargets[group] == visible) return
        toolbarVisibilityTargets[group] = visible
        val token = (toolbarVisibilityTokens[group] ?: 0) + 1
        toolbarVisibilityTokens[group] = token
        if (!visible) {
            animateToolbarGroup(group, false) {
                toolbarVisibilityTokens[group] == token && toolbarVisibilityTargets[group] == false
            }
            return
        }
        setToolbarGroupEnabled(group, false)
        window.decorView.postDelayed({
            if (toolbarVisibilityTokens[group] != token || toolbarVisibilityTargets[group] != true) {
                return@postDelayed
            }
            animateToolbarGroup(group, true) {
                toolbarVisibilityTokens[group] == token && toolbarVisibilityTargets[group] == true
            }
        }, delayMs)
    }

    private fun refreshToolbarAvailability() {
        val ready = cardFile != null && cardUiReady
        if (batchModeActive) {
            setToolbarGroupVisible(openCardActions, true)
            setToolbarGroupVisible(allSaveActions, false)
            setToolbarGroupVisible(createCardActions, true, 80L)
            setToolbarGroupVisible(formatCardActions, false)
            setToolbarGroupVisible(closeCardActions, ready, if (ready) 160L else 0L)
            setToolbarGroupVisible(multiExportActions, true)
            setToolbarGroupVisible(multiRemoveActions, true, 100L)
            setImportButtonVisible(controlsExpanded && ready)
            return
        }
        setToolbarGroupVisible(openCardActions, true)
        setToolbarGroupVisible(allSaveActions, ready && saves.size > 1)
        setToolbarGroupVisible(createCardActions, true, 80L)
        setToolbarGroupVisible(formatCardActions, ready && saves.isNotEmpty(), if (ready) 120L else 0L)
        setToolbarGroupVisible(closeCardActions, ready, if (ready) 240L else 0L)
        setToolbarGroupVisible(multiExportActions, false)
        setToolbarGroupVisible(multiRemoveActions, false)
    }

    private fun scheduleCardContextActions() {
        setToolbarGroupVisible(allSaveActions, false)
        setToolbarGroupVisible(formatCardActions, false)
        setToolbarGroupVisible(closeCardActions, false)
        setToolbarGroupVisible(multiExportActions, false)
        setToolbarGroupVisible(multiRemoveActions, false)
        setImportButtonVisible(false)
        cardUiReady = false
        saveListExpanded = false
        if (saves.isNotEmpty()) {
            list.visibility = View.VISIBLE
            list.alpha = 0f
            listPreparingPreviews = true
        }
        val token = ++saveAnimationToken
        window.decorView.postDelayed({
            if (token != saveAnimationToken || cardFile == null) return@postDelayed
            cardUiReady = true
            refreshToolbarAvailability()
            if (controlsExpanded) setImportButtonVisible(true)
            if (controlsExpanded && ((rowPreviewsReady && !listPreparingPreviews) || saves.isEmpty())) {
                animateSaveRows(true)
            }
        }, 1000L)
    }

    private fun animateSaveRows(show: Boolean, delayMs: Long = 0L, after: (() -> Unit)? = null) {
        val token = ++saveAnimationToken
        val offset = 14f * resources.displayMetrics.density
        val children = (0 until list.childCount).map { list.getChildAt(it) }
        if (show) {
            list.visibility = View.VISIBLE
            list.alpha = 1f
            saveListExpanded = true
            children.forEach { child ->
                child.animate().cancel()
                child.alpha = 0f
                child.translationY = -offset
            }
        } else {
            saveListExpanded = false
        }
        val ordered = if (show) children else children.asReversed()
        ordered.forEachIndexed { index, child ->
            child.postDelayed({
                if (token != saveAnimationToken) return@postDelayed
                child.animate().cancel()
                child.animate()
                    .alpha(if (show) 1f else 0f)
                    .translationY(if (show) 0f else -offset)
                    .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                    .setDuration(300L)
                    .withLayer()
                    .start()
            }, delayMs + index * 45L)
        }
        val endDelay = delayMs + (ordered.size.coerceAtLeast(1) - 1) * 45L + 315L
        list.postDelayed({
            if (token != saveAnimationToken) return@postDelayed
            if (!show) list.visibility = View.INVISIBLE
            after?.invoke()
        }, endDelay)
    }

    private fun confirmCloseApp() {
        showConfirmDialog(getString(R.string.confirm_close_app)) {
            clearSelectionState()
            closeApp()
        }
    }

    private fun confirmCloseCard() {
        if (cardFile == null) {
            MyMCToast.show(this, getString(R.string.no_memory_card_open))
            finishToolbarAction()
            return
        }
        showConfirmDialog(getString(R.string.confirm_close_card), onCancel = ::finishToolbarAction) {
            closeCard()
        }
    }

    private fun confirmOpenCard() {
        showConfirmDialog(
            getString(R.string.confirm_open_card),
            getString(R.string.select_ps2_card_file),
            onCancel = ::finishToolbarAction
        ) {
            chooseCard()
        }
    }

    private fun confirmCreateCard() {
        showConfirmDialog(
            getString(R.string.confirm_create_card),
            getString(R.string.create_card_explanation),
            onCancel = ::finishToolbarAction
        ) {
            MyMCChoiceDialog.show(
                this,
                getString(R.string.choose_size),
                listOf("8 MB", "16 MB", "32 MB", "64 MB"),
                onCancel = ::finishToolbarAction
            ) { index ->
                pendingCardSizeMb = listOf(8, 16, 32, 64)[index]
                chooseCreateCard()
            }
        }
    }

    private fun confirmDeleteAllSaves() {
        val sourceCard = cardFile
        val destinationUri = cardUri
        if (sourceCard == null || destinationUri == null) {
            MyMCToast.show(this, getString(R.string.no_memory_card_open))
            finishToolbarAction()
            return
        }
        if (saves.isEmpty()) {
            MyMCToast.show(this, getString(R.string.card_has_no_save_games))
            finishToolbarAction()
            return
        }
        showConfirmDialog(
            getString(R.string.confirm_format_card),
            getString(R.string.format_card_count, saves.size),
            onCancel = ::finishToolbarAction
        ) {
            showConfirmDialog(
                getString(R.string.final_confirmation),
                getString(R.string.cannot_undo_continue),
                onCancel = ::finishToolbarAction
            ) {
                performDeleteAllSaves(sourceCard, destinationUri)
            }
        }
    }

    private fun performDeleteAllSaves(sourceCard: File, destinationUri: Uri) {
        val workingCard = File(cacheDir, "delete-all-${System.currentTimeMillis()}.ps2")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_formatting_card),
            getString(R.string.progress_updating_card_safely)
        )
        ioExecutor.execute {
            try {
                val api = Python.getInstance().getModule("mymc_api")
                val result = JSONObject(api.callAttr(
                    "delete_all_saves", sourceCard.absolutePath, workingCard.absolutePath
                ).toString())
                val snapshot = JSONObject(api.callAttr(
                    "card_snapshot", workingCard.absolutePath
                ).toString())
                val remaining = snapshot.getJSONArray("saves")
                if (remaining.length() != 0) {
                    throw IllegalStateException(getString(R.string.not_all_saves_removed))
                }
                copyFileToUri(workingCard, destinationUri)
                val refreshedCard = copyToCache(destinationUri)
                runOnUiThread {
                    progress.dismiss()
                    cardFile?.delete()
                    cardFile = refreshedCard
                    showCardContents(remaining, previewFile = refreshedCard)
                    val removed = result.optInt("removed", 0)
                    MyMCToast.show(
                        this,
                        getString(R.string.card_formatted),
                        getString(R.string.save_games_removed_count, removed),
                        true
                    )
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.format_card_failed), e.message, true)
                    finishToolbarAction()
                }
            } finally {
                workingCard.delete()
            }
        }
    }

    private fun deleteSelectedSave() {
        val sourceCard = cardFile
        val destinationUri = cardUri
        val save = selectedSave
        if (sourceCard == null || destinationUri == null || save == null) {
            MyMCToast.show(this, getString(R.string.select_game_save), getString(R.string.open_card_first))
            return
        }
        showConfirmDialog(getString(R.string.confirm_remove_game_save), save) {
            performDelete(save, sourceCard, destinationUri)
        }
    }

    private fun performDelete(save: String, sourceCard: File, destinationUri: Uri) {
        val workingCard = File(cacheDir, "delete-card-${System.currentTimeMillis()}.ps2")
        try {
            val api = Python.getInstance().getModule("mymc_api")
            api.callAttr("delete_save", sourceCard.absolutePath, save, workingCard.absolutePath)
            api.callAttr("list_saves", workingCard.absolutePath)
            copyFileToUri(workingCard, destinationUri)
            cardFile?.delete()
            cardFile = copyToCache(destinationUri)
            val arr = JSONArray(api.callAttr("list_saves", cardFile!!.absolutePath).toString())
            showCardContents(arr, previewFile = cardFile)
            MyMCToast.show(this, getString(R.string.game_save_removed), save)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.remove_game_save_failed), e.message, true)
        } finally {
            workingCard.delete()
        }
    }

    private fun formatSaveDisplay(obj: org.json.JSONObject): String {
        val title = obj.optString("title", obj.optString("name", getString(R.string.game_save_default)))
        val serial = obj.optString("serial", obj.optString("name", ""))
        val region = obj.optString("region", getString(R.string.unknown))
        val flag = obj.optString("flag", "🌐")
        val sizeBytes = obj.optLong("size_bytes", obj.optLong("size", 0L))
        val sizeText = when {
            sizeBytes >= 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f MB", sizeBytes / (1024.0 * 1024.0))
            sizeBytes >= 1024L -> "${(sizeBytes + 1023L) / 1024L} KB"
            else -> "$sizeBytes B"
        }
        return "$title\n${getString(R.string.save_serial_format, serial)}\n${getString(R.string.save_region_size_format, region, flag, sizeText)}"
    }

    private fun closeApp() {
        finishAndRemoveTask()
    }

    private fun updateCardName(uri: Uri?) {
        if (uri == null) {
            cardName.text = getString(R.string.memory_card_name_none)
            return
        }
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)
                }
            }
        } catch (_: Exception) { }
        cardName.text = getString(
            R.string.memory_card_name,
            name ?: uri.lastPathSegment ?: getString(R.string.selected_file)
        )
    }

    private fun closeCard() {
        setImportButtonVisible(false)
        cardUiReady = false
        val closingFile = cardFile
        cardFile = null
        cardUri = null
        clearSelectionState()
        updateCardName(null)
        updatePermanentStatus()
        MyMCToast.show(this, getString(R.string.card_closed))
        window.decorView.postDelayed({ closingFile?.delete() }, 5000L)
        animateSaveRows(false, 1000L) {
            closingFile?.delete()
            saves.clear()
            saveDisplay.clear()
            adapter.clearPreviewPayloads()
            adapter.notifyDataSetChanged()
            rowPreviewsReady = true
            listPreparingPreviews = false
            finishToolbarAction()
        }
    }

    private fun chooseCreateCard() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "MemoryCard-${pendingCardSizeMb}MB.ps2")
            addCategory(Intent.CATEGORY_OPENABLE)
        }, createCard)
    }

    private fun createCard(uri: Uri) {
        val tmp = File(cacheDir, "new-card-${System.currentTimeMillis()}.ps2")
        try {
            val api = Python.getInstance().getModule("mymc_api")
            api.callAttr("create_card", tmp.absolutePath, pendingCardSizeMb)
            copyFileToUri(tmp, uri)
            cardFile?.delete()
            cardUri = uri
            updateCardName(uri)
            cardFile = copyToCache(uri)
            saves.clear()
            saveDisplay.clear()
            adapter.clearPreviewPayloads()
            adapter.notifyDataSetChanged()
            selectedSave = null
            adapter.selectedPosition = -1
            list.clearChoices()
            updatePermanentStatus()
            scheduleCardContextActions()
            MyMCToast.show(this, getString(R.string.card_created), long = true)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.create_card_failed), e.message, true)
        } finally {
            tmp.delete()
            finishToolbarAction()
        }
    }

    private fun chooseCard() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, openCard)
    }

    private fun choosePsu() {
        if (cardFile == null || cardUri == null) {
            MyMCToast.show(this, getString(R.string.open_card_first))
            finishToolbarAction()
            return
        }
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/octet-stream", "*/*"))
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, importPsu)
    }

    private fun showExportFormatChoice(
        onCancel: (() -> Unit)? = null,
        onChoose: (String) -> Unit
    ) {
        val formats = listOf("PSU", "MAX", "CBS", "SPS", "XPS")
        MyMCChoiceDialog.show(
            this,
            getString(R.string.choose_export_format),
            formats,
            onCancel = onCancel
        ) { index ->
            onChoose(formats[index].lowercase(java.util.Locale.ROOT))
        }
    }

    private fun chooseExportTarget(format: String) {
        if (cardFile == null || selectedSave == null) {
            MyMCToast.show(this, getString(R.string.select_game_save), getString(R.string.open_card_first)); return
        }
        try {
            val api = Python.getInstance().getModule("mymc_api")
            val arr = JSONArray(api.callAttr("list_saves", cardFile!!.absolutePath).toString())
            var title = selectedSave!!
            var serial = selectedSave!!
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                if (obj.getString("name") == selectedSave) {
                    title = obj.optString("title", selectedSave!!)
                    serial = obj.optString("serial", selectedSave!!)
                    break
                }
            }
            val safeTitle = title.replace(Regex("[\\/:*?\"<>|\r\n]"), "_").replace(Regex("\\s+"), " ").trim().ifEmpty { selectedSave!! }
            val safeSerial = serial.replace(Regex("[\\/:*?\"<>|]"), "_").trim()
            val exportName = if (safeSerial.isNotEmpty() && safeSerial != safeTitle) "$safeTitle - $safeSerial" else safeTitle
            pendingExportFormat = format
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/octet-stream"
                putExtra(Intent.EXTRA_TITLE, "$exportName.${format.uppercase(java.util.Locale.ROOT)}")
                addCategory(Intent.CATEGORY_OPENABLE)
            }, exportPsu)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.prepare_export_failed), e.message, true)
        }
    }

    private fun chooseMultiExportFolder(format: String) {
        if (selectedMultiSaveNames().isEmpty()) {
            MyMCToast.show(this, getString(R.string.select_one_or_more_saves))
            finishToolbarAction()
            return
        }
        pendingExportAll = false
        pendingExportFormat = format
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }, exportMany)
    }

    private fun chooseAllExportFolder(format: String) {
        if (cardFile == null || saves.size <= 1) {
            MyMCToast.show(this, getString(R.string.export_all_requires_two))
            finishToolbarAction()
            return
        }
        pendingExportAll = true
        pendingExportFormat = format
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }, exportMany)
    }

    private fun exportSelectedSaves(treeUri: Uri) {
        val sourceCard = cardFile ?: run { finishToolbarAction(); return }
        val exportingAll = pendingExportAll
        val names = if (exportingAll) saves.toList() else selectedMultiSaveNames()
        val format = pendingExportFormat
        if (names.isEmpty()) {
            finishToolbarAction()
            return
        }
        val progress = MyMCProgressDialog.show(
            this,
            getString(
                if (exportingAll) R.string.progress_exporting_all_save_games
                else R.string.progress_exporting_save_games
            ),
            getString(R.string.progress_processing_items, names.size)
        )
        ioExecutor.execute {
            var exported = 0
            try {
                val api = Python.getInstance().getModule("mymc_api")
                val parent = DocumentsContract.buildDocumentUriUsingTree(
                    treeUri, DocumentsContract.getTreeDocumentId(treeUri)
                )
                val metadata = JSONArray(api.callAttr("list_saves", sourceCard.absolutePath).toString())
                val labels = mutableMapOf<String, String>()
                for (i in 0 until metadata.length()) {
                    val obj = metadata.getJSONObject(i)
                    val title = obj.optString("title", obj.optString("name", getString(R.string.game_save_default))).trim()
                    val serial = obj.optString("serial", "").trim()
                    labels[obj.optString("name")] =
                        if (serial.isNotEmpty() && title != serial) "$title - $serial" else title
                }
                val extension = format.uppercase(java.util.Locale.ROOT)
                names.forEachIndexed { index, name ->
                    val safeName = labels[name].orEmpty().replace(Regex("[\\/:*?\"<>|\\r\\n]"), "_").trim()
                        .ifEmpty { "GameSave-${index + 1}" }
                    val temp = File(cacheDir, "multi-export-${System.currentTimeMillis()}-$index.$format")
                    try {
                        api.callAttr("export_save_any", sourceCard.absolutePath, name, temp.absolutePath, format)
                        val destination = DocumentsContract.createDocument(
                            contentResolver, parent, "application/octet-stream", "$safeName.$extension"
                        ) ?: throw IllegalStateException(
                            getString(R.string.cannot_create_file, "$safeName.$extension")
                        )
                        copyFileToUri(temp, destination)
                        exported++
                    } finally {
                        temp.delete()
                    }
                }
                runOnUiThread {
                    progress.dismiss()
                    if (!exportingAll) adapter.exitMultiMode()
                    MyMCToast.show(this, getString(R.string.save_games_exported_count, exported), long = true)
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(
                            if (exportingAll) R.string.all_export_failed
                            else R.string.multi_export_failed
                        ),
                        e.message,
                        true
                    )
                    finishToolbarAction()
                }
            }
        }
    }

    private fun confirmDeleteSelectedSaves() {
        val names = selectedMultiSaveNames()
        if (names.isEmpty()) {
            MyMCToast.show(this, getString(R.string.select_one_or_more_saves))
            finishToolbarAction()
            return
        }
        showConfirmDialog(
            getString(R.string.confirm_remove_save_games, names.size),
            getString(R.string.selected_items_removed_permanently),
            onCancel = ::finishToolbarAction
        ) { performDeleteSelectedSaves(names) }
    }

    private fun performDeleteSelectedSaves(names: List<String>) {
        val sourceCard = cardFile ?: run { finishToolbarAction(); return }
        val destinationUri = cardUri ?: run { finishToolbarAction(); return }
        val workingCard = File(cacheDir, "delete-many-${System.currentTimeMillis()}.ps2")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_removing_save_games),
            getString(R.string.progress_updating_card_safely)
        )
        ioExecutor.execute {
            try {
                val api = Python.getInstance().getModule("mymc_api")
                val result = JSONObject(api.callAttr(
                    "delete_saves", sourceCard.absolutePath, JSONArray(names).toString(), workingCard.absolutePath
                ).toString())
                copyFileToUri(workingCard, destinationUri)
                val snapshot = JSONObject(api.callAttr("card_snapshot", workingCard.absolutePath).toString())
                runOnUiThread {
                    progress.dismiss()
                    val previous = cardFile
                    cardFile = workingCard
                    previous?.delete()
                    adapter.exitMultiMode()
                    showCardContents(snapshot.getJSONArray("saves"), previewFile = workingCard)
                    MyMCToast.show(
                        this,
                        getString(R.string.save_games_removed_count, result.optInt("count", 0)),
                        long = true
                    )
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                workingCard.delete()
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.remove_save_games_failed), e.message, true)
                    finishToolbarAction()
                }
            }
        }
    }

    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        if (result != RESULT_OK || data == null) {
            finishToolbarAction()
            return
        }
        val uri = data.data
        when (request) {
            openCard -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                cardUri = uri
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                } catch (_: Exception) { }
                loadCard(uri)
                finishToolbarAction()
            }
            exportPsu -> uri?.let { export(it) }
            importPsu -> {
                val selected = mutableListOf<Uri>()
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) selected += clip.getItemAt(i).uri
                }
                uri?.let { if (it !in selected) selected += it }
                startBatchImport(selected)
            }
            createCard -> if (uri != null) createCard(uri) else finishToolbarAction()
            exportMany -> if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) { }
                exportSelectedSaves(uri)
            } else finishToolbarAction()
        }
    }

    private fun startBatchImport(uris: List<Uri>) {
        if (uris.isEmpty()) {
            finishToolbarAction()
            return
        }
        pendingImports.clear()
        pendingImports.addAll(uris)
        processNextImport()
    }

    private fun processNextImport() {
        if (pendingImports.isEmpty()) {
            finishToolbarAction()
            return
        }
        val next = pendingImports.removeFirst()
        importPsu(next) { processNextImport() }
    }

    private fun copyToCache(uri: Uri): File {
        val out = File(cacheDir, "card-${System.currentTimeMillis()}.ps2")
        contentResolver.openInputStream(uri).use { rawInput ->
            val input = BufferedInputStream(requireNotNull(rawInput), 256 * 1024)
            BufferedOutputStream(out.outputStream(), 256 * 1024).use { output ->
                input.copyTo(output, 256 * 1024)
            }
        }
        return out
    }

    private fun copyFileToUri(file: File, uri: Uri) {
        contentResolver.openOutputStream(uri, "wt").use { rawOutput ->
            BufferedOutputStream(requireNotNull(rawOutput), 256 * 1024).use { output ->
                BufferedInputStream(file.inputStream(), 256 * 1024).use { input ->
                    input.copyTo(output, 256 * 1024)
                }
                output.flush()
            }
        }
        verifyWrittenUriSize(file, uri)
    }

    private fun verifyWrittenUriSize(source: File, uri: Uri) {
        try {
            contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                val writtenSize = descriptor.statSize
                if (writtenSize >= 0L && writtenSize != source.length()) {
                    throw IllegalStateException(
                        getString(R.string.incomplete_file, source.length(), writtenSize)
                    )
                }
            }
        } catch (e: IllegalStateException) {
            throw e
        } catch (_: Exception) {
            // Some document providers don't expose statSize. The closed and
            // flushed buffered stream remains the authoritative write result.
        }
    }

    private fun loadCard(uri: Uri) {
        try {
            val file = copyToCache(uri)
            val api = Python.getInstance().getModule("mymc_api")
            val state = api.callAttr("card_state", file.absolutePath).toString()

            when (state) {
                "valid" -> {
                    cardUiReady = false
                    cardFile?.delete()
                    cardFile = file
                    cardUri = uri
                    updateCardName(uri)
                    showCardContents(api, file)
                    scheduleCardContextActions()
                }
                "blank" -> {
                    showConfirmDialog(
                        getString(R.string.card_unformatted),
                        getString(R.string.confirm_format_unformatted)
                    ) {
                        formatBlankCard(uri, file)
                    }
                }
                else -> {
                    file.delete()
                    MyMCToast.show(
                        this,
                        getString(R.string.card_invalid),
                        getString(R.string.selected_file_invalid),
                        true
                    )
                }
            }
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.open_card_failed), e.message, true)
        }
    }

    private fun formatBlankCard(uri: Uri, sourceFile: File) {
        val formatted = File(cacheDir, "formatted-card-${System.currentTimeMillis()}.ps2")
        try {
            val api = Python.getInstance().getModule("mymc_api")
            api.callAttr("format_blank_card", sourceFile.absolutePath, formatted.absolutePath)
            api.callAttr("list_saves", formatted.absolutePath)
            copyFileToUri(formatted, uri)

            cardFile?.delete()
            cardFile = copyToCache(uri)
            cardUri = uri
            updateCardName(uri)
            showCardContents(api, cardFile!!)
            updatePermanentStatus()
            scheduleCardContextActions()
            MyMCToast.show(this, getString(R.string.card_formatted), long = true)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.format_card_failed), e.message, true)
        } finally {
            sourceFile.delete()
            formatted.delete()
        }
    }

    private fun showCardContents(api: com.chaquo.python.PyObject, file: File) {
        val result = api.callAttr("list_saves", file.absolutePath).toString()
        showCardContents(JSONArray(result), previewFile = file)
    }

    private fun showCardContents(arr: JSONArray, updateStatus: Boolean = true, previewFile: File? = cardFile) {
        if (adapter.isMultiMode()) adapter.exitMultiMode()
        saves.clear()
        saveDisplay.clear()
        val ordered = (0 until arr.length())
            .map { arr.getJSONObject(it) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) {
                it.optString("title", it.optString("name", ""))
            })
        for (obj in ordered) {
            saves += obj.getString("name")
            saveDisplay += formatSaveDisplay(obj)
        }
        adapter.selectedPosition = -1
        adapter.clearPreviewPayloads()
        adapter.notifyDataSetChanged()
        selectedSave = null
        list.clearChoices()
        rowPreviewsReady = saves.isEmpty()
        if (saves.isNotEmpty()) {
            saveListExpanded = false
            listPreparingPreviews = true
            list.visibility = View.VISIBLE
            list.alpha = 0f
        } else {
            listPreparingPreviews = false
            list.alpha = 1f
        }
        if (updateStatus) updatePermanentStatus()
        refreshToolbarAvailability()
        if (previewFile != null) {
            loadRowPreviews(previewFile, saves.toList())
        } else if (cardUiReady && saves.isEmpty()) {
            animateSaveRows(true)
        }
    }

    private fun loadRowPreviews(file: File, names: List<String>) {
        val loadToken = ++previewLoadToken
        if (names.isEmpty()) {
            rowPreviewsReady = true
            listPreparingPreviews = false
            if (cardUiReady && controlsExpanded && !saveListExpanded) animateSaveRows(true)
            return
        }
        val expectedPath = file.absolutePath
        ioExecutor.execute {
            val payloads = linkedMapOf<String, String>()
            val snapshots = linkedMapOf<String, android.graphics.Bitmap>()
            try {
                val api = Python.getInstance().getModule("mymc_api")
                names.chunked(8).forEach { batch ->
                    var result: JSONObject? = null
                    for (attempt in 0..2) {
                        try {
                            result = JSONObject(api.callAttr(
                                "get_icon_payloads", expectedPath, JSONArray(batch).toString()
                            ).toString())
                            break
                        } catch (_: Exception) {
                            if (attempt == 2) result = null
                        }
                    }
                    batch.forEach { name ->
                        var payload = result?.optJSONObject(name)
                        if (payload?.optBoolean("ok", false) != true) {
                            for (attempt in 0..1) {
                                try {
                                    val retry = JSONObject(api.callAttr(
                                        "get_icon_payload", expectedPath, name
                                    ).toString())
                                    payload = retry
                                    if (retry.optBoolean("ok", false)) break
                                } catch (_: Exception) { }
                            }
                        }
                        payload?.let {
                            val json = it.toString()
                            payloads[name] = json
                            snapshots[name] = Ps2IconSnapshotRenderer.render(json)
                        }
                    }
                }
            } catch (_: Exception) {
                // A missing or invalid icon must not affect save management.
            } finally {
                runOnUiThread {
                    if (loadToken != previewLoadToken || cardFile?.absolutePath != expectedPath) {
                        return@runOnUiThread
                    }
                    adapter.setPreviewPayloads(payloads, snapshots)
                    rowPreviewsReady = true
                    list.postDelayed({
                        if (
                            loadToken != previewLoadToken ||
                            cardFile?.absolutePath != expectedPath
                        ) return@postDelayed
                        listPreparingPreviews = false
                        if (cardUiReady && controlsExpanded && !saveListExpanded) animateSaveRows(true)
                    }, 40L)
                }
            }
        }
    }

    private fun importPsu(psuUri: Uri, onFinished: () -> Unit) {
        val sourceCard = cardFile ?: run { onFinished(); return }
        val destinationUri = cardUri ?: run { onFinished(); return }
        val displayName = try {
            contentResolver.query(psuUri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else ""
            } ?: ""
        } catch (_: Exception) { "" }
        val ext = displayName.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("psu", "max", "sps", "xps", "cbs")) {
            onFinished()
            MyMCToast.show(
                this,
                getString(R.string.unsupported_format),
                getString(R.string.supported_import_formats),
                true
            )
            return
        }

        val temp = File(cacheDir, "import-${System.currentTimeMillis()}.$ext")
        val workingCard = File(cacheDir, "import-card-${System.currentTimeMillis()}.ps2")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_importing_game_save),
            getString(R.string.progress_reading_card)
        )
        ioExecutor.execute {
            try {
                contentResolver.openInputStream(psuUri).use { rawInput ->
                    val input = BufferedInputStream(requireNotNull(rawInput), 256 * 1024)
                    BufferedOutputStream(temp.outputStream(), 256 * 1024).use { output ->
                        input.copyTo(output, 256 * 1024)
                    }
                }
                val info = JSONObject(Python.getInstance().getModule("mymc_api").callAttr(
                    "import_save_any", sourceCard.absolutePath, temp.absolutePath, workingCard.absolutePath
                ).toString())
                runOnUiThread {
                    progress.dismiss()
                    val commit = { commitPreparedImport(workingCard, destinationUri, info, onFinished) }
                    if (info.optBoolean("overwritten", false)) {
                        MyMCDialog.show(this, getString(R.string.confirm_overwrite_game_save), onCancel = {
                            workingCard.delete()
                            onFinished()
                        }) { commit() }
                    } else commit()
                }
            } catch (e: Exception) {
                workingCard.delete()
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(e)
                    onFinished()
                }
            } finally {
                temp.delete()
            }
        }
    }

    private fun commitPreparedImport(
        workingCard: File,
        destinationUri: Uri,
        info: JSONObject,
        onFinished: () -> Unit
    ) {
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_saving_card),
            getString(R.string.progress_writing_safely)
        )
        ioExecutor.execute {
            try {
                copyFileToUri(workingCard, destinationUri)
                val previousCard = cardFile
                cardFile = workingCard
                previousCard?.delete()
                val snapshot = JSONObject(Python.getInstance().getModule("mymc_api")
                    .callAttr("card_snapshot", workingCard.absolutePath).toString())
                runOnUiThread {
                    progress.dismiss()
                    showCardContents(snapshot.getJSONArray("saves"), updateStatus = false)
                    val freeKb = snapshot.getJSONObject("stats").optLong("free_bytes", 0L) / 1024L
                    status.text = getString(R.string.save_games_found_free, saves.size, freeKb)
                    val title = info.optString(
                        "title",
                        info.optString("save_name", getString(R.string.game_save_default))
                    ).trim()
                    val serial = info.optString("serial", "").trim()
                    val gameName = if (serial.isNotEmpty() && title != serial) "$title - $serial" else title
                    val toastTitle = if (info.optBoolean("overwritten", false)) {
                        getString(R.string.game_save_overwritten)
                    } else {
                        getString(R.string.game_save_imported)
                    }
                    MyMCToast.show(this, toastTitle, gameName, true)
                    onFinished()
                }
            } catch (e: Exception) {
                workingCard.delete()
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(e)
                    onFinished()
                }
            }
        }
    }

    private fun showImportFailure(error: Exception) {
        val detail = error.message ?: error.toString()
        val normalized = detail.lowercase(java.util.Locale.ROOT)
        val noSpace = normalized.contains("sem espaço") ||
            normalized.contains("sem espaco") ||
            normalized.contains("no space") ||
            normalized.contains("errno 28")
        if (noSpace) {
            MyMCToast.show(
                this,
                getString(R.string.no_space_on_card),
                long = true
            )
        } else {
            MyMCToast.show(this, getString(R.string.import_failed), detail, true)
        }
    }

    private fun export(uri: Uri) {
        val file = cardFile ?: return
        val save = selectedSave ?: return
        val format = pendingExportFormat
        val tmp = File(cacheDir, "export-${System.currentTimeMillis()}.$format")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_exporting_game_save),
            getString(R.string.progress_generating_format)
        )
        ioExecutor.execute {
            try {
                Python.getInstance().getModule("mymc_api").callAttr(
                    "export_save_any", file.absolutePath, save, tmp.absolutePath, format
                )
                copyFileToUri(tmp, uri)
                runOnUiThread {
                    progress.dismiss()
                    updatePermanentStatus()
                    MyMCToast.show(
                        this,
                        getString(R.string.game_save_exported),
                        format.uppercase(java.util.Locale.ROOT)
                    )
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.export_failed), e.message, true)
                }
            } finally {
                tmp.delete()
            }
        }
    }
}

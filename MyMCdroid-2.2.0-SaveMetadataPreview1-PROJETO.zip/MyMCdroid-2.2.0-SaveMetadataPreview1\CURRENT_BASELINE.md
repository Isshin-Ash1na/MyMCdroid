# Base oficial atual

`MyMCdroid 2.2.0 — Animated Icon Preview 1`

Consulte `BASELINE_ANIMATED_ICON_PREVIEW1.md` para a especificação consolidada.

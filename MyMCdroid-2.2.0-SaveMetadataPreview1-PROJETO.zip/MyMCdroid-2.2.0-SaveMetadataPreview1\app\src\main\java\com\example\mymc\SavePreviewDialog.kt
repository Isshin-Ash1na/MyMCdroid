package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView

object SavePreviewDialog {
    fun show(
        context: Context,
        title: String,
        serial: String,
        region: String,
        payload: String,
        onClosed: () -> Unit
    ) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_save_preview, null)
        dialog.setContentView(view)
        val panel = view.findViewById<View>(R.id.expandedPreviewPanel)
        val preview = view.findViewById<SavePreviewView>(R.id.expandedPreview)
        val rotation = view.findViewById<Button>(R.id.expandedPreviewRotation)
        val iconAnimation = view.findViewById<ImageButton>(R.id.expandedPreviewAnimation)
        view.findViewById<TextView>(R.id.expandedPreviewTitle).text = title
        view.findViewById<TextView>(R.id.expandedPreviewSerial).text = serial
        view.findViewById<TextView>(R.id.expandedPreviewRegion).text = region
        preview.setCompactMode(false)
        preview.setInteractive(true)
        preview.setIconAnimationEnabled(true)
        preview.setOnRenderReadyListener {
            preview.queryIconAnimationAvailability { available ->
                if (!available || iconAnimation.visibility == View.VISIBLE) return@queryIconAnimationAvailability
                iconAnimation.alpha = 0f
                iconAnimation.visibility = View.VISIBLE
                iconAnimation.animate().alpha(1f).setDuration(180L).start()
            }
        }
        preview.setPayload(payload)
        preview.setRotationEnabled(true)
        var rotating = true
        rotation.setOnClickListener {
            rotating = !rotating
            preview.setRotationEnabled(rotating)
            rotation.text = context.getString(
                if (rotating) R.string.pause_rotation else R.string.continue_rotation
            )
        }
        var iconAnimating = true
        iconAnimation.setOnClickListener {
            iconAnimating = !iconAnimating
            preview.setIconAnimationPlaying(iconAnimating)
            iconAnimation.setImageResource(
                if (iconAnimating) R.drawable.ic_animation_pause else R.drawable.ic_animation_play
            )
            iconAnimation.contentDescription = context.getString(
                if (iconAnimating) R.string.pause_icon_animation
                else R.string.continue_icon_animation
            )
        }
        var closing = false
        var callbackSent = false
        fun restoreMiniatures() {
            if (callbackSent) return
            callbackSent = true
            onClosed()
        }
        fun close() {
            if (closing) return
            closing = true
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            restoreMiniatures()
            panel.animate().alpha(0f).scaleX(0.985f).scaleY(0.985f)
                .translationY(5f * context.resources.displayMetrics.density)
                .setDuration(160L).withEndAction { dialog.dismiss() }.start()
        }
        view.findViewById<ImageButton>(R.id.expandedPreviewClose).setOnClickListener { close() }
        dialog.setOnCancelListener { close() }
        dialog.setOnDismissListener {
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            preview.suspendRenderer()
            restoreMiniatures()
        }
        val width = (context.resources.displayMetrics.widthPixels * 0.88f).toInt()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
            attributes = attributes.apply { dimAmount = 0.72f; windowAnimations = 0 }
        }
        panel.alpha = 0f; panel.scaleX = 0.98f; panel.scaleY = 0.98f
        panel.translationY = 6f * context.resources.displayMetrics.density
        dialog.show()
        dialog.window?.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f)).setDuration(240L).start()
    }
}

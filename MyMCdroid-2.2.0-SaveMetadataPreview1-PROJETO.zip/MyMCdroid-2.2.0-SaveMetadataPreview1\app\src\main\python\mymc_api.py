from pathlib import Path
import json
import hashlib
from mymc_core import open_card
from mymc_export import export_psu, export_any, find_save
from ps2_writer import WritableCard

_METADATA_FILE = Path.home() / "mymc_save_metadata.json"


def _metadata_signature(card, save):
    """Stable signature for a save independent of its memory-card position/name."""
    h = hashlib.sha256()
    for entry in sorted(card.save_files(save), key=lambda x: x["name"].lower()):
        name = entry["name"]
        data = card.extract_file(entry["first_cluster"], entry["size"])
        h.update(name.encode("utf-8", "replace"))
        h.update(b"\0")
        h.update(data)
        h.update(b"\0")
    return h.hexdigest()


def _load_metadata_cache():
    try:
        if _METADATA_FILE.exists():
            obj = json.loads(_METADATA_FILE.read_text(encoding="utf-8"))
            return obj if isinstance(obj, dict) else {}
    except Exception:
        pass
    return {}


def _save_metadata_cache(cache):
    try:
        _METADATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = _METADATA_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(cache, ensure_ascii=False), encoding="utf-8")
        tmp.replace(_METADATA_FILE)
    except Exception:
        pass


def _remember_metadata(card, save, title, serial, region, flag):
    if not serial:
        return
    cache = _load_metadata_cache()
    cache[_metadata_signature(card, save)] = {
        "title": title or save.name,
        "serial": serial,
        "region": region,
        "flag": flag,
    }
    _save_metadata_cache(cache)


def _serial_from_files(card, save):
    """Find a PS2 serial in save entry names or textual file data."""
    import re
    candidates = []
    for entry in card.save_files(save):
        candidates.append(entry["name"])
        # Serial IDs are normally present in a small metadata/header file.
        # Limit scanning to the first 64 KiB of each file to avoid expensive
        # scans through large game-specific save blobs.
        try:
            data = card.extract_file(entry["first_cluster"], min(entry["size"], 65536))
            candidates.append(data.decode("latin1", "ignore"))
        except Exception:
            pass
    for candidate in candidates:
        m = re.search(r"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}", str(candidate), re.I)
        if m:
            serial = _normalize_serial(m.group(0))
            if serial:
                return serial
    return ""

def _decode_icon_title(data):
    """Extract the two title lines from a PS2 icon.sys file.

    icon.sys stores a title split at the byte offset in the header.  The
    original mymc implementation treats the two parts separately; doing the
    same avoids decoding the padding/binary fields as part of the title.
    """
    import struct

    if len(data) < 964:
        return None
    try:
        fmt = (
            "<4s2xH4xL"
            "16s16s16s16s16s16s16s16s16s16s16s"
            "68s64s64s64s512x"
        )
        fields = list(struct.unpack(fmt, data[:964]))
        offset = int(fields[1])
        title_raw = fields[14]

        def decode(raw):
            raw = raw.split(b"\x00", 1)[0]
            return raw.decode("shift_jis", "replace").strip()

        # The offset is a byte offset into the 512-byte title field.
        if 0 < offset < len(title_raw):
            first = decode(title_raw[:offset])
            second = decode(title_raw[offset:])
            title = " ".join(x for x in (first, second) if x).strip()
        else:
            title = decode(title_raw)

        # Some saves contain embedded line/control separators.  Never expose
        # literal escape sequences in the Android list.
        title = title.replace("\\n", " ").replace("\r", " ").replace("\n", " ")
        title = " ".join(title.split())
        return title or None
    except Exception:
        return None


def _normalize_serial(serial):
    """Normalize container-specific PS2 serial prefixes to the game serial.

    SharkPort/X-Port and CodeBreaker commonly store a region prefix such as
    BASLUS/BISLPM.  The leading B is a container/database marker; the
    consumer-facing game serial is SLUS/SLPM/etc.
    """
    import re
    s = (serial or "").upper().strip()
    m = re.search(r"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPS|SLKA|SCAJ|SCED|SLED)-(\d{5})", s)
    if not m:
        return ""
    token = m.group(0)
    prefix, number = token.split("-", 1)
    aliases = {
        "BASLUS": "SLUS", "BASCUS": "SCUS",
        "BESLES": "SLES", "BESCES": "SCES",
        "BISLPS": "SLPS", "BISLPM": "SLPM",
        "BISCPH": "SCPH", "BISCPS": "SCPS",
    }
    prefix = aliases.get(prefix, prefix)
    return f"{prefix}-{number}"


def _extract_serial(save_name, game_title=None, container_serial=None):
    """Extract and normalize a PS2 game serial.

    Prefer a serial embedded in the source container (MAX/CBS/SPS/XPS),
    then a serial in the imported save directory name, then known title
    fallbacks.  This is important for GameShark/CodeBreaker saves whose
    directory name can be a friendly label rather than a serial.
    """
    import re
    for candidate in (container_serial, save_name):
        s = (candidate or "").upper()
        m = re.search(r"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}", s)
        if m:
            normalized = _normalize_serial(m.group(0))
            if normalized:
                return normalized

    t = re.sub(r"[^A-Z0-9]+", "", (game_title or save_name or "").upper())
    known = {
        "ONIMUSHA3": "SLUS-20694",
        "ONIMUSHA3DEMONSIEGE": "SLUS-20694",
    }
    return known.get(t, "")


def _serial_from_container(path):
    """Find a serial embedded in a save-container header.

    The supported container formats keep the game ID in plain ASCII.  We
    scan only the header/metadata area first, avoiding false matches inside
    arbitrary save data.
    """
    import re
    raw = Path(path).read_bytes()
    ext = Path(path).suffix.lower()
    if ext in (".sps", ".xps"):
        hay = raw[:8192]
    elif ext == ".cbs":
        hay = raw[:4096]
    elif ext == ".max":
        hay = raw[:4096]
    else:
        hay = raw[:4096]
    matches = re.findall(rb"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}", hay, re.I)
    for raw_serial in matches:
        serial = _normalize_serial(raw_serial.decode("ascii", "ignore"))
        if serial:
            return serial
    return ""


def _region_info(serial):
    s = (serial or "").upper()
    if s.startswith(("BASLUS-", "BASCUS-", "SCUS-", "SLUS-")):
        return "NTSC-U", "🇺🇸"
    if s.startswith(("BESLES-", "BESCES-", "SLES-", "SLED-", "SCES-", "SCED-", "PBPX-")):
        return "PAL", "🇪🇺"
    if s.startswith(("BISLPS-", "BISLPM-", "SLPS-", "SLPM-", "SCPS-")):
        return "NTSC-J", "🇯🇵"
    return "Desconhecida", "🌐"


def save_metadata(card, save):
    title = None
    entries = card.save_files(save)
    for entry in entries:
        if entry["name"].lower() == "icon.sys":
            data = card.extract_file(entry["first_cluster"], entry["size"])
            title = _decode_icon_title(data)
            break

    cache = _load_metadata_cache()
    cached = cache.get(_metadata_signature(card, save), {})
    serial = _extract_serial(save.name, title)
    if not serial:
        serial = _serial_from_files(card, save)
    if not serial:
        serial = cached.get("serial", "")
    region, flag = _region_info(serial)
    if not serial and cached.get("region"):
        region, flag = cached.get("region", "Desconhecida"), cached.get("flag", "🌐")
    if cached.get("title") and (not title or title == save.name):
        title = cached.get("title")
    return {
        "name": save.name,
        "title": title or save.name,
        "serial": serial,
        "region": region,
        "flag": flag,
        "size": save.size,
        "size_bytes": sum(e["size"] for e in entries if not e.get("is_directory")),
        "first_cluster": save.first_cluster,
    }


def _card_stats_obj(card):
    free_clusters = 0
    for index in range(card.alloc_end):
        if (card.lookup_fat(index) & 0x80000000) == 0:
            free_clusters += 1
    free_bytes = free_clusters * card.cluster_size
    total_bytes = card.alloc_end * card.cluster_size
    used_bytes = max(0, total_bytes - free_bytes)
    return {
        "free_bytes": free_bytes,
        "used_bytes": used_bytes,
        "total_bytes": total_bytes,
        "free_percent": round((free_bytes * 100.0 / total_bytes), 1) if total_bytes else 0.0,
    }

def card_stats(card_path):
    """Return reliable free-space information from the PS2 FAT."""
    return json.dumps(_card_stats_obj(open_card(card_path)), ensure_ascii=False)

def list_saves(card_path):
    card = open_card(card_path)
    return json.dumps(
        [save_metadata(card, s) for s in card.saves()],
        ensure_ascii=False
    )

def card_snapshot(card_path):
    """List saves and space from one buffered card load after a mutation."""
    card = open_card(card_path)
    return json.dumps({
        "saves": [save_metadata(card, s) for s in card.saves()],
        "stats": _card_stats_obj(card),
    }, ensure_ascii=False)

def export_save(card_path, save_name, destination):
    card = open_card(card_path)
    save = find_save(card, save_name)
    count, size = export_psu(card, save, destination)
    return json.dumps({"save": save_name, "files": count, "bytes": size}, ensure_ascii=False)

def export_save_any(card_path, save_name, destination, format_name):
    card = open_card(card_path)
    save = find_save(card, save_name)
    count, size = export_any(card, save, destination, format_name)
    return json.dumps({"save": save_name, "format": format_name, "files": count, "bytes": size}, ensure_ascii=False)

def delete_save(card_path, save_name, destination):
    """Delete one save from a card image and write the result to destination."""
    return WritableCard(card_path, destination).delete_save(save_name)

def delete_saves(card_path, save_names_json, destination):
    """Delete selected saves in one working-card transaction."""
    names = json.loads(save_names_json)
    removed = WritableCard(card_path, destination).delete_saves(names)
    return json.dumps({"removed": removed, "count": len(removed)}, ensure_ascii=False)

def delete_all_saves(card_path, destination):
    """Delete all saves in a working copy and return the removed count."""
    removed = WritableCard(card_path, destination).delete_all_saves()
    return json.dumps({"removed": removed}, ensure_ascii=False)


def _psu_metadata(psu_path):
    """Read the imported save name and game title from a PSU without changing it."""
    from save_formats import load_any
    imported = load_any(psu_path)
    title = None
    for f in imported.files:
        if f.name.lower() == "icon.sys":
            title = _decode_icon_title(f.data)
            break
    return imported, title or imported.name


def _matching_save_names(card, serial, region):
    """Return all existing saves with the same normalized Serial ID + region.

    Directory names are deliberately not used as the identity because saves
    imported from MAX/CBS/SPS/XPS often use different container-specific
    names. Empty/unknown serials never match anything.
    """
    serial = _normalize_serial(serial)
    if not serial or region == "Desconhecida":
        return []
    matches = []
    for save in card.saves():
        meta = save_metadata(card, save)
        if meta.get("serial") == serial and meta.get("region") == region:
            matches.append(save.name)
    return matches


def import_save(card_path, psu_path, destination, save_name=None):
    """Import a PSU, replacing an existing save with the same Serial ID + region."""
    imported, imported_title = _psu_metadata(psu_path)
    target = save_name or imported.name
    serial = _extract_serial(target, imported_title)
    region, flag = _region_info(serial)
    card = open_card(card_path)
    matching_names = _matching_save_names(card, serial, region)
    exact_existing = any(s.name == target for s in card.saves())
    replace_names = sorted(set(matching_names + ([target] if exact_existing else [])))

    result = WritableCard(card_path, destination).import_files(
        imported.files, target, replace_existing=True,
        replace_names=replace_names, save_metadata=imported
    )
    return json.dumps({
        "files": result,
        "overwritten": bool(replace_names),
        "save_name": target,
        "title": imported_title,
        "serial": serial,
        "region": region,
        "flag": flag,
    }, ensure_ascii=False)


def import_save_any(card_path, save_path, destination, save_name=None):
    from save_formats import load_any
    imported = load_any(save_path)
    imported_name, files = imported
    target = save_name or imported_name

    imported_title = None
    for f in files:
        if f.name.lower() == "icon.sys":
            imported_title = _decode_icon_title(f.data)
            break

    serial = _extract_serial(
        target, imported_title, _serial_from_container(save_path)
    )
    if not serial:
        import re
        for f in files:
            m = re.search(
                r"(?:BASLUS|BASCUS|BESLES|BESCES|BISLPS|BISLPM|BISCPH|BISCPS|"
                r"SLUS|SCUS|SLES|SCES|SLPS|SLPM|SCPS|SLKA|SCAJ|SCED|SLED)-\d{5}",
                f.name, re.I
            )
            if m:
                serial = _normalize_serial(m.group(0))
                if serial:
                    break

    region, flag = _region_info(serial)
    card = open_card(card_path)
    matching_names = _matching_save_names(card, serial, region)
    exact_existing = any(s.name == target for s in card.saves())
    replace_names = sorted(set(matching_names + ([target] if exact_existing else [])))

    result = WritableCard(card_path, destination).import_files(
        files, target, replace_existing=True, replace_names=replace_names,
        save_metadata=imported
    )
    overwritten = bool(replace_names)

    # Persist metadata against the newly-created entry so it remains available
    # even when its directory name is a friendly label without a serial.
    if serial:
        out_card = open_card(destination)
        new_save = next((s for s in out_card.saves() if s.name == target), None)
        if new_save is not None:
            _remember_metadata(
                out_card, new_save, imported_title or target,
                serial, region, flag
            )

    return json.dumps({
        "files": result, "overwritten": overwritten, "save_name": target,
        "title": imported_title or target, "serial": serial,
        "region": region, "flag": flag
    }, ensure_ascii=False)

def create_card(destination, size_mb=8):
    from ps2_formatter import create_memory_card
    size_mb = int(size_mb)
    if size_mb not in (8, 16, 32, 64):
        raise ValueError("Tamanho de Memory Card não suportado")
    return create_memory_card(destination, pages_per_card=16384 * (size_mb // 8))


def card_state(card_path):
    """Return 'valid', 'blank', or 'invalid' for a PS2 memory-card image."""
    from pathlib import Path
    p = Path(card_path)
    data = p.read_bytes()
    # A PCSX2-created, completely erased image is raw 0xFF.
    if data and all(b == 0xFF for b in data):
        if len(data) % 528 == 0:
            return "blank"
        return "invalid"
    try:
        card = open_card(card_path)
        # Force a root/FAT read so malformed images are not classified as valid.
        card.root_entries()
        return "valid"
    except Exception:
        return "invalid"


def format_blank_card(source, destination):
    """Format an erased raw image, preserving its original capacity."""
    from pathlib import Path
    from ps2_formatter import create_memory_card
    size = Path(source).stat().st_size
    if size % 528 != 0:
        raise ValueError("Tamanho de imagem não suportado para formatação.")
    pages = size // 528
    if pages < 16384 or pages % 16 != 0:
        raise ValueError("Capacidade da memory card não é compatível com o formato PS2.")
    return create_memory_card(destination, pages_per_card=pages)


def _get_icon_payload_for_card(card, save_name):
    """Return PS2ICON candidates for the selected save.

    The normal/copy/delete icon filenames are defined by ``icon.sys`` and may
    be completely unrelated to ``icon.icn`` (for example ``game.icn``,
    ``slime1.ico`` or ``bio4.ico``).  Resolve those references first, using a
    case-insensitive filename lookup, then fall back to header discovery.
    """
    import base64
    import struct

    save = find_save(card, save_name)
    entries = card.save_files(save)
    file_entries = [e for e in entries if not e.get("is_directory") and e["size"] > 0]
    by_name = {e["name"].casefold(): e for e in file_entries}

    candidates = []
    seen = set()
    icon_sys_refs = []
    diagnostics = []

    def read_entry(entry):
        try:
            return card.extract_file(entry["first_cluster"], entry["size"])
        except Exception as exc:
            diagnostics.append(f'{entry["name"]}: leitura falhou ({exc})')
            return None

    def add_candidate(entry, reason, referenced_as=None):
        key = (entry["first_cluster"], entry["size"])
        if key in seen:
            return
        raw = read_entry(entry)
        if raw is None or len(raw) < 20:
            return
        magic = int.from_bytes(raw[0:4], "little")
        if magic != 0x00010000:
            diagnostics.append(f'{entry["name"]}: cabeçalho 0x{magic:08X} não é PS2ICON')
            return
        seen.add(key)
        candidates.append({
            "file": entry["name"],
            "reason": reason,
            "referenced_as": referenced_as or "",
            "size": entry["size"],
            "icon": base64.b64encode(raw).decode("ascii"),
        })

    # Resolve exact normal/copy/delete icon filenames from icon.sys.
    icon_sys_entry = by_name.get("icon.sys")
    if icon_sys_entry is not None and icon_sys_entry["size"] >= 964:
        raw = read_entry(icon_sys_entry)
        if raw is not None and len(raw) >= 964:
            try:
                fmt = (
                    "<4s2xH4xL"
                    "16s16s16s16s16s16s16s16s16s16s16s"
                    "68s64s64s64s512x"
                )
                fields = struct.unpack(fmt, raw[:964])
                # fields 15, 16 and 17 are normal, copy and delete icons.
                for label, value in zip(("normal", "copy", "delete"), fields[15:18]):
                    name = value.split(b"\0", 1)[0].decode("shift_jis", "replace").strip()
                    if not name:
                        continue
                    icon_sys_refs.append({"role": label, "name": name})
                    entry = by_name.get(name.casefold())
                    if entry is not None:
                        add_candidate(entry, "icon.sys", label)
                    else:
                        diagnostics.append(f'icon.sys refere {label}="{name}", mas o ficheiro não existe')
            except Exception as exc:
                diagnostics.append(f"icon.sys inválido: {exc}")

    # Conventional names next.  This includes uncommon .ico/.icn names even
    # when icon.sys is malformed or missing.
    for entry in file_entries:
        lower = entry["name"].casefold()
        if lower.endswith((".icn", ".ico")) or lower.startswith("icon"):
            add_candidate(entry, "filename")

    # Last fallback: inspect every reasonably sized file for the PS2ICON magic.
    for entry in file_entries:
        if entry["size"] > 2 * 1024 * 1024:
            continue
        key = (entry["first_cluster"], entry["size"])
        if key in seen:
            continue
        try:
            head = card.extract_file(entry["first_cluster"], min(entry["size"], 20))
        except Exception:
            continue
        if len(head) >= 4 and int.from_bytes(head[:4], "little") == 0x00010000:
            add_candidate(entry, "signature")

    if not candidates:
        return json.dumps({
            "ok": False,
            "error": "Nenhum ficheiro PS2ICON válido encontrado no save.",
            "icon_sys_refs": icon_sys_refs,
            "files": [e["name"] for e in file_entries],
            "diagnostics": diagnostics,
        }, ensure_ascii=False)

    return json.dumps({
        "ok": True,
        "candidates": candidates,
        "icon_sys_refs": icon_sys_refs,
        "diagnostics": diagnostics,
        "file": candidates[0]["file"],
        "icon": candidates[0]["icon"],
    }, ensure_ascii=False)


def get_icon_payload(card_path, save_name):
    return _get_icon_payload_for_card(open_card(card_path), save_name)


def get_icon_payloads(card_path, save_names_json):
    """Load multiple row-preview payloads from one Memory Card read."""
    card = open_card(card_path)
    names = json.loads(save_names_json)
    result = {}
    for name in names:
        try:
            result[name] = json.loads(_get_icon_payload_for_card(card, name))
        except Exception as exc:
            result[name] = {"ok": False, "error": str(exc)}
    return json.dumps(result, ensure_ascii=False)

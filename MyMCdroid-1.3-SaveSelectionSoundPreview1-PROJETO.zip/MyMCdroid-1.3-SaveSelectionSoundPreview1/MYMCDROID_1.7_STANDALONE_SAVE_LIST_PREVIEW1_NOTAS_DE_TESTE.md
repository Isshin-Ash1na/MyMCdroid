# MyMCdroid 1.7 — Standalone Save List Preview 1

## Testes principais

1. Abra dois ou mais Game Saves individuais, misturando arquivo e pasta quando possível.
2. Confirme que todos aparecem no painel **Lista de Game Saves individuais** e permanecem acessíveis pelo seletor e pelo deslizamento lateral.
3. Selecione uma linha e valide os botões **Exportar**, **Transferir** (com um Memory Card aberto) e **Fechar Game Save**.
4. Feche um item da lista e confirme que somente a sessão é removida; o arquivo ou a pasta de origem deve permanecer no armazenamento.
5. Toque novamente na miniatura selecionada e confirme que o render ampliado mantém exportar, transferir, arquivos internos, data/hora e ID/região.
6. Em um Game Save individual em pasta, altere o ID/serial e confirme no gerenciador de arquivos que a própria pasta recebeu o novo nome compatível.
7. Feche o último item com e sem um Memory Card aberto e confirme o retorno correto à última página disponível.

## Compatibilidade preservada

- Game Saves individuais: `.PSU`, `.MAX`, `.CBS`, `.SPS`, `.XPS` e pasta ARMSX2/PCSX2.
- Memory Cards em arquivo `.PS2` e em pasta.
- Transferência com confirmação de sobrescrita por Serial ID + região.
- Interface, Manual, sons e idiomas Português (Brasil) e Inglês.

## Verificações executadas

- compilação Kotlin completa das fontes: aprovada;
- compilação dos recursos Android e paridade PT/EN: aprovadas;
- regressões de Memory Card em pasta e editor interno: aprovadas;
- pacote contém somente o projeto-fonte, sem APK compilado.

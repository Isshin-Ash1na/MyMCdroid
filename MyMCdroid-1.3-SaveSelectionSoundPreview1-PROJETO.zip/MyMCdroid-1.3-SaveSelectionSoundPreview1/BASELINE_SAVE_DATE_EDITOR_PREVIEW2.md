# MyMCdroid 1.0 — Base oficial

- Versão aprovada: **1.0 — Save Date Editor Preview 2**
- Data de aprovação: **22/08/2026**
- Estado: **Base oficial**
- APK: **não incluído**

## Funcionalidades consolidadas neste ciclo

- editor de arquivos internos do Game Save: exportar, substituir, adicionar, renomear e remover;
- alteração do ID raiz e recálculo de Região/Serial ID;
- alteração de data e hora com conversão entre o JST interno do Memory Card e o fuso do BIOS/emulador;
- fuso do sistema PS2 configurável, com GMT+04:30 inicial conforme a referência aprovada;
- data e hora exibidas no render ampliado abaixo de Região/Tamanho;
- permanência no render ampliado após confirmar ou cancelar alterações;
- atualização do conteúdo e do ícone 3D dentro do próprio painel ampliado;
- ícone circular de alerta nos diálogos de renomear, data/hora e ID/Região;
- referência oficial do myMCpp adicionada à aba Sobre;
- suporte preservado a Memory Card `.ps2`, Memory Card em pasta e PSU/MAX/CBS/SPS/XPS;
- interface, Manual, Sobre, idiomas, sons, múltiplos Memory Cards e identidade visual preservados.

## Continuidade

Todo novo desenvolvimento deverá partir desta base. O próximo ciclo deverá avançar para a versão **1.1**.

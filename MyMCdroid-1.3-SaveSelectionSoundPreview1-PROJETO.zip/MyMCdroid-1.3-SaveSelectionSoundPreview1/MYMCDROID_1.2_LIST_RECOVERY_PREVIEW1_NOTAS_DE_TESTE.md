# MyMCdroid 1.2 — List Recovery Preview 1

## Nomes de Memory Card

1. Abra pelo menos três Memory Cards, incluindo um arquivo ou pasta com nome longo.
2. Inicie a transferência de um Game Save e abra a escolha do Memory Card de destino.
3. Confirme que cada nome ocupa as linhas necessárias, sem cortar letras na parte inferior.
4. Para Memory Card em pasta, confirme que aparece o nome da pasta, não o caminho completo do armazenamento.

## Recuperação da lista

1. Com um Memory Card contendo muitos Game Saves, role para o meio da lista.
2. Alterne rapidamente entre dois ou mais Memory Cards.
3. Transfira um Game Save e confira o Memory Card de destino.
4. Remova Game Saves em posições diferentes da lista.
5. Feche um Memory Card e continue rolando o Memory Card que assumir a tela.
6. Repita as operações antes e depois de selecionar um Game Save.

## Resultado esperado

Nenhuma linha deve permanecer transparente ou formar um espaço vazio. Os Game Saves devem reaparecer por completo após cada animação, mantendo miniatura, nome, Serial ID, região e tamanho.

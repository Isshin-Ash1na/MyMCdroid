"""Generate the original MyMCdroid Neon Memory interface sound pack."""
from __future__ import annotations

import argparse
import math
import random
import struct
import wave
from pathlib import Path


SAMPLE_RATE = 22050
TAU = math.tau


def envelope(t: float, duration: float, attack: float = 0.018, release: float = 0.12) -> float:
    fade_in = min(1.0, t / max(attack, 0.001))
    fade_out = min(1.0, (duration - t) / max(release, 0.001))
    return max(0.0, min(fade_in, fade_out))


def chirp(t: float, start_hz: float, end_hz: float, duration: float) -> float:
    slope = (end_hz - start_hz) / max(duration, 0.001)
    return math.sin(TAU * (start_hz * t + 0.5 * slope * t * t))


def pulse(t: float, start: float, duration: float, frequency: float) -> float:
    if t < start or t >= start + duration:
        return 0.0
    local = t - start
    return math.sin(TAU * frequency * local) * envelope(local, duration, 0.008, duration * 0.72)


def render(duration: float, synth) -> list[float]:
    count = int(SAMPLE_RATE * duration)
    samples = [synth(index / SAMPLE_RATE, duration) for index in range(count)]
    peak = max((abs(value) for value in samples), default=1.0)
    gain = 0.82 / max(peak, 1.0)
    return [max(-1.0, min(1.0, value * gain)) for value in samples]


def write_wav(path: Path, samples: list[float]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = b"".join(struct.pack("<h", round(value * 32767)) for value in samples)
    with wave.open(str(path), "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(SAMPLE_RATE)
        output.writeframes(pcm)


def app_open(t: float, duration: float) -> float:
    rise = chirp(t, 170, 430, duration) * 0.30
    triad = (
        pulse(t, 0.10, 0.42, 330) * 0.32
        + pulse(t, 0.21, 0.38, 495) * 0.28
        + pulse(t, 0.34, 0.32, 660) * 0.34
    )
    shimmer = math.sin(TAU * 1320 * t) * envelope(t, duration, 0.24, 0.24) * 0.08
    return (rise + triad + shimmer) * envelope(t, duration, 0.02, 0.18)


def import_sound(t: float, duration: float) -> float:
    inward = chirp(t, 980, 300, 0.28) * envelope(t, 0.28, 0.012, 0.15) * 0.58 if t < 0.28 else 0.0
    accepted = pulse(t, 0.23, 0.15, 660) * 0.42
    return inward + accepted


def export_sound(t: float, duration: float) -> float:
    outward = chirp(t, 280, 1020, 0.29) * envelope(t, 0.29, 0.012, 0.15) * 0.55 if t < 0.29 else 0.0
    released = pulse(t, 0.23, 0.15, 820) * 0.40
    return outward + released


def transfer_sound(t: float, duration: float) -> float:
    first = chirp(t, 360, 760, 0.20) * envelope(t, 0.20, 0.01, 0.10) * 0.46 if t < 0.20 else 0.0
    local = t - 0.16
    second = chirp(local, 460, 940, 0.24) * envelope(local, 0.24, 0.01, 0.14) * 0.52 if 0 <= local < 0.24 else 0.0
    return first + second


def remove_sound(t: float, duration: float) -> float:
    rng = random.Random(int(t * SAMPLE_RATE) + 4701)
    drop = chirp(t, 290, 82, duration) * envelope(t, duration, 0.004, 0.18) * 0.62
    snap = (rng.random() * 2 - 1) * envelope(t, 0.065, 0.002, 0.05) * 0.24 if t < 0.065 else 0.0
    return drop + snap


def confirm_sound(t: float, duration: float) -> float:
    return pulse(t, 0.0, 0.10, 640) * 0.52 + pulse(t, 0.065, 0.10, 900) * 0.58


def cancel_sound(t: float, duration: float) -> float:
    return pulse(t, 0.0, 0.10, 520) * 0.50 + pulse(t, 0.065, 0.10, 310) * 0.52


def card_transition(t: float, duration: float) -> float:
    rng = random.Random(int(t * SAMPLE_RATE) + 991)
    noise = (rng.random() * 2 - 1) * 0.11
    glide = chirp(t, 410, 690, duration) * 0.36
    return (noise + glide) * envelope(t, duration, 0.018, 0.15)


def function_transition(t: float, duration: float) -> float:
    airy = chirp(t, 620, 920, duration) * 0.32
    harmonic = math.sin(TAU * 1240 * t) * 0.10
    return (airy + harmonic) * envelope(t, duration, 0.012, 0.12)


def scroll_tick(t: float, duration: float) -> float:
    decay = math.exp(-34 * t)
    return (math.sin(TAU * 1180 * t) * 0.46 + math.sin(TAU * 1760 * t) * 0.18) * decay


SOUNDS = {
    "sound_app_open.wav": (0.68, app_open),
    "sound_import.wav": (0.38, import_sound),
    "sound_export.wav": (0.38, export_sound),
    "sound_transfer.wav": (0.43, transfer_sound),
    "sound_remove.wav": (0.30, remove_sound),
    "sound_confirm.wav": (0.18, confirm_sound),
    "sound_cancel.wav": (0.18, cancel_sound),
    "sound_card_transition.wav": (0.28, card_transition),
    "sound_function_transition.wav": (0.20, function_transition),
    "sound_scroll_tick.wav": (0.075, scroll_tick),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    for filename, (duration, synth) in SOUNDS.items():
        write_wav(args.output / filename, render(duration, synth))
    total = sum((args.output / name).stat().st_size for name in SOUNDS)
    print(f"generated {len(SOUNDS)} sounds ({total} bytes)")


if __name__ == "__main__":
    main()

"""Regression checks for the expanded-preview internal file editor."""
from __future__ import annotations

import json
import tempfile
from pathlib import Path

from folder_card import FolderCardWriter, create_folder_card
from mymc_api import (
    _serialize_ps2_datetime,
    add_save_file,
    change_save_datetime,
    delete_save_file,
    export_save_folder,
    get_save_datetime,
    list_save_files,
    read_save_file,
    rename_save_file,
    rename_save_root,
)
from mymc_core import open_card
from ps2_formatter import create_memory_card
from ps2_writer import WritableCard
from save_formats import ImportedFile, ImportedSave


OLD_ID = "BASLUS-12345SAVE"
NEW_ID = "BESLES-54321SAVE"
CREATED = (9, 8, 7, 6, 5, 2024)
MODIFIED = (19, 18, 17, 16, 7, 2025)


def source_save():
    files = [
        ImportedFile(OLD_ID, b"root-linked-data", created=CREATED, modified=MODIFIED),
        ImportedFile("icon.sys", b"PS2D" + bytes(range(64)), created=CREATED, modified=MODIFIED),
        ImportedFile("DATA.BIN", bytes(range(256)) * 4, created=CREATED, modified=MODIFIED),
    ]
    return ImportedSave(OLD_ID, files, created=CREATED, modified=MODIFIED)


def file_names(card_path, save_name):
    return [item["name"] for item in json.loads(list_save_files(str(card_path), save_name))]


def exercise_editor(source, root):
    root.mkdir(parents=True, exist_ok=True)
    addition = root / "addition.bin"
    addition.write_bytes(b"new-file" * 97)

    added = root / ("added-folder" if source.is_dir() else "added.ps2")
    add_save_file(str(source), OLD_ID, str(addition), "EXTRA.DAT", str(added))
    assert read_save_file(str(added), OLD_ID, "EXTRA.DAT") == addition.read_bytes()

    renamed = root / ("renamed-folder" if source.is_dir() else "renamed.ps2")
    rename_save_file(str(added), OLD_ID, "EXTRA.DAT", "RENAMED.DAT", str(renamed))
    assert "EXTRA.DAT" not in file_names(renamed, OLD_ID)
    assert read_save_file(str(renamed), OLD_ID, "RENAMED.DAT") == addition.read_bytes()

    removed = root / ("removed-folder" if source.is_dir() else "removed.ps2")
    delete_save_file(str(renamed), OLD_ID, "RENAMED.DAT", str(removed))
    assert "RENAMED.DAT" not in file_names(removed, OLD_ID)

    changed = root / ("region-folder" if source.is_dir() else "region.ps2")
    result = json.loads(rename_save_root(str(removed), OLD_ID, NEW_ID, str(changed)))
    assert result["region"] == "PAL"
    assert result["renamed_files"] == 1
    assert [item.name for item in open_card(changed).saves()] == [NEW_ID]
    assert NEW_ID in file_names(changed, NEW_ID)
    assert OLD_ID not in file_names(changed, NEW_ID)
    assert read_save_file(str(changed), NEW_ID, NEW_ID) == b"root-linked-data"
    assert open_card(changed).check() == []

    exported_folder = root / "renamed-id-folder-export"
    folder_result = json.loads(export_save_folder(str(changed), NEW_ID, str(exported_folder)))
    assert folder_result["folder_name"] == NEW_ID

    ps2_timezone = 270
    before_date = json.loads(get_save_datetime(str(changed), NEW_ID, ps2_timezone))
    dated = root / ("dated-folder" if source.is_dir() else "dated.ps2")
    date_result = json.loads(change_save_datetime(
        str(changed), NEW_ID, 2026, 8, 5, 14, 30, 27, ps2_timezone, str(dated)
    ))
    assert date_result["modified"]["display"] == "05/08/2026 14:30:27"
    assert date_result["modified"]["stored_display"] == "05/08/2026 19:00:27"
    after_date = json.loads(get_save_datetime(str(dated), NEW_ID, ps2_timezone))
    assert after_date["created"] == before_date["created"]
    assert after_date["modified"]["display"] == "05/08/2026 14:30:27"
    assert open_card(dated).check() == []
    changed = dated

    duplicate_target = root / ("duplicate-folder" if source.is_dir() else "duplicate.ps2")
    try:
        add_save_file(str(changed), NEW_ID, str(addition), "DATA.BIN", str(duplicate_target))
        raise AssertionError("duplicate internal name accepted")
    except FileExistsError:
        pass

    invalid_target = root / ("invalid-folder" if source.is_dir() else "invalid.ps2")
    try:
        rename_save_file(str(changed), NEW_ID, "DATA.BIN", "../DATA.BIN", str(invalid_target))
        raise AssertionError("invalid PS2 name accepted")
    except ValueError as error:
        assert "INVALID_PS2_NAME" in str(error)


def run():
    reference = _serialize_ps2_datetime((9, 51, 6, 27, 10, 2025), 270)
    assert reference["display"] == "27/10/2025 02:21:09"
    assert reference["stored_display"] == "27/10/2025 06:51:09"

    with tempfile.TemporaryDirectory(prefix="mymcdroid_internal_editor_") as temp:
        root = Path(temp)
        imported = source_save()

        blank_image = root / "blank.ps2"
        source_image = root / "source.ps2"
        create_memory_card(str(blank_image))
        WritableCard(blank_image, source_image).import_files(
            imported.files, imported.name, save_metadata=imported
        )
        exercise_editor(source_image, root / "image")

        blank_folder = root / "blank-folder"
        source_folder = root / "source-folder"
        create_folder_card(blank_folder)
        FolderCardWriter(blank_folder, source_folder).import_files(
            imported.files,
            imported.name,
            save_metadata=imported,
            host_directory_name=imported.name,
        )
        exercise_editor(source_folder, root / "folder")

    print("internal file editor: image/folder add/rename/remove/date/region OK")


if __name__ == "__main__":
    run()

# MyMCdroid 1.6 — Standalone Save Action Preview 1

## Testes principais

1. Inicie o aplicativo sem Memory Card aberto.
2. Confirme a sequência: disquete Abrir Game Save individual, seguido por Abrir Memory Card.
3. Toque no disquete e teste as opções Game Save em arquivo e Game Save em pasta.
4. Toque em Abrir Memory Card e confirme que aparecem somente Memory Card em arquivo e Memory Card em pasta.
5. Abra um Memory Card e verifique se o disquete continua disponível na primeira posição.
6. Ative as opções em lote e confirme que o botão de Game Save individual permanece visível e alinhado.

## Regressão

- Abrir Game Saves individuais em PSU, MAX, CBS, SPS, XPS e pasta ARMSX2/PCSX2.
- Fechar apenas o render pelo X e encerrar a sessão pelo botão Fechar Game Save.
- Exportar, editar e transferir um Game Save individual.
- Abrir Memory Cards .PS2 e Memory Cards em pasta.
- Verificar a nova ordem e os textos no Manual em português brasileiro e inglês.

Projeto-fonte para testes. APK não incluído.

# MyMCdroid 1.8 — Standalone Save List Flow Preview 1

## Testes principais

1. Abra dois ou mais Game Saves individuais e feche o render ampliado pelo X. Confirme que o aplicativo permanece na Lista de Game Saves individuais e conserva o item selecionado.
2. Alterne entre Memory Cards e a lista individual pelo seletor e por deslizamento. Verifique a retração e a reaparição suave e sequencial das linhas.
3. Transfira um Game Save pelo render ampliado. Confirme que o Memory Card de destino é aberto e o item transferido fica selecionado.
4. Abra um Game Save individual em pasta e altere o ID/região. Quando solicitado, selecione a pasta que contém a pasta desse Game Save, não a própria pasta do Game Save.
5. Confirme que a pasta física foi renomeada, que o render continua aberto e que a lista usa o novo ID/URI.
6. Repita a alteração: a autorização persistida deve evitar uma nova solicitação enquanto continuar válida.
7. Cancele a escolha da pasta pai e teste também uma pasta incorreta. O Game Save não deve ser alterado e o render deve permanecer aberto.

## Compatibilidade a preservar

- Memory Cards em arquivo `.PS2` e em pasta.
- Game Saves `.PSU`, `.MAX`, `.CBS`, `.SPS`, `.XPS` e em pasta.
- Verificação de sobrescrita por Serial ID + região.
- Edição de arquivos internos, data/hora, ID/região, exportação e transferência.

Pacote do projeto sem APK compilado.

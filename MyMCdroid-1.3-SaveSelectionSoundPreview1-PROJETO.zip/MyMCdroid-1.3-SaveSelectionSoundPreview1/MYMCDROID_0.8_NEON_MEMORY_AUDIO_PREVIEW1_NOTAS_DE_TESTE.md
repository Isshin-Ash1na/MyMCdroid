# MyMCdroid 0.8 — Neon Memory Audio Preview 1

Prévia criada a partir da base oficial 0.7. O pacote não contém APK compilado.

## Testes recomendados

1. Abra o app e confirme o efeito curto de inicialização.
2. Teste Sim e Não nos diálogos e também o cancelamento pelo botão Voltar.
3. Importe, exporte, transfira e remova Game Saves, verificando que o som ocorre somente após sucesso.
4. Alterne entre dois Memory Cards para conferir o panorama esquerdo/direito.
5. Retraia e reabra funções pelo ícone do Memory Card e ative/desative o modo em lote.
6. Role manualmente a lista de Game Saves e confirme que o efeito não fica contínuo ou excessivo.
7. Em Configurações, desative os sons, reative e teste diferentes volumes.
8. Ative o modo silencioso do aparelho e confirme que os efeitos não são reproduzidos.
9. Repita os fluxos em Português (Brasil) e Inglês.
10. Confirme que PSU, MAX, CBS, SPS, XPS e Game Save em pasta continuam funcionando.

# Abertura de Game Save individual

## Decisão de implementação

O arquivo selecionado é lido pelo mesmo pipeline de importação já usado pelo MyMCdroid para PSU, MAX, CBS, SPS e XPS. Em segundo plano, o aplicativo cria um Memory Card temporário de 8 MB no cache, importa nele exatamente um Game Save e utiliza as APIs consolidadas de metadados, arquivos internos e render 3D.

Essa abordagem evita duplicar os leitores de formato e mantém a visualização isolada coerente com a importação real. O Memory Card temporário nunca aparece na lista de cartões abertos e é removido ao fechar o render.

## Operações

- Exportar: usa o cartão temporário como origem e permite PSU, MAX, CBS, SPS, XPS ou pasta.
- Transferir: quando existe um Memory Card aberto, grava o Game Save no cartão selecionado por meio de cópia de trabalho e confirmação.
- Arquivos internos: listagem e exportação são permitidas; alterações ficam ocultas no modo isolado para não produzir mudanças apenas temporárias e enganosas.
- Remover: oculto no modo isolado, pois não existe um Memory Card de origem para atualizar.

## Referências

- PS2 Save Builder: https://www.ps2savetools.com/download/ps2-save-builder/
- myMCpp: https://github.com/PCSX2/myMCpp
- Android Storage Access Framework: https://developer.android.com/guide/topics/providers/document-provider

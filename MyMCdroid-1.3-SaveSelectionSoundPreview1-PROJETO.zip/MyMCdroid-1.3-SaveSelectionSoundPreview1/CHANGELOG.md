# MyMCdroid 1.3 — Save Selection Sound Preview 1

## Novo efeito Neon Memory
- Adicionado um som inédito e original de seleção de Game Save.
- O efeito de 165 ms combina um ataque tátil curto com duas camadas tonais ascendentes.
- O arquivo é mono, 44,1 kHz e compacto para preservar o tamanho do aplicativo.

## Aplicação do som
- O efeito toca ao selecionar um Game Save diferente na lista.
- Durante as opções em lote, o mesmo efeito toca ao acrescentar outro Game Save à seleção.
- Desmarcar um item não reproduz o efeito.
- O som respeita a opção Sons da Interface, o volume configurado, o modo silencioso e o volume de mídia.

## Interface
- Configurações e traduções atualizadas para citar o feedback de seleção.
- Versão atualizada para 1.3.
- A base oficial 1.2 permanece preservada até a aprovação desta revisão.

# MyMCdroid 1.2 — List Recovery Preview 1

## Memory Cards com nomes longos
- As opções do seletor de destino passam a ter altura dinâmica e texto multilinha, sem cortar a parte inferior do nome.
- Memory Cards em pasta usam o nome real da pasta em vez do caminho completo retornado pela URI do Android.
- O fallback de nome para arquivos também extrai somente o último componente legível do caminho.

## Estabilidade da lista
- Animações sequenciais usam atrasos canceláveis no próprio animador, eliminando callbacks antigos sobre linhas recicladas.
- Toda linha reutilizada pelo ListView tem transparência, deslocamento, escala e visibilidade restaurados antes de receber outro Game Save.
- Fechar Memory Card, transferir, remover ou recarregar a lista invalida animações anteriores e normaliza as linhas visíveis.
- Ao final de cada retração ou aparição, o estado visual de todas as linhas atuais é consolidado.

## Interface
- Versão atualizada para 1.2.
- A base oficial 1.1 permanece preservada até a aprovação desta revisão.

# MyMCdroid 1.1 — Memory Card Focus Base

## Fluxo principal simplificado
- Removida a função Abrir Game Save individual, incluindo botão, seletor, lista, sessões persistentes, navegação lateral e transferência associada.
- O fluxo do aplicativo volta a ser concentrado exclusivamente nos Memory Cards abertos em arquivo .PS2 ou pasta compatível com ARMSX2/PCSX2.
- A importação e exportação de Game Saves pelos Memory Cards continuam compatíveis com .PSU, .MAX, .CBS, .SPS, .XPS e pasta.

## Render ampliado
- Removidos do render ampliado os botões Exportar Game Save, Transferir Game Save e Remover Game Save.
- O render ampliado conserva zoom, rotação, animação, data/hora, edição de ID/região e gerenciamento dos arquivos internos.
- Exportar, Transferir e Remover Game Save continuam disponíveis na linha do Game Save selecionado, quando aplicável.

## Interface e documentação
- Removidos textos, ícones e recursos internos exclusivos do fluxo de Game Save individual.
- Manual, tela Sobre e traduções em português brasileiro e inglês atualizados.
- A antiga numeração provisória 1.9 foi redefinida como versão oficial 1.1.
- Esta versão passa a ser a nova base oficial do projeto.

# MyMCdroid 1.8 — Standalone Save List Flow Preview 1

## Navegação e animações
- Fechar o render ampliado de um Game Save individual mantém o aplicativo na Lista de Game Saves individuais e preserva a seleção.
- Transferir pelo render ampliado abre o Memory Card que recebeu o Game Save e seleciona o item transferido.
- A lista individual passa a usar retração e reaparição sequencial, além da transição horizontal já aplicada entre Memory Cards.

## Alteração segura de ID/região em pasta
- A renomeação deixa de tentar modificar diretamente a raiz escolhida, operação bloqueada pelo Android.
- Na primeira alteração de ID/região, o aplicativo solicita a pasta que contém diretamente o Game Save e persiste essa autorização pelo Storage Access Framework.
- A pasta física, a URI da sessão, a lista e o render ampliado permanecem sincronizados após a alteração.
- Selecionar uma pasta pai incorreta ou cancelar a autorização não modifica o Game Save e mantém o render aberto.

## Interface e documentação
- Manual e traduções em português brasileiro e inglês atualizados.
- Versão atualizada para 1.8.

# MyMCdroid 1.7 — Standalone Save List Preview 1

## Lista de Game Saves individuais
- Cada Game Save individual aberto é mantido numa coleção persistente durante a sessão.
- A coleção ocupa o painel principal com o título “Lista de Game Saves individuais” e usa as mesmas linhas, miniaturas e seleção dos Save Games de um Memory Card.
- Ao selecionar um item, aparecem Exportar, Transferir quando houver Memory Card aberto e Fechar Game Save.
- Fechar Game Save remove apenas a sessão da lista após confirmação, sem apagar o arquivo ou a pasta original.
- Tocar novamente na miniatura abre o render ampliado com todas as ferramentas já estabelecidas.
- A coleção integra o seletor e a navegação lateral por deslizamento entre Memory Cards.

## Game Save individual em pasta
- Alterar ID/serial também renomeia fisicamente a pasta para o nome compatível produzido pelo formato ARMSX2/PCSX2.
- A sessão, a seleção e a lista passam a usar a nova URI sem perder o render aberto.

## Interface e documentação
- Manual e traduções em português brasileiro e inglês atualizados.
- Versão atualizada para 1.7.

# MyMCdroid 1.6 — Standalone Save Action Preview 1

## Ação independente para Game Save individual
- Novo botão Abrir Game Save individual na barra principal, posicionado antes de Abrir Memory Card.
- O ícone é um disquete em contorno azul-ciano, sem preenchimento, seguindo a iconografia estabelecida do projeto.
- O botão permite escolher Game Save em arquivo ou Game Save em pasta.

## Fluxos separados
- Abrir Memory Card agora oferece somente Memory Card em arquivo .PS2 ou Memory Card em pasta.
- A abertura de Game Save individual não depende mais do menu de Abrir Memory Card.
- O novo botão permanece disponível com ou sem Memory Card aberto e durante o modo de seleção em lote.

## Manual e versão
- O Manual apresenta Abrir Game Save individual antes de Abrir Memory Card e utiliza o novo disquete.
- Textos em português brasileiro e inglês revisados para refletir a separação.
- Versão atualizada para 1.6.

# MyMCdroid 1.5 — Standalone Folder Preview 1

## Game Save individual em pasta
- A opção Game Save individual agora permite escolher entre arquivo e pasta.
- Pastas compatíveis com ARMSX2/PCSX2 são abertas diretamente no render ampliado e permanecem no seletor da sessão.
- Pastas de Memory Card completas são rejeitadas para evitar que sejam interpretadas como um único Game Save.

## Edição e persistência
- Exportar, substituir, adicionar, renomear e remover arquivos internos continuam disponíveis.
- Alterações de data/hora e ID/região também são gravadas no Game Save em pasta.
- Depois de cada alteração, a pasta compatível é reconstruída e sincronizada com segurança para o local escolhido pelo usuário.
- O formato em pasta é restaurado corretamente após a recriação da atividade.

## Compatibilidade preservada
- Exportação, transferência e confirmação de sobrescrita por Serial ID + região permanecem disponíveis.
- Game Saves individuais em PSU, MAX, CBS, SPS e XPS continuam funcionando sem alteração.
- Manual, Sobre e traduções atualizados para a versão 1.5.

# MyMCdroid 1.4 — Standalone Navigation Preview 1

## Sobrescrita segura em todas as transferências
- A transferência iniciada no render ampliado de um Memory Card agora verifica o destino antes da gravação.
- A mesma regra consolidada de Serial ID + região usada pelo Game Save individual é aplicada às transferências unitárias, em lote e de todos os itens.
- Quando há correspondência, o aplicativo identifica o Memory Card e exige confirmação explícita para sobrescrever.

## Fechar Game Save individual
- Novo botão Fechar Game Save no render individual, com o mesmo ícone de Fechar Memory Card.
- O botão encerra a sessão individual somente após confirmação.
- O X continua fechando apenas o render e preserva o Game Save no seletor da sessão.

## Navegação por deslizamento
- O render individual entra pela direita com a mesma curva e duração suave usadas na troca entre Memory Cards.
- Ao fechar o render ou encerrar a sessão individual, o aplicativo retorna ao último Memory Card aberto com animação horizontal.

## Documentação
- Manual, Sobre e traduções atualizados para a versão 1.4.

# MyMCdroid 1.3 — Standalone Transfer Preview 1

## Transferência segura do Game Save individual
- Antes de gravar, o destino é verificado pela regra consolidada de Serial ID + região, com proteção adicional para o mesmo nome interno.
- Quando um Game Save correspondente já existe, o aplicativo informa o Memory Card e o item encontrado e exige confirmação explícita de sobrescrita.
- Cancelar a confirmação não modifica o Memory Card.

## Navegação após transferência
- Depois de uma transferência concluída, o render individual é fechado suavemente.
- O Memory Card receptor passa a ser o cartão ativo, inclusive quando não era o cartão exibido.
- O Game Save recém-transferido é localizado, selecionado e trazido para a área visível da lista.

## Exportação individual
- O render do Game Save individual agora exibe o ícone Exportar Game Save ao lado de Transferir Game Save.
- Exportação completa disponível em PSU, MAX, CBS, SPS, XPS e pasta ARMSX2/PCSX2.

## Documentação
- Manual, Sobre e traduções atualizados para a versão 1.3.

# MyMCdroid 1.2 — Persistent Standalone Save Preview 1

## Game Save individual persistente
- Game Saves individuais abertos permanecem disponíveis no seletor da sessão junto aos Memory Cards.
- Fechar o render ampliado não descarta o Game Save; tocar no item correspondente abre novamente a visualização.
- Estado dos Game Saves individuais é restaurado quando a Activity é recriada, usando permissões persistentes do Android.

## Editor completo e seguro
- Exportar, substituir, adicionar, renomear e remover arquivos internos disponíveis no Game Save individual.
- Alterar data/hora e alterar ID/região também funcionam no arquivo isolado.
- Cada alteração é aplicada em uma cópia de trabalho, reexportada para o mesmo formato original e refletida no render sem voltar à lista.

## Transferência e iconografia
- O Game Save individual mostra somente o ícone de transferência entre as ações de Game Save no topo.
- Se houver mais de um Memory Card aberto, o usuário escolhe explicitamente o cartão de destino.
- A transferência mantém o Game Save individual aberto e selecionável e não troca automaticamente o cartão exibido.
- Exportar, transferir e remover no render de Game Saves pertencentes a Memory Card usam ícones contextuais.

## Documentação
- Manual atualizado em Português (Brasil) e Inglês.

# MyMCdroid 1.1 — Standalone Save Preview 1

## Render ampliado
- Ações Exportar Game Save, Transferir Game Save e Remover Game Save adicionadas acima dos arquivos internos.
- Transferir aparece somente quando existe destino compatível; Remover fica oculto para Game Save isolado.
- Zoom suave entre 100% e 250%, sem recriar o render WebGL.

## Game Save individual
- Terceira opção no fluxo Abrir Memory Card, abaixo de Memory Card em pasta.
- Abertura direta de arquivos PSU, MAX, CBS, SPS e XPS no render ampliado.
- Arquivos internos podem ser listados e exportados em modo de inspeção somente leitura.
- Com um Memory Card aberto, o Game Save isolado pode ser transferido para o cartão selecionado.
- Exportação do Game Save isolado disponível em PSU, MAX, CBS, SPS, XPS e pasta.

## Documentação
- Manual e Sobre atualizados em Português (Brasil) e Inglês.
- Android Storage Access Framework incluído nas fontes e referências.

# MyMCdroid 1.0 — Save Date Editor Preview 2

## Horário compatível com o navegador do PS2
- Conversão bidirecional entre o JST fixo do Memory Card e o fuso do BIOS/emulador.
- GMT+04:30 inicial conforme o exemplo Onimusha 2 fornecido, configurável em Configurações.
- Data e hora agora aparecem no render ampliado, abaixo de Região/Tamanho.

## Continuidade do editor ampliado
- Cancelar ou concluir uma ferramenta não fecha mais a visualização ampliada.
- Após uma alteração, arquivos, metadados e render são recarregados dentro do próprio painel.
- Renomear arquivo, Alterar data/hora e Alterar ID/Região usam o ícone de alerta circular.

## Referências
- myMCpp adicionado como link oficial na aba Sobre em ambos os idiomas.

# MyMCdroid 1.0 — Save Date Editor Preview 1

## Data e hora do Game Save
- Nova ação Alterar data/hora na visualização ampliada.
- A data de modificação do diretório raiz é alterada sem modificar a criação nem os arquivos internos.
- Entrada validada no formato `DD/MM/AAAA HH:MM:SS`, entre os anos 2000 e 2099.
- Compatibilidade com imagens `.ps2` e Memory Cards em pasta.

## Reorganização do painel ampliado
- Exportar arquivo e Substituir arquivo agora usam botões de contorno iguais às demais funções.
- Ferramentas distribuídas em duas colunas, com altura, largura e espaçamento uniformes.
- Ordem: Exportar/Substituir, Adicionar/Renomear, Remover/Alterar data e hora, Alterar ID/Região.

# MyMCdroid 0.9 — Internal File Editor Preview 1

## Editor interno do Game Save
- A visualização ampliada agora permite adicionar, renomear e remover arquivos internos.
- Exportar e substituir arquivos continuam disponíveis e usam a mesma seleção visual.
- O último arquivo interno não pode ser removido, evitando um diretório de Game Save vazio.
- Nomes duplicados, reservados, incompatíveis com Shift-JIS ou maiores que 31 bytes são rejeitados.

## Alteração de ID/Região
- Nova opção para editar o ID raiz do Game Save.
- Se existir um arquivo interno com o mesmo nome do ID antigo, ele é renomeado junto.
- A região mostrada na lista é recalculada pelo novo Serial ID.
- A interface avisa que jogos com região gravada dentro de dados binários podem exigir ajustes adicionais específicos do jogo.

## Segurança e compatibilidade
- Alterações são feitas fora da interface principal e em cópia de trabalho.
- Demais arquivos, dados, modos, atributos e datas são preservados.
- Compatibilidade mantida com Memory Card `.ps2`, Memory Card em pasta, PSU, MAX, CBS, SPS e XPS.

# MyMCdroid 0.8 — Neon Memory Audio Preview 1

## Áudio
- Novo pacote sonoro original com dez efeitos de interface.
- Sons de abertura, importação, exportação, transferência, remoção, confirmação e cancelamento.
- Troca de Memory Card com panorama coerente com a direção do movimento.
- Transições de funções e scroll com controle contra repetição excessiva.
- Sons operacionais executados apenas depois do sucesso da operação.

## Configurações
- Nova opção Sons da Interface, ativada por padrão.
- Controle de volume próprio, com valor inicial de 70%.
- Respeito ao modo silencioso e ao volume de mídia do Android.

# MyMCdroid 0.7 — Cleanup & Performance Preview 1

## Correção consolidada na base 0.7
- Removida somente a linha azul interna do ícone Abrir Memory Card, preservando cor, tamanho e forma externa.

## Organização e tamanho
- Código legado de referência foi retirado do pacote do aplicativo e preservado em `reference/`.
- Testes e utilitários de desenvolvimento foram movidos para `tools/python_tests/`.
- Classes, layouts, drawables, animações, estilos, cores e textos sem uso foram removidos.

## Desempenho
- O módulo Python principal é reutilizado durante a sessão, evitando buscas repetidas.
- Clusters indiretos/FAT já decodificados são reutilizados durante cada leitura do Memory Card.
- A verificação de imagem apagada agora é feita em blocos e cartões válidos não são lidos integralmente duas vezes.
- A identificação do Serial ID lê apenas o cabeçalho necessário dos contêineres.
- Cache e entradas de metadados são compartilhados durante listagens e comparações.

## Compatibilidade preservada
- Regra de sobrescrita por Serial ID + Região.
- PSU, MAX, CBS, SPS, XPS e Game Save em pasta.
- Múltiplos Memory Cards, transferências, renderização 3D, Manual, Sobre e identidade visual da versão 0.6.

# MyMCdroid 0.6 — Directional Outline Icons

## Iconografia
- Manual, Configurações e Sobre em branco.
- Importação orientada para baixo.
- Exportações orientadas para cima.
- Transferências orientadas para a direita.
- Uma única cor e ausência de preenchimento nos ícones alterados.

## Origem
- Criada diretamente a partir da base oficial 0.4 e aprovada como nova base oficial.

# MyMCdroid 2.1.0 RC1

## Interface
- Diálogos personalizados MyMCdroid com fundo escurecido e fade.
- Toasts personalizados MyMCdroid.
- Ícone de Exportar Save corrigido para seta apontando para cima.
- Tipografia ampliada no painel Detalhes do Save.
- Mensagens de operações removidas do painel permanente da Memory Card.

## Estado
- Preview, seleção e detalhes são limpos ao fechar ou trocar a Memory Card.
- Preview e detalhes são limpos depois de apagar um save.
- Novo Memory Card abre sem seleção automática.

## Mensagens
- “Save Game Overwritten” substituído por “Save Game Sobrescrito”.

## Fora desta RC
- Ambiente wireframe do preview 3D.
- Tela Sobre o Aplicativo.
- Recursos adicionais.

# MyMCdroid 1.4 — Standalone Navigation Preview 1

## Testes principais

1. Abra dois Memory Cards, amplie um Game Save e transfira-o para o outro cartão.
2. Repita usando um destino que já possua o mesmo Serial ID e região; confirme que a pergunta de sobrescrita aparece antes da gravação.
3. Cancele essa pergunta e confira que o Memory Card de destino não foi alterado.
4. Abra um Game Save individual e verifique a entrada suave da direita para a esquerda.
5. Toque no X: o render deve fechar, o Game Save deve permanecer no seletor e o último Memory Card aberto deve reaparecer.
6. Abra o Game Save individual novamente e toque no novo ícone Fechar Game Save; após confirmar, a sessão deve desaparecer do seletor e o último Memory Card deve ser exibido.
7. Com apenas um Memory Card aberto, transfira um Game Save individual já existente no destino e valide a mesma confirmação de sobrescrita.

## Regressão rápida

- Exportação e edição de arquivos internos continuam disponíveis no render individual.
- PSU, MAX, CBS, SPS, XPS e Memory Card em pasta continuam funcionando.
- Manual, Sobre e interface permanecem disponíveis em português brasileiro e inglês.

Projeto-fonte para testes. APK não incluído.

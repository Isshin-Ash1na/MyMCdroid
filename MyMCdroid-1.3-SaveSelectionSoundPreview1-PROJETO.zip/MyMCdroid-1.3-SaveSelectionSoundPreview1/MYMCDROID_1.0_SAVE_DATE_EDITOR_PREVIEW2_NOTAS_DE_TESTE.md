# MyMCdroid 1.0 — Save Date Editor Preview 2

## Teste principal com Onimusha 2

1. Em **Informações → Configurações**, confirme **Fuso do PS2: GMT+04:30**.
2. Abra o Memory Card e expanda o Game Save de Onimusha 2.
3. Confira a data e hora abaixo de Região/Tamanho. Para a referência enviada, o painel deve mostrar `27/10/2025 02:21:09`.
4. Toque em **Alterar data/hora**, informe outro valor e confirme.
5. Confirme que o render ampliado permanece aberto e que a data mostrada é atualizada.
6. Abra o cartão no navegador do PS2 e compare o mesmo valor.

## Permanência no render ampliado

- Cancele e conclua Renomear arquivo, Substituir arquivo, Adicionar arquivo, Remover arquivo, Alterar data/hora e Alterar ID/Região.
- Em todos os casos, confirme que o aplicativo continua no render ampliado.
- Após mudanças, confira a atualização da lista de arquivos, ID/Região, data/hora e ícone 3D.

## Ícones e Sobre

- Renomear arquivo, Alterar data/hora e Alterar ID/Região devem mostrar a exclamação dentro do círculo.
- A aba Sobre deve apresentar **myMCpp** como link para `https://github.com/PCSX2/myMCpp`.

## Verificações automatizadas

- conversão de `27/10/2025 06:51:09` em JST para `27/10/2025 02:21:09` em GMT+04:30;
- gravação e releitura da hora local em Memory Card `.ps2` e em pasta;
- preservação da data de criação e integridade do sistema de arquivos;
- regressão de metadados PSU/MAX/CBS/SPS/XPS;
- paridade de 273 textos Português/Inglês;
- compilação dos recursos Android com AAPT2.

O projeto não contém APK compilado. Esta versão foi aprovada e definida como nova base oficial em 22/08/2026.

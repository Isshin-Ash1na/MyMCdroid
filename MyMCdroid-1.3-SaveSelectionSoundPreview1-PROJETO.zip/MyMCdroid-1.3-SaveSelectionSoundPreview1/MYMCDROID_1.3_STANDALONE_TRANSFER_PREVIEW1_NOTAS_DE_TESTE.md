# MyMCdroid 1.3 — Standalone Transfer Preview 1

## Exportação do Game Save individual

1. Abra um Game Save individual nos formatos PSU, MAX, CBS, SPS e XPS.
2. No topo do render, toque no ícone **Exportar Game Save**.
3. Exporte em PSU, MAX, CBS, SPS, XPS e pasta.
4. Importe novamente cada resultado e confirme arquivos, nome, ícone, data/hora e região.

## Transferência sem conflito

1. Abra dois Memory Cards e um Game Save individual que ainda não exista no destino.
2. Toque em **Transferir Game Save** e escolha o cartão receptor.
3. Confirme a transferência normal.
4. Verifique que o aplicativo fecha o render individual, abre o Memory Card receptor e seleciona o Game Save transferido.

## Transferência com sobrescrita

1. Transfira ou importe previamente o mesmo Game Save no Memory Card de destino.
2. Inicie novamente a transferência do Game Save individual para esse cartão.
3. Confirme que aparece a mensagem de Game Save idêntico, com o nome do Memory Card e do item encontrado.
4. Escolha **Não** e verifique que o Memory Card não é alterado.
5. Repita, escolha **Sim** e confirme a sobrescrita.
6. Verifique que o cartão receptor é exibido e o Game Save sobrescrito fica selecionado.

## Regressão

- Seletor entre vários Memory Cards.
- Persistência do Game Save individual na sessão.
- Editor completo de arquivos internos.
- Transferências singular, em lote e total entre Memory Cards.
- Importação e sobrescrita por Serial ID + região.
- Português (Brasil), Inglês, Manual, Sobre, sons e identidade visual.

## Verificações executadas

- detecção automatizada de destino vazio e de conflito Serial ID + região;
- testes Python de Memory Card em pasta, editor interno e integridade PSU/MAX/CBS/SPS/XPS;
- compilação Kotlin isolada de todas as classes do aplicativo;
- compilação isolada dos recursos Android com AAPT2;
- XML válido e paridade completa entre Português (Brasil) e Inglês.

Não foi gerado APK ou ZIP nesta etapa.

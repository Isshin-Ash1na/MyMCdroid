# MyMCdroid 1.1 — Memory Card Focus Base

## Base oficial

Esta versão corresponde à revisão anteriormente identificada provisoriamente como 1.9. A implementação foi renumerada para 1.1 e definida como a nova base oficial do projeto.

## Testes recomendados

1. Confirme que a barra principal não apresenta o botão Abrir Game Save individual.
2. Abra Memory Cards em arquivo .PS2 e em pasta e alterne entre eles por deslizamento e pelo seletor.
3. Importe e exporte Game Saves nos formatos .PSU, .MAX, .CBS, .SPS, .XPS e pasta.
4. Selecione um Game Save e confira na lista as ações Exportar, Transferir (com dois Memory Cards abertos) e Remover.
5. Toque novamente na miniatura para abrir o render ampliado e confirme que nele não aparecem Exportar, Transferir nem Remover Game Save.
6. No render ampliado, teste zoom, rotação, animação, data/hora, alteração de ID/região e as ações de arquivos internos: exportar, substituir, adicionar, renomear e remover.
7. Feche o render ampliado e confirme que o aplicativo retorna à lista do mesmo Memory Card sem piscar ou perder miniaturas.

## Resultado esperado

O aplicativo opera somente por Memory Cards, sem a função de Game Save individual. A remoção das ações no render ampliado não altera as ações equivalentes disponíveis na lista nem as ferramentas internas do render.

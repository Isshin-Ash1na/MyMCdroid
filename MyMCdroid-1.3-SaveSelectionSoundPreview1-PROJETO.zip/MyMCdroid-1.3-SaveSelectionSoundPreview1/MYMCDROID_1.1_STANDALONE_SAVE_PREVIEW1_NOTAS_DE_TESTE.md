# MyMCdroid 1.1 — Standalone Save Preview 1

## Testes principais

1. Abra um Game Save individual em cada formato: PSU, MAX, CBS, SPS e XPS.
2. Confirme que o render ampliado abre diretamente e exibe nome, Serial ID, região, tamanho, data/hora e arquivos internos.
3. Teste o zoom de 100% a 250% e verifique rotação e animação.
4. Exporte o Game Save isolado nos seis destinos disponíveis e importe-o novamente.
5. Com um Memory Card aberto, transfira o Game Save isolado e valide o resultado no cartão.
6. Em um Game Save pertencente a Memory Card, teste Exportar, Transferir e Remover no topo do render ampliado.
7. Confirme que Remover não aparece para Game Save isolado e que Transferir só aparece quando há destino.
8. Selecione um arquivo interno e teste sua exportação.

## Regressão

- Abrir/criar Memory Card em arquivo e em pasta.
- Importação e sobrescrita por Serial ID + Região.
- Exportação, transferência e remoção singular, em lote e total.
- Editor interno completo para Game Saves pertencentes a Memory Card.
- Português (Brasil), Inglês, Manual, Sobre, sons e identidade visual.

## Verificações automatizadas executadas

- compilação isolada de todos os recursos Android com AAPT2;
- testes Python de Memory Card em pasta, editor interno e integridade PSU/MAX/CBS/SPS/XPS;
- análise sintática Kotlin sem erros estruturais novos.

# Base oficial do projeto

**MyMCdroid 1.2 — List Recovery Base**

Esta versão foi aprovada em **24/08/2026** e substitui a base oficial MyMCdroid 1.1. Todas as próximas alterações devem preservar as funções consolidadas nesta revisão.

## Correções consolidadas da versão 1.2

- nomes longos de Memory Card aparecem em múltiplas linhas no seletor de transferência;
- Memory Cards em pasta exibem o nome real da pasta, sem o caminho completo da URI;
- animações sequenciais da lista usam atrasos canceláveis;
- linhas recicladas sempre recuperam transparência, posição, escala e visibilidade;
- fechar, transferir, remover ou recarregar não deixa espaços vazios na lista.

## Funções consolidadas

- abertura, criação e gerenciamento de Memory Cards em arquivo .PS2;
- suporte a Memory Cards em pasta compatíveis com ARMSX2/PCSX2;
- abertura simultânea de múltiplos Memory Cards e navegação entre eles;
- importação e exportação de Game Saves em .PSU, .MAX, .CBS, .SPS, .XPS e pasta;
- importação, exportação, remoção e transferência em lote;
- transferência entre Memory Cards com verificação de Game Save existente e confirmação de sobrescrita;
- renderização dos ícones 3D com miniaturas estáveis, animação, rotação e zoom;
- render ampliado com data/hora, alteração de ID/região e gerenciamento dos arquivos internos;
- idiomas Português (Brasil) e Inglês;
- pacote sonoro MyMCdroid Neon Memory;
- Manual e tela Sobre integrados.

## Simplificações consolidadas

- a função Abrir Game Save individual e todos os seus fluxos permanecem removidos;
- Exportar, Transferir e Remover Game Save não aparecem dentro do render ampliado;
- essas ações permanecem disponíveis na linha do Game Save selecionado, quando aplicável.

## Regra de continuidade

- base oficial: **MyMCdroid 1.2 — List Recovery Base**;
- próximo ciclo funcional: **versão 1.3**;
- o versionCode Android permanece crescente;
- o pacote oficial contém somente o projeto-fonte, sem APK compilado;
- versões e bases anteriores permanecem apenas como histórico.

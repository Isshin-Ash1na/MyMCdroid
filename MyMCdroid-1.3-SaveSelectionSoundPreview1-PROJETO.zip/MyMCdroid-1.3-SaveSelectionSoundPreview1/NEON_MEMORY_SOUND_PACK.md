# MyMCdroid — Neon Memory Sound Pack

Pacote sonoro original criado para a interface do MyMCdroid 0.8.

## Efeitos

- `sound_app_open.wav`: inicialização do aplicativo;
- `sound_import.wav`: importação concluída;
- `sound_export.wav`: exportação concluída;
- `sound_transfer.wav`: transferência concluída;
- `sound_remove.wav`: remoção ou formatação concluída;
- `sound_confirm.wav`: confirmação do usuário;
- `sound_cancel.wav`: cancelamento ou fechamento;
- `sound_card_transition.wav`: transição direcional entre Memory Cards;
- `sound_function_transition.wav`: entrada, saída ou retração de funções;
- `sound_scroll_tick.wav`: marcação discreta durante o scroll manual.

Os arquivos são PCM mono, 22.050 Hz e 16 bits. O pacote completo ocupa aproximadamente 134 KB antes da compactação. Todos os efeitos são gerados pelo script `tools/generate_neon_memory_sounds.py` e não reutilizam áudio de consoles, jogos ou bibliotecas externas.

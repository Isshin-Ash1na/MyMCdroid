# MyMCdroid 1.5 — Standalone Folder Preview 1

## Fluxo principal

1. Toque em Abrir Memory Card e escolha Game Save individual.
2. Escolha Game Save em pasta e selecione diretamente a pasta de um Game Save criado pelo ARMSX2 ou PCSX2.
3. Confirme que o render ampliado, os dados, o ícone e a lista de arquivos internos são carregados.
4. Feche o render pelo X e abra novamente o mesmo item pelo seletor da sessão.

## Edição da pasta

1. Teste exportar, substituir, adicionar, renomear e remover um arquivo interno.
2. Altere a data/hora e depois o ID/região.
3. Após cada operação, confirme que o render permanece aberto e atualizado.
4. Abra a pasta novamente e verifique se as alterações foram preservadas.
5. Teste a pasta modificada no ARMSX2 ou PCSX2.

## Transferência e segurança

1. Com um Memory Card aberto, transfira o Game Save individual em pasta para ele.
2. Repita com um Game Save de mesmo Serial ID e região no destino.
3. A confirmação de sobrescrita deve aparecer antes de qualquer gravação.
4. Depois da transferência, o aplicativo deve exibir o Memory Card receptor.

## Regressão

- Abrir Game Save individual em PSU, MAX, CBS, SPS e XPS.
- Exportar o Game Save individual em todos os formatos disponíveis.
- Fechar apenas o render pelo X e encerrar a sessão pelo botão Fechar Game Save.

Projeto-fonte para testes. APK não incluído.

# Análise — PS2 Save Builder e editor interno

Referências consultadas:

- [PS2 Save Builder](https://www.ps2savetools.com/download/ps2-save-builder/)
- [Como alterar a região de um save de PS2](https://www.ps2savetools.com/ufaqs/how-to-change-the-region-of-a-ps2-save/)
- [PlayStation 2 Memory Card File System](https://www.ps2savetools.com/ps2memcardformat.html)

## Regras aplicadas

- A entrada de diretório do PS2 reserva 32 bytes para o nome normalmente utilizado pelo sistema. O MyMCdroid limita a entrada do usuário a 31 bytes em Shift-JIS para preservar o terminador nulo.
- Nomes `.` e `..`, caracteres de controle, `?`, `*`, `/` e `\\` são rejeitados.
- O prefixo `_pcsx2_` fica reservado para os arquivos de controle dos Memory Cards em pasta.
- Duplicatas sem distinção de maiúsculas/minúsculas são bloqueadas para manter portabilidade entre Android, Windows e os emuladores.
- A troca de região altera o ID raiz e, quando existir, o arquivo interno de nome exatamente igual ao ID antigo.

## Limite conhecido da troca de região

O PS2 Save Builder orienta alterar o Root/ID e nomes internos correspondentes. Alguns jogos, porém, também armazenam o Serial ID ou a região dentro do conteúdo binário e podem usar checksums próprios. O MyMCdroid não modifica automaticamente esses dados opacos porque uma substituição genérica poderia corromper o Game Save.

# MyMCdroid 0.9 — Internal File Editor Preview 1

## Como testar

1. Abra um Memory Card `.ps2` ou em pasta e expanda o render de um Game Save.
2. Selecione um arquivo interno e teste **Exportar**, **Substituir**, **Renomear** e **Remover**.
3. Use **Adicionar** para escolher um arquivo do Android e definir seu nome interno.
4. Feche e reabra o Memory Card para confirmar que os arquivos e o ícone continuam corretos.
5. Em uma cópia de teste, use **Alterar ID/Região**, informe o ID raiz da outra região e confirme o novo Serial ID/região na lista.
6. Exporte o Game Save nos formatos necessários e teste no jogo/emulador de destino.

## Pontos de atenção

- Alterar ou remover `icon.sys` ou arquivos `.icn` pode impedir a exibição do ícone no PS2.
- A troca de ID/Região não edita dados binários específicos do jogo nem recalcula checksums proprietários.
- Confirme que datas, tamanho e demais arquivos permanecem presentes no navegador do PS2.
- Teste nomes duplicados, maiores que 31 bytes e caracteres incompatíveis; o app deve recusá-los sem modificar o Memory Card.

## Verificações automatizadas realizadas

- adicionar, renomear e remover arquivo em imagem `.ps2`;
- as mesmas operações em Memory Card em pasta;
- alteração do ID raiz de NTSC-U para PAL e renomeação do arquivo interno correspondente;
- integridade do sistema de arquivos após cada gravação;
- regressão de Memory Card em pasta e de metadados;
- importação/sobrescrita PSU, MAX, CBS, SPS e XPS preservada;
- recursos Android compilados isoladamente com AAPT2.

O pacote contém somente o projeto-fonte, sem APK compilado.

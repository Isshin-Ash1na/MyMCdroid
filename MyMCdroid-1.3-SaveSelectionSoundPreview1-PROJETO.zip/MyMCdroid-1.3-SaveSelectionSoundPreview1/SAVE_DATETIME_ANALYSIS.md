# Data e hora no sistema de arquivos do Memory Card PS2

Referências:

- [PlayStation 2 Memory Card File System](https://www.ps2savetools.com/ps2memcardformat.html)
- [PS2 save game format for EMS adapter — PSU](https://www.ps2savetools.com/documents/ps2-save-game-format-for-ems-adapter-psu/)
- [PS2SDK — configuração de fuso horário](https://github.com/ps2dev/ps2sdk/blob/master/ee/kernel/src/osd_config.c)
- [myMCpp](https://github.com/PCSX2/myMCpp)

Cada entrada de diretório possui campos independentes de criação e modificação. A data utiliza segundo, minuto, hora, dia, mês e ano de quatro dígitos.

O formato do Memory Card grava esses campos em JST (`GMT+09:00`), independentemente do fuso escolhido no console. O navegador do PS2 converte a hora armazenada para o fuso configurado no BIOS, usando a diferença `fuso do PS2 - GMT+09:00`.

O MyMCdroid 1.0 Preview 2 modifica somente o campo `modified` da entrada raiz do Game Save. A data informada pelo usuário é tratada como a hora que deverá aparecer no navegador do PS2 e convertida para JST antes da gravação. Na leitura, ocorre a conversão inversa. O campo `created`, os dados e os metadados dos arquivos internos permanecem intactos.

O fuso do BIOS não é armazenado no Memory Card. Por isso ele pode ser ajustado em **Informações → Configurações → Fuso horário do sistema PS2**. A referência enviada (`06:51:09` no cartão e `02:21:09` no PS2) corresponde a `GMT+04:30`, adotado como valor inicial desta preview.

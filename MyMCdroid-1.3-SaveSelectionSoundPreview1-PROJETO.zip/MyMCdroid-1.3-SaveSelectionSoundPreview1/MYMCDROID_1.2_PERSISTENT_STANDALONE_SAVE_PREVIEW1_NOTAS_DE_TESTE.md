# MyMCdroid 1.2 — Persistent Standalone Save Preview 1

## Testes principais

1. Abra dois Memory Cards com nomes diferentes.
2. Em **Abrir Memory Card**, escolha **Game Save individual** e abra um arquivo PSU, MAX, CBS, SPS ou XPS.
3. Feche o render ampliado e confirme que o Game Save continua no seletor; toque nele para reabrir.
4. Toque no ícone de transferência e confira se a lista mostra os dois Memory Cards pelo nome.
5. Transfira para cada destino e confirme que o Game Save individual continua aberto e que a tela não muda automaticamente para o cartão receptor.
6. No render individual, selecione um arquivo interno e teste exportar, substituir, renomear e remover.
7. Teste também adicionar arquivo, alterar data/hora e alterar ID/região.
8. Depois de cada alteração, confirme que o render permanece aberto, a lista interna é atualizada e o arquivo original continua importável no mesmo formato.
9. Repita a transferência com apenas um Memory Card aberto; a confirmação deve aparecer diretamente, sem seletor intermediário.

## Regressão

- Game Saves de Memory Card continuam mostrando os ícones Exportar, Transferir e Remover no topo do render.
- Abrir/criar Memory Card em arquivo e em pasta.
- Importação e sobrescrita por Serial ID + Região.
- Exportação, transferência e remoção singular, em lote e total.
- Português (Brasil), Inglês, Manual, Sobre, sons e identidade visual.

## Verificações executadas

- compilação Kotlin isolada de todas as classes do aplicativo, com stubs apenas para o runtime Chaquopy e para `R`;
- compilação isolada dos recursos com AAPT2 e validação XML;
- paridade completa entre textos Português (Brasil) e Inglês;
- testes Python de Memory Card em pasta, editor interno e integridade PSU/MAX/CBS/SPS/XPS.

Observação: a tarefa Gradle completa não pôde ler `platforms/android-36/package.xml` no SDK local por restrição externa de permissão; não foi gerado APK.

# MyMCdroid 1.0 — Save Date Editor Preview 1

## Como testar a data e hora

1. Abra um Memory Card e expanda o render de um Game Save.
2. Toque em **Alterar data/hora**.
3. Informe uma data no formato `DD/MM/AAAA HH:MM:SS` e confirme.
4. Feche e reabra o Memory Card e confirme que o Game Save permanece íntegro.
5. Abra o Memory Card no navegador do PS2 ou no emulador e confira a data e hora exibidas.
6. Exporte o Game Save em um formato compatível e confirme que a data continua preservada.

## Como testar o novo painel

- Selecione um arquivo interno e confirme que Exportar, Substituir, Renomear e Remover são habilitados juntos.
- Confira o alinhamento em duas colunas e a uniformidade de altura, contorno e espaçamento.
- Confirme que Adicionar, Alterar data/hora e Alterar ID/Região permanecem disponíveis sem selecionar um arquivo interno.
- Em telas menores, role o conteúdo da caixa ampliada para acessar todas as ferramentas.

## Verificações realizadas

- gravação da data em Memory Card `.ps2`;
- gravação da data em Memory Card em pasta;
- data de criação preservada;
- integridade do sistema de arquivos após a alteração;
- regressão do editor interno, Memory Card em pasta e formatos PSU/MAX/CBS/SPS/XPS;
- recursos Android e traduções validados com AAPT2.

O pacote contém somente o projeto-fonte, sem APK compilado.

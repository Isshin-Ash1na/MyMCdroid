# MyMCdroid 1.3 — Save Selection Sound Preview 1

## Seleção comum

1. Abra um Memory Card com dois ou mais Game Saves.
2. Selecione diferentes Game Saves pela linha e pela miniatura.
3. Confirme que cada nova seleção reproduz o efeito Neon Memory.
4. Toque novamente na miniatura já selecionada para ampliar o render e confirme que o som de seleção não se repete.

## Seleção em lote

1. Segure um Game Save por 1 segundo para ativar as opções em lote.
2. Acrescente outros Game Saves à seleção e confirme o mesmo efeito sonoro.
3. Desmarque um Game Save e confirme que o efeito não toca.
4. Encerre o modo em lote pelo Game Save inicial.

## Configurações de som

1. Desative Sons da Interface e confirme que a seleção permanece silenciosa.
2. Reative a opção e teste diferentes níveis de volume.
3. Confirme que o efeito respeita o modo silencioso do aparelho.

## Resultado esperado

O novo efeito deve oferecer resposta imediata e discreta sem atrasar a seleção, repetir ao abrir o render ou interferir nas animações e funções da lista.

package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.Button
import android.widget.TextView

object MyMCDialog {
    fun show(
        context: Context,
        title: String,
        message: String? = null,
        onCancel: (() -> Unit)? = null,
        onConfirm: () -> Unit
    ) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        // Disable the device/theme window transition. Some Android versions
        // slide dialogs horizontally before the custom panel animation starts.
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_mymc_confirm, null)
        dialog.setContentView(view)
        dialog.setCancelable(true)
        dialog.setOnCancelListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            onCancel?.invoke()
        }

        view.findViewById<TextView>(R.id.dialogTitle).text = title
        val messageView = view.findViewById<TextView>(R.id.dialogMessage)
        if (message.isNullOrBlank()) {
            messageView.visibility = View.GONE
        } else {
            messageView.text = message
            messageView.visibility = View.VISIBLE
        }

        val panel = view.findViewById<View>(R.id.dialogPanel)
        val offset = 6f * context.resources.displayMetrics.density
        val smoothInterpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
        panel.alpha = 0f
        panel.scaleX = 0.98f
        panel.scaleY = 0.98f
        panel.translationY = offset

        fun dismissAnimated(after: (() -> Unit)? = null) {
            panel.animate()
                .alpha(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .translationY(offset * 0.65f)
                .setInterpolator(smoothInterpolator)
                .setDuration(160)
                .withEndAction {
                    if (dialog.isShowing) dialog.dismiss()
                    after?.invoke()
                }
                .start()
        }

        view.findViewById<Button>(R.id.dialogNo).setOnClickListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            dismissAnimated(onCancel)
        }
        view.findViewById<Button>(R.id.dialogYes).setOnClickListener {
            MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
            dismissAnimated(onConfirm)
        }

        val dialogWidth = (context.resources.displayMetrics.widthPixels * 0.86f).toInt()
        dialog.window?.apply {
            setWindowAnimations(0)
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
            attributes = attributes.apply {
                width = dialogWidth
                height = WindowManager.LayoutParams.WRAP_CONTENT
                gravity = Gravity.CENTER
                dimAmount = 0.72f
                windowAnimations = 0
            }
        }

        dialog.show()
        // Keep the panel invisible while Android performs its first measure.
        // Only animate after the centered window has its final dimensions.
        dialog.window?.setLayout(dialogWidth, WindowManager.LayoutParams.WRAP_CONTENT)
        panel.post {
            panel.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setInterpolator(smoothInterpolator)
                .setDuration(240)
                .start()
        }
    }
}

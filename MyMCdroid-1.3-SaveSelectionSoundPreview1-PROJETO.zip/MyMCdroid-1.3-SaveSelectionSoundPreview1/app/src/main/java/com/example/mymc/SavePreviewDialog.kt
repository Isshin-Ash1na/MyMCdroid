package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

object SavePreviewDialog {
    data class FileItem(val name: String, val size: Long)

    class Handle internal constructor(
        private val dialog: Dialog,
        private val dismissAction: () -> Unit,
        private val refreshAction: (
            String,
            String,
            String,
            String,
            String,
            String,
            List<FileItem>,
        ) -> Unit,
    ) {
        fun refresh(
            title: String,
            serial: String,
            region: String,
            saveId: String,
            modifiedDateTime: String,
            payload: String,
            files: List<FileItem>,
        ) {
            if (dialog.isShowing) {
                refreshAction(
                    title,
                    serial,
                    region,
                    saveId,
                    modifiedDateTime,
                    payload,
                    files,
                )
            }
        }

        fun dismiss() {
            if (dialog.isShowing) dismissAction()
        }
    }

    fun show(
        context: Context,
        title: String,
        serial: String,
        region: String,
        saveId: String,
        modifiedDateTime: String,
        payload: String,
        files: List<FileItem>,
        allowEditing: Boolean,
        onExportFile: (String) -> Unit,
        onReplaceFile: (String) -> Unit,
        onAddFile: () -> Unit,
        onRenameFile: (String) -> Unit,
        onRemoveFile: (String) -> Unit,
        onChangeDateTime: (String) -> Unit,
        onChangeRegion: (String) -> Unit,
        horizontalSlide: Boolean,
        onClosed: () -> Unit,
    ): Handle {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_save_preview, null)
        dialog.setContentView(view)
        val panel = view.findViewById<View>(R.id.expandedPreviewPanel)
        val preview = view.findViewById<SavePreviewView>(R.id.expandedPreview)
        val rotation = view.findViewById<ImageButton>(R.id.expandedPreviewRotation)
        val animationControl = view.findViewById<LinearLayout>(R.id.expandedPreviewAnimationControl)
        val iconAnimation = view.findViewById<ImageButton>(R.id.expandedPreviewAnimation)
        val zoomOut = view.findViewById<Button>(R.id.expandedPreviewZoomOut)
        val zoomIn = view.findViewById<Button>(R.id.expandedPreviewZoomIn)
        val zoomLabel = view.findViewById<TextView>(R.id.expandedPreviewZoomLabel)
        val fileList = view.findViewById<ListView>(R.id.expandedPreviewFiles)
        val fileListEmpty = view.findViewById<TextView>(R.id.expandedPreviewFilesEmpty)
        val exportFile = view.findViewById<Button>(R.id.expandedPreviewExportFile)
        val replaceFile = view.findViewById<Button>(R.id.expandedPreviewReplaceFile)
        val addFile = view.findViewById<Button>(R.id.expandedPreviewAddFile)
        val renameFile = view.findViewById<Button>(R.id.expandedPreviewRenameFile)
        val removeFile = view.findViewById<Button>(R.id.expandedPreviewRemoveFile)
        val changeDateTime = view.findViewById<Button>(R.id.expandedPreviewChangeDateTime)
        val changeRegion = view.findViewById<Button>(R.id.expandedPreviewChangeRegion)
        val fileEditActions = view.findViewById<View>(R.id.expandedPreviewFileEditActions)
        val fileAdvancedActions = view.findViewById<View>(R.id.expandedPreviewFileAdvancedActions)
        val titleView = view.findViewById<TextView>(R.id.expandedPreviewTitle)
        val serialView = view.findViewById<TextView>(R.id.expandedPreviewSerial)
        val regionView = view.findViewById<TextView>(R.id.expandedPreviewRegion)
        val dateTimeView = view.findViewById<TextView>(R.id.expandedPreviewDateTime)
        var currentSaveId = saveId
        var currentModifiedDateTime = modifiedDateTime
        var currentFiles = files

        if (!allowEditing) {
            replaceFile.visibility = View.GONE
            fileEditActions.visibility = View.GONE
            fileAdvancedActions.visibility = View.GONE
            changeRegion.visibility = View.GONE
        }

        val labels = currentFiles.map { item ->
            "${item.name}  •  ${formatSize(item.size)}"
        }.toMutableList()
        val fileAdapter = ArrayAdapter(
            context,
            R.layout.save_file_list_item,
            R.id.saveFileName,
            labels,
        )
        fileList.adapter = fileAdapter
        var selectedFile: String? = null
        fun updateTextFields(
            newTitle: String,
            newSerial: String,
            newRegion: String,
            newModifiedDateTime: String,
        ) {
            titleView.text = newTitle
            serialView.text = newSerial
            regionView.text = newRegion
            dateTimeView.text = context.getString(
                R.string.expanded_preview_datetime,
                Ps2TimeZone.format(Ps2TimeZone.offsetMinutes(context)),
                newModifiedDateTime.ifBlank { "—" },
            )
        }
        fun updateFileVisibility() {
            fileList.visibility = if (currentFiles.isEmpty()) View.GONE else View.VISIBLE
            fileListEmpty.visibility = if (currentFiles.isEmpty()) View.VISIBLE else View.GONE
        }
        fun updateFileActions() {
            val enabled = selectedFile != null
            exportFile.isEnabled = enabled
            replaceFile.isEnabled = enabled
            renameFile.isEnabled = enabled
            removeFile.isEnabled = enabled
            exportFile.alpha = if (enabled) 1f else 0.45f
            replaceFile.alpha = if (enabled) 1f else 0.45f
            renameFile.alpha = if (enabled) 1f else 0.45f
            removeFile.alpha = if (enabled) 1f else 0.45f
        }
        fileList.setOnItemClickListener { _, _, position, _ ->
            selectedFile = currentFiles.getOrNull(position)?.name
            fileList.setItemChecked(position, true)
            updateFileActions()
        }
        updateTextFields(title, serial, region, modifiedDateTime)
        updateFileVisibility()
        updateFileActions()

        preview.setCompactMode(false)
        preview.setInteractive(true)
        preview.setIconAnimationEnabled(true)
        preview.setOnRenderReadyListener {
            preview.queryIconAnimationAvailability { available ->
                if (!available || animationControl.visibility == View.VISIBLE) {
                    return@queryIconAnimationAvailability
                }
                animationControl.alpha = 0f
                animationControl.visibility = View.VISIBLE
                animationControl.animate().alpha(1f).setDuration(180L).start()
            }
        }
        preview.setPayload(payload)
        preview.setRotationEnabled(true)
        var rotating = true
        rotation.setOnClickListener {
            rotating = !rotating
            preview.setRotationEnabled(rotating)
            rotation.setImageResource(
                if (rotating) R.drawable.ic_rotation_pause else R.drawable.ic_rotation_play
            )
            rotation.contentDescription = context.getString(
                if (rotating) R.string.pause_rotation else R.string.continue_rotation
            )
        }
        var iconAnimating = true
        iconAnimation.setOnClickListener {
            iconAnimating = !iconAnimating
            preview.setIconAnimationPlaying(iconAnimating)
            iconAnimation.setImageResource(
                if (iconAnimating) R.drawable.ic_animation_pause else R.drawable.ic_animation_play
            )
            iconAnimation.contentDescription = context.getString(
                if (iconAnimating) R.string.pause_icon_animation
                else R.string.continue_icon_animation
            )
        }

        var zoom = 1f
        fun applyZoom(value: Float) {
            zoom = value.coerceIn(1f, 2.5f)
            preview.animate().cancel()
            preview.animate()
                .scaleX(zoom)
                .scaleY(zoom)
                .setDuration(160L)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .start()
            zoomLabel.text = context.getString(R.string.zoom_percent, (zoom * 100f).toInt())
            zoomOut.isEnabled = zoom > 1f
            zoomIn.isEnabled = zoom < 2.5f
            zoomOut.alpha = if (zoomOut.isEnabled) 1f else 0.45f
            zoomIn.alpha = if (zoomIn.isEnabled) 1f else 0.45f
        }
        zoomOut.setOnClickListener { applyZoom(zoom - 0.25f) }
        zoomIn.setOnClickListener { applyZoom(zoom + 0.25f) }
        applyZoom(1f)

        var closing = false
        var callbackSent = false
        var afterClose: (() -> Unit)? = null
        fun close(after: (() -> Unit)? = null) {
            if (closing) return
            closing = true
            if (after == null) MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            afterClose = after
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            val density = context.resources.displayMetrics.density
            if (horizontalSlide) {
                panel.animate().alpha(0f).translationX(34f * density)
                    .setDuration(420L)
                    .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f))
                    .withEndAction { dialog.dismiss() }
                    .start()
            } else {
                panel.animate().alpha(0f).scaleX(0.985f).scaleY(0.985f)
                    .translationY(5f * density)
                    .setDuration(160L).withEndAction { dialog.dismiss() }.start()
            }
        }
        exportFile.setOnClickListener {
            selectedFile?.let(onExportFile)
        }
        replaceFile.setOnClickListener {
            selectedFile?.let(onReplaceFile)
        }
        addFile.setOnClickListener { onAddFile() }
        renameFile.setOnClickListener {
            selectedFile?.let(onRenameFile)
        }
        removeFile.setOnClickListener {
            selectedFile?.let(onRemoveFile)
        }
        changeDateTime.setOnClickListener { onChangeDateTime(currentModifiedDateTime) }
        changeRegion.setOnClickListener { onChangeRegion(currentSaveId) }
        view.findViewById<ImageButton>(R.id.expandedPreviewClose).setOnClickListener { close() }
        dialog.setOnCancelListener { close() }
        dialog.setOnDismissListener {
            preview.setRotationEnabled(false)
            preview.setIconAnimationPlaying(false)
            preview.suspendRenderer()
            if (!callbackSent) {
                callbackSent = true
                onClosed()
            }
            afterClose?.also { action ->
                afterClose = null
                action()
            }
        }

        val density = context.resources.displayMetrics.density
        val width = (context.resources.displayMetrics.widthPixels * 0.92f).toInt()
        val height = (context.resources.displayMetrics.heightPixels * 0.92f).toInt()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            attributes = attributes.apply {
                dimAmount = 0.72f
                windowAnimations = 0
                y = (12f * density).toInt()
            }
        }
        panel.alpha = 0f
        if (horizontalSlide) {
            panel.translationX = 34f * density
        } else {
            panel.scaleX = 0.98f
            panel.scaleY = 0.98f
            panel.translationY = 6f * density
        }
        dialog.show()
        dialog.window?.setLayout(width, height)
        if (horizontalSlide) {
            panel.animate().alpha(1f).translationX(0f)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .setDuration(520L)
                .start()
        } else {
            panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f))
                .setDuration(240L)
                .start()
        }
        return Handle(dialog, { close() }) {
                newTitle,
                newSerial,
                newRegion,
                newSaveId,
                newModifiedDateTime,
                newPayload,
                newFiles,
            ->
            currentSaveId = newSaveId
            currentModifiedDateTime = newModifiedDateTime
            currentFiles = newFiles
            selectedFile = null
            fileList.clearChoices()
            fileAdapter.setNotifyOnChange(false)
            fileAdapter.clear()
            fileAdapter.addAll(newFiles.map { item ->
                "${item.name}  •  ${formatSize(item.size)}"
            })
            fileAdapter.notifyDataSetChanged()
            updateTextFields(newTitle, newSerial, newRegion, newModifiedDateTime)
            updateFileVisibility()
            updateFileActions()
            preview.setPayload(newPayload)
            preview.setRotationEnabled(rotating)
            preview.setIconAnimationPlaying(iconAnimating)
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes >= 1024L * 1024L -> String.format(
            java.util.Locale.US,
            "%.1f MB",
            bytes / (1024.0 * 1024.0),
        )
        bytes >= 1024L -> "${(bytes + 1023L) / 1024L} KB"
        else -> "$bytes B"
    }
}

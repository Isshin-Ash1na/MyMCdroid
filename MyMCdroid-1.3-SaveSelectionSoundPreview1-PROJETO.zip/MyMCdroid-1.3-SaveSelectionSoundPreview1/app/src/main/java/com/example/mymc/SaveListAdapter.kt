package com.example.mymc

import android.app.Activity
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class SaveListAdapter(
    private val activity: Activity,
    private val saveNames: MutableList<String>,
    private val items: MutableList<String>,
    private val onSelect: (Int) -> Unit,
    private val onExport: (Int) -> Unit,
    private val onTransfer: (Int) -> Unit,
    private val onDelete: (Int) -> Unit,
    private val onMultiModeChanged: (Boolean, Set<Int>) -> Unit,
    private val onExpandPreview: (Int, String?) -> Unit
) : BaseAdapter() {

    var selectedPosition: Int = -1
    private val previewPayloads = mutableMapOf<String, String>()
    private val previewSnapshots = mutableMapOf<String, Bitmap>()
    private var attachedList: ListView? = null
    private var multiMode = false
    private var multiOrigin = -1
    private val multiSelected = linkedSetOf<Int>()
    private var transferAvailable = false
    private val sharedPreview = SavePreviewView(activity).apply {
        setCompactMode(true)
        setInteractive(false)
        alpha = 0f
        setOnRenderReadyListener {
            val parent = parent as? FrameLayout ?: return@setOnRenderReadyListener
            val snapshot = parent.findViewById<ImageView>(R.id.saveMiniSnapshot)
            animate().cancel()
            snapshot.animate().cancel()
            visibility = View.VISIBLE
            animate().alpha(1f).setDuration(160L).start()
            snapshot.animate().alpha(0f).setDuration(160L).start()
        }
        setOnClickListener {
            val position = getTag(R.id.press_bound_position) as? Int ?: return@setOnClickListener
            handlePreviewTap(position)
        }
    }

    fun setPreviewPayloads(payloads: Map<String, String>, snapshots: Map<String, Bitmap>) {
        previewPayloads.clear()
        previewPayloads.putAll(payloads)
        previewSnapshots.clear()
        previewSnapshots.putAll(snapshots)
        notifyDataSetChanged()
    }

    fun updatePreviewPayloads(payloads: Map<String, String>) {
        previewPayloads.putAll(payloads)
        val list = attachedList ?: return
        val changedNames = payloads.keys
        for (childIndex in 0 until list.childCount) {
            val position = list.firstVisiblePosition + childIndex
            if (saveNames.getOrNull(position) in changedNames) bindPreview(list.getChildAt(childIndex), position)
        }
    }

    fun clearPreviewPayloads() {
        detachSharedPreview()
        sharedPreview.clearSave()
        previewPayloads.clear()
        previewSnapshots.clear()
    }

    fun selectPosition(position: Int, animateActions: Boolean = false) {
        if (position !in items.indices || selectedPosition == position) return
        val previous = selectedPosition
        visibleView(previous)?.let { applySelectionState(it, previous, false, false) }
        selectedPosition = position
        visibleView(position)?.let { applySelectionState(it, position, true, animateActions) }
    }

    fun clearSelection() {
        val previous = selectedPosition
        if (previous < 0) return
        visibleView(previous)?.let { applySelectionState(it, previous, false, false) }
        selectedPosition = -1
        detachSharedPreview()
    }

    fun isMultiMode(): Boolean = multiMode

    fun selectedMultiPositions(): Set<Int> = multiSelected.toSet()

    fun setTransferAvailable(available: Boolean) {
        if (transferAvailable == available) return
        transferAvailable = available
        refreshVisibleRows()
    }

    fun suspendVisiblePreviews() {
        if (sharedPreview.parent != null) sharedPreview.suspendRenderer()
    }

    fun resumeVisiblePreviews() {
        if (sharedPreview.parent != null) sharedPreview.resumeRenderer()
    }

    fun exitMultiMode() {
        if (!multiMode) return
        multiMode = false
        multiOrigin = -1
        multiSelected.clear()
        refreshVisibleRows()
        onMultiModeChanged(false, emptySet())
    }

    private fun enterMultiMode(position: Int) {
        if (multiMode || position !in items.indices) return
        val previousSelection = selectedPosition
        visibleView(previousSelection)?.findViewById<View>(R.id.saveActions)?.let { actions ->
            actions.animate().cancel()
            actions.animate().alpha(0f).translationX(24f * activity.resources.displayMetrics.density)
                .setDuration(180L).withEndAction {
                    actions.visibility = View.INVISIBLE
                    visibleView(previousSelection)?.let { previousView ->
                        applySelectionState(previousView, previousSelection, previousSelection in multiSelected, false)
                    }
                }.start()
        }
        selectedPosition = -1
        detachSharedPreview()
        multiMode = true
        multiOrigin = position
        multiSelected.clear()
        multiSelected += position
        refreshVisibleRows(skipPosition = previousSelection)
        onMultiModeChanged(true, multiSelected.toSet())
    }

    private fun handleMultiTap(position: Int) {
        if (position == multiOrigin) {
            exitMultiMode()
            return
        }
        val added = multiSelected.add(position)
        if (!added) {
            multiSelected.remove(position)
        } else {
            MyMCSound.play(activity, MyMCSound.Effect.SAVE_SELECT, level = 0.78f)
        }
        visibleView(position)?.let { applySelectionState(it, position, position in multiSelected, false) }
        onMultiModeChanged(true, multiSelected.toSet())
    }

    private fun refreshVisibleRows(skipPosition: Int = -1) {
        val list = attachedList ?: return
        for (childIndex in 0 until list.childCount) {
            val position = list.firstVisiblePosition + childIndex
            if (position == skipPosition) continue
            val selected = if (multiMode) position in multiSelected else position == selectedPosition
            applySelectionState(list.getChildAt(childIndex), position, selected, false)
        }
    }

    private fun visibleView(position: Int): View? {
        val list = attachedList ?: return null
        val childIndex = position - list.firstVisiblePosition
        return if (childIndex in 0 until list.childCount) list.getChildAt(childIndex) else null
    }

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): String = items[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        attachedList = parent as? ListView
        val view = convertView ?: LayoutInflater.from(activity).inflate(R.layout.save_list_item, parent, false)
        // ListView recycles rows. Always discard visual properties left by a
        // cancelled entrance/exit animation before binding the new position.
        view.animate().cancel()
        view.clearAnimation()
        view.alpha = 1f
        view.translationX = 0f
        view.translationY = 0f
        view.scaleX = 1f
        view.scaleY = 1f
        view.visibility = View.VISIBLE
        view.setTag(R.id.press_bound_position, position)

        val title = view.findViewById<TextView>(R.id.saveTitle)
        val serial = view.findViewById<TextView>(R.id.saveSerial)
        val region = view.findViewById<TextView>(R.id.saveRegion)
        val previewContainer = view.findViewById<FrameLayout>(R.id.savePreviewContainer)
        val export = view.findViewById<ImageButton>(R.id.exportSaveRow)
        val transfer = view.findViewById<ImageButton>(R.id.transferSaveRow)
        val delete = view.findViewById<ImageButton>(R.id.deleteSaveRow)

        val lines = items[position].split("\n")
        title.text = lines.getOrElse(0) { activity.getString(R.string.game_save_default) }
        serial.text = lines.getOrElse(1) { activity.getString(R.string.save_serial_format, "—") }
        region.text = lines.getOrElse(2) { activity.getString(R.string.save_region_fallback) }

        bindPreview(view, position)
        val selected = if (multiMode) position in multiSelected else position == selectedPosition
        applySelectionState(view, position, selected, false)

        val selectSave = View.OnClickListener {
            if (multiMode) handleMultiTap(position)
            else if (selectedPosition != position) {
                selectPosition(position, animateActions = true)
                onSelect(position)
            }
        }
        val row = view.findViewById<LinearLayout>(R.id.saveRow)
        row.setOnClickListener(selectSave)
        previewContainer.setOnClickListener { handlePreviewTap(position) }
        installOneSecondPress(row, position)
        installOneSecondPress(previewContainer, position)
        export.setOnClickListener { onExport(position) }
        transfer.setOnClickListener { onTransfer(position) }
        delete.setOnClickListener { onDelete(position) }
        return view
    }

    private fun handlePreviewTap(position: Int) {
        if (multiMode) {
            handleMultiTap(position)
        } else if (selectedPosition == position) {
            onExpandPreview(position, previewPayloads[saveNames.getOrNull(position)])
        } else {
            selectPosition(position, animateActions = true)
            onSelect(position)
        }
    }

    private fun installOneSecondPress(target: View, position: Int) {
        target.setTag(R.id.press_bound_position, position)
        var startX = 0f
        var startY = 0f
        var activated = false
        var holding = false
        val trigger = Runnable {
            if (
                !multiMode && holding &&
                target.getTag(R.id.press_bound_position) == position
            ) {
                activated = true
                target.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                enterMultiMode(position)
            }
        }
        target.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activated = false
                    holding = true
                    startX = event.x
                    startY = event.y
                    view.postDelayed(trigger, 1000L)
                }
                MotionEvent.ACTION_MOVE -> {
                    val tolerance = 14f * activity.resources.displayMetrics.density
                    if (kotlin.math.abs(event.x - startX) > tolerance || kotlin.math.abs(event.y - startY) > tolerance) {
                        view.removeCallbacks(trigger)
                        holding = false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holding = false
                    view.removeCallbacks(trigger)
                    if (activated) {
                        activated = false
                        return@setOnTouchListener true
                    }
                }
            }
            false
        }
    }

    private fun bindPreview(view: View, position: Int) {
        val container = view.findViewById<FrameLayout>(R.id.savePreviewContainer)
        val snapshot = view.findViewById<ImageView>(R.id.saveMiniSnapshot)
        if (sharedPreview.parent === container && (multiMode || selectedPosition != position)) detachSharedPreview()
        val saveName = saveNames.getOrNull(position).orEmpty()
        snapshot.animate().cancel()
        snapshot.alpha = 1f
        snapshot.visibility = View.VISIBLE
        snapshot.setImageBitmap(previewSnapshots[saveName])
        snapshot.tag = saveName
    }

    private fun attachSharedPreview(view: View, position: Int) {
        val saveName = saveNames.getOrNull(position).orEmpty()
        val payload = previewPayloads[saveName] ?: run {
            if (sharedPreview.parent === view.findViewById<FrameLayout>(R.id.savePreviewContainer)) detachSharedPreview()
            return
        }
        val container = view.findViewById<FrameLayout>(R.id.savePreviewContainer)
        val snapshot = view.findViewById<ImageView>(R.id.saveMiniSnapshot)
        val oldParent = sharedPreview.parent as? FrameLayout
        if (oldParent !== container) {
            detachSharedPreview()
            sharedPreview.alpha = 0f
            sharedPreview.visibility = View.VISIBLE
            container.addView(
                sharedPreview,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        snapshot.alpha = 1f
        snapshot.visibility = View.VISIBLE
        sharedPreview.setTag(R.id.press_bound_position, position)
        sharedPreview.setRotationEnabled(true)
        sharedPreview.setPayload(payload)
    }

    private fun detachSharedPreview() {
        val parent = sharedPreview.parent as? FrameLayout ?: return
        sharedPreview.animate().cancel()
        parent.findViewById<ImageView>(R.id.saveMiniSnapshot)?.let { snapshot ->
            snapshot.animate().cancel()
            snapshot.alpha = 1f
            snapshot.visibility = View.VISIBLE
        }
        parent.removeView(sharedPreview)
        sharedPreview.alpha = 0f
        sharedPreview.setRotationEnabled(false)
    }

    private fun applySelectionState(view: View, position: Int, selected: Boolean, animateActions: Boolean) {
        val row = view.findViewById<LinearLayout>(R.id.saveRow)
        val container = view.findViewById<FrameLayout>(R.id.savePreviewContainer)
        val actions = view.findViewById<LinearLayout>(R.id.saveActions)
        view.findViewById<View>(R.id.transferSaveRow).visibility =
            if (transferAvailable) View.VISIBLE else View.GONE
        view.findViewById<ImageButton>(R.id.deleteSaveRow).apply {
            visibility = View.VISIBLE
            setImageResource(R.drawable.ic_delete_save)
            contentDescription = activity.getString(R.string.action_remove_game_save)
        }
        row.isSelected = selected
        row.setBackgroundResource(if (selected) R.drawable.save_row_selected else R.drawable.save_row_normal)
        if (selected && !multiMode) attachSharedPreview(view, position)
        else if (sharedPreview.parent === container) detachSharedPreview()
        actions.animate().cancel()
        val offset = 24f * activity.resources.displayMetrics.density
        if (!selected || multiMode) {
            actions.tag = null
            actions.alpha = 0f
            actions.translationX = offset
            actions.visibility = View.INVISIBLE
            return
        }
        actions.tag = position
        if (!animateActions) {
            actions.alpha = 1f
            actions.translationX = 0f
            actions.visibility = View.VISIBLE
            return
        }
        actions.alpha = 0f
        actions.translationX = offset
        actions.visibility = View.VISIBLE
        actions.animate()
            .alpha(1f)
            .translationX(0f)
            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
            .setDuration(220)
            .start()
    }
}

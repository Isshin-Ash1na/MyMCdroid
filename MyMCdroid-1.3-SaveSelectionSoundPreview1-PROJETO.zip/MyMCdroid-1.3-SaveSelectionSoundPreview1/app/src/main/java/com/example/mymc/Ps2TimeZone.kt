package com.example.mymc

import android.content.Context
import java.util.Locale

/** Timezone used by the target PS2 BIOS/emulator when showing Memory Card dates. */
object Ps2TimeZone {
    private const val PREFERENCES = "mymcdroid_preferences"
    private const val OFFSET_KEY = "ps2_timezone_offset_minutes"
    private const val MIN_OFFSET = -12 * 60
    private const val MAX_OFFSET = 14 * 60
    private const val STEP_MINUTES = 15

    // Matches the PS2/BIOS reference supplied for this project; it remains configurable.
    private const val DEFAULT_OFFSET_MINUTES = 4 * 60 + 30

    fun offsetMinutes(context: Context): Int = context
        .getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        .getInt(OFFSET_KEY, DEFAULT_OFFSET_MINUTES)
        .coerceIn(MIN_OFFSET, MAX_OFFSET)

    fun setOffsetMinutes(context: Context, value: Int) {
        val normalized = value.coerceIn(MIN_OFFSET, MAX_OFFSET)
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
            .edit()
            .putInt(OFFSET_KEY, normalized)
            .apply()
    }

    fun seekProgress(context: Context): Int =
        (offsetMinutes(context) - MIN_OFFSET) / STEP_MINUTES

    fun offsetForProgress(progress: Int): Int =
        (MIN_OFFSET + progress * STEP_MINUTES).coerceIn(MIN_OFFSET, MAX_OFFSET)

    fun maxProgress(): Int = (MAX_OFFSET - MIN_OFFSET) / STEP_MINUTES

    fun format(offsetMinutes: Int): String {
        val sign = if (offsetMinutes >= 0) "+" else "−"
        val absolute = kotlin.math.abs(offsetMinutes)
        return String.format(
            Locale.ROOT,
            "GMT%s%02d:%02d",
            sign,
            absolute / 60,
            absolute % 60,
        )
    }
}

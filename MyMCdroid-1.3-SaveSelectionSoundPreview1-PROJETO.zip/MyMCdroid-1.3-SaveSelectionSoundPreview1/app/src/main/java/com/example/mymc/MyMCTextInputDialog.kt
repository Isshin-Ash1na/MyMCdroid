package com.example.mymc

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.animation.PathInterpolator
import android.view.inputmethod.InputMethodManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

object MyMCTextInputDialog {
    fun show(
        context: Context,
        title: String,
        message: String,
        hint: String,
        initialText: String = "",
        iconRes: Int = R.drawable.ic_create_mc,
        confirmTextRes: Int = R.string.create,
        onCancel: (() -> Unit)? = null,
        validate: ((String) -> String?)? = null,
        onConfirm: (String) -> Unit,
    ) {
        val dialog = Dialog(context, R.style.Theme_MyMC_Dialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setWindowAnimations(0)
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_mymc_text_input, null)
        dialog.setContentView(view)
        dialog.setCancelable(true)
        dialog.setOnCancelListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            onCancel?.invoke()
        }

        view.findViewById<TextView>(R.id.inputTitle).text = title
        view.findViewById<TextView>(R.id.inputMessage).text = message
        view.findViewById<ImageView>(R.id.inputIcon).apply {
            setImageResource(iconRes)
            contentDescription = context.getString(
                if (iconRes == R.drawable.ic_dialog_alert) R.string.alert
                else R.string.action_create_memory_card
            )
        }
        val input = view.findViewById<EditText>(R.id.inputValue).apply {
            this.hint = hint
            setText(initialText)
            setSelection(text.length)
        }
        val panel = view.findViewById<View>(R.id.inputPanel)
        val offset = 6f * context.resources.displayMetrics.density
        val interpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
        panel.alpha = 0f
        panel.scaleX = 0.98f
        panel.scaleY = 0.98f
        panel.translationY = offset

        fun dismiss(after: (() -> Unit)? = null) {
            panel.animate()
                .alpha(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .translationY(offset * 0.65f)
                .setInterpolator(interpolator)
                .setDuration(160L)
                .withEndAction {
                    if (dialog.isShowing) dialog.dismiss()
                    after?.invoke()
                }
                .start()
        }

        view.findViewById<Button>(R.id.inputCancel).setOnClickListener {
            MyMCSound.play(context, MyMCSound.Effect.CANCEL)
            dismiss(onCancel)
        }
        val confirmButton = view.findViewById<Button>(R.id.inputConfirm)
        confirmButton.setText(confirmTextRes)
        confirmButton.setOnClickListener {
            val value = input.text?.toString().orEmpty().trim()
            val error = validate?.invoke(value)
            if (error != null) {
                input.error = error
                input.requestFocus()
                return@setOnClickListener
            }
            MyMCSound.play(context, MyMCSound.Effect.CONFIRM)
            dismiss { onConfirm(value) }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                confirmButton.performClick()
                true
            } else {
                false
            }
        }

        val width = (context.resources.displayMetrics.widthPixels * 0.86f).toInt()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.CENTER)
            attributes = attributes.apply {
                dimAmount = 0.72f
                windowAnimations = 0
            }
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        dialog.show()
        dialog.window?.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
        panel.post {
            panel.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setInterpolator(interpolator)
                .setDuration(240L)
                .withEndAction {
                    input.requestFocus()
                    val keyboard = context.getSystemService(Context.INPUT_METHOD_SERVICE)
                        as? InputMethodManager
                    keyboard?.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
                }
                .start()
        }
    }
}

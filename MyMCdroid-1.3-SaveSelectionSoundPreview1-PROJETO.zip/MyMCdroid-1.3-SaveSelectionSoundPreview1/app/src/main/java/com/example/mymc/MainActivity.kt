package com.example.mymc

import android.app.Activity
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.content.res.Configuration
import android.view.View
import android.view.MotionEvent
import android.view.animation.PathInterpolator
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import android.widget.ImageButton
import android.widget.AbsListView
import android.widget.ListView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private companion object {
        const val STATE_CARD_URI = "open_card_uri"
        const val STATE_CARD_IS_FOLDER = "open_card_is_folder"
        const val STATE_CARD_URIS = "open_card_uris"
        const val STATE_CARD_FOLDER_FLAGS = "open_card_folder_flags"
        const val STATE_ACTIVE_CARD_INDEX = "active_card_index"
    }

    private data class OpenCardSession(
        var file: File,
        val uri: Uri,
        val isFolder: Boolean,
        var snapshot: JSONObject,
        val displayName: String,
        var firstVisibleSave: Int = 0,
    )

    private enum class TransferMode { ONE, MANY, ALL }

    private lateinit var status: TextView
    private lateinit var cardName: TextView
    private lateinit var list: ListView
    private lateinit var adapter: SaveListAdapter
    private lateinit var importButton: ImageButton
    private lateinit var cardMenuButton: android.widget.ImageView
    private lateinit var cardInfoPanel: View
    private lateinit var cardActionsRow: View
    private lateinit var openCardActions: View
    private lateinit var allSaveActions: View
    private lateinit var transferAllActions: View
    private lateinit var multiExportActions: View
    private lateinit var transferManyActions: View
    private lateinit var createCardActions: View
    private lateinit var multiRemoveActions: View
    private lateinit var formatCardActions: View
    private lateinit var closeCardActions: View
    private lateinit var cardMenuPanel: android.view.ViewGroup
    private lateinit var cardPageIndicator: TextView
    private lateinit var cardSelectorScroll: android.widget.HorizontalScrollView
    private lateinit var cardSelector: android.widget.LinearLayout
    private val saves = mutableListOf<String>()
    private val saveDisplay = mutableListOf<String>()
    private var cardFile: File? = null
    private var cardUri: Uri? = null
    private var cardIsFolder = false
    private val openCards = mutableListOf<OpenCardSession>()
    private var activeCardIndex = -1
    private var selectedSave: String? = null
    private var importButtonAnimationToken = 0
    private var importButtonTargetVisible = false
    private var saveAnimationToken = 0
    private var saveListExpanded = false
    private var cardUiReady = false
    private var batchModeActive = false
    private var controlsExpanded = true
    private var cardContentTransitionActive = false
    private var controlsAnimationToken = 0
    private var saveListInteractionBlocked = false
    private var listPreparingPreviews = false
    private var rowPreviewsReady = true
    private var previewLoadToken = 0
    private var pendingExportAll = false
    private var pendingExportFormat = "psu"
    private var pendingSingleExportCard: File? = null
    private var pendingSingleExportSave: String? = null
    private var pendingCardSizeMb = 8
    private var pendingInternalSaveName: String? = null
    private var pendingInternalFileName: String? = null
    private var pendingInternalCardUri: String? = null
    private var expandedPreviewActive = false
    private var expandedPreviewHandle: SavePreviewDialog.Handle? = null
    private var expandedPreviewSaveName: String? = null
    private var swipeTracking = false
    private var swipeStartX = 0f
    private var swipeStartY = 0f
    private var swipeStartTime = 0L
    private val toolbarGroupAnimations = mutableMapOf<View, ValueAnimator>()
    private val toolbarVisibilityTargets = mutableMapOf<View, Boolean>()
    private val toolbarVisibilityTokens = mutableMapOf<View, Int>()
    private val pendingImports = ArrayDeque<Uri>()
    private val pendingFolderImports = ArrayDeque<File>()
    private var pendingFolderImportRoot: File? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val folderCardStorage by lazy { FolderCardStorage(this) }
    private val mymcApi by lazy { Python.getInstance().getModule("mymc_api") }

    private val openCard = 100
    private val exportPsu = 101
    private val importPsu = 102
    private val createCard = 104
    private val exportMany = 105
    private val openFolderCardRequest = 106
    private val createFolderCardRequest = 107
    private val exportInternalFileRequest = 108
    private val replaceInternalFileRequest = 109
    private val importFolderSaveRequest = 110
    private val exportFolderSaveRequest = 111
    private val importFolderSavesRequest = 112
    private val addInternalFileRequest = 113

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(AppLanguage.wrap(newBase))
    }

    override fun onDestroy() {
        toolbarGroupAnimations.values.toList().forEach { it.cancel() }
        toolbarGroupAnimations.clear()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putStringArrayList(
            STATE_CARD_URIS,
            ArrayList(openCards.map { it.uri.toString() }),
        )
        outState.putBooleanArray(
            STATE_CARD_FOLDER_FLAGS,
            openCards.map { it.isFolder }.toBooleanArray(),
        )
        outState.putInt(STATE_ACTIVE_CARD_INDEX, activeCardIndex)
        cardUri?.let { outState.putString(STATE_CARD_URI, it.toString()) }
        outState.putBoolean(STATE_CARD_IS_FOLDER, cardIsFolder)
        super.onSaveInstanceState(outState)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Keep the currently opened Memory Card when switching portrait/landscape.
        hideNavigationBar()
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        MyMCSound.initialize(this)
        hideNavigationBar()
        status = findViewById(R.id.status)
        cardName = findViewById(R.id.cardName)
        updateCardName(null)
        list = findViewById(R.id.saves)
        importButton = findViewById(R.id.importPsu)
        cardMenuButton = findViewById(R.id.cardMenuButton)
        cardInfoPanel = findViewById(R.id.cardInfoPanel)
        cardActionsRow = findViewById(R.id.cardActionsRow)
        cardPageIndicator = findViewById(R.id.cardPageIndicator)
        cardSelectorScroll = findViewById(R.id.cardSelectorScroll)
        cardSelector = findViewById(R.id.cardSelector)
        openCardActions = findViewById(R.id.openCardActions)
        allSaveActions = findViewById(R.id.allSaveActions)
        transferAllActions = findViewById(R.id.transferAllActions)
        multiExportActions = findViewById(R.id.multiExportActions)
        transferManyActions = findViewById(R.id.transferManyActions)
        createCardActions = findViewById(R.id.createCardActions)
        multiRemoveActions = findViewById(R.id.multiRemoveActions)
        formatCardActions = findViewById(R.id.formatCardActions)
        closeCardActions = findViewById(R.id.closeCardActions)
        cardMenuPanel = findViewById(R.id.cardMenuPanel)
        adapter = SaveListAdapter(
            this,
            saves,
            saveDisplay,
            onSelect = { position ->
                selectedSave = saves.getOrNull(position)
                if (selectedSave != null) {
                    MyMCSound.play(this, MyMCSound.Effect.SAVE_SELECT, level = 0.78f)
                }
            },
            onExport = { position ->
                selectSaveAt(position)
                showExportFormatChoice { format -> chooseExportTarget(format) }
            },
            onTransfer = { position ->
                selectSaveAt(position)
                selectedSave?.let { confirmTransferSaves(listOf(it), TransferMode.ONE) }
            },
            onDelete = { position ->
                selectSaveAt(position)
                deleteSelectedSave()
            },
            onMultiModeChanged = { active, positions ->
                setMultiSaveActionsVisible(active)
                if (active) {
                    status.text = getString(R.string.save_games_selected_count, positions.size)
                } else {
                    updatePermanentStatus()
                }
            },
            onExpandPreview = { position, payload ->
                openExpandedPreview(position, payload)
            }
        )
        list.adapter = adapter
        list.setOnTouchListener { _, _ -> saveListInteractionBlocked || listPreparingPreviews }
        var saveScrollState = AbsListView.OnScrollListener.SCROLL_STATE_IDLE
        var lastSoundedFirstItem = -1
        list.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {
                saveScrollState = scrollState
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
                    lastSoundedFirstItem = list.firstVisiblePosition
                }
            }

            override fun onScroll(
                view: AbsListView?,
                firstVisibleItem: Int,
                visibleItemCount: Int,
                totalItemCount: Int,
            ) {
                if (
                    saveScrollState != AbsListView.OnScrollListener.SCROLL_STATE_IDLE &&
                    firstVisibleItem != lastSoundedFirstItem &&
                    totalItemCount > visibleItemCount
                ) {
                    lastSoundedFirstItem = firstVisibleItem
                    MyMCSound.playScrollTick(this@MainActivity)
                }
            }
        })
        findViewById<ImageButton>(R.id.open).setOnClickListener {
            startToolbarAction()
            confirmOpenCard()
        }
        importButton.setOnClickListener {
            startToolbarAction()
            chooseImportSource()
        }
        findViewById<ImageButton>(R.id.exportAllSaves).setOnClickListener {
            startToolbarAction()
            showExportFormatChoice(onCancel = ::finishToolbarAction) { format ->
                chooseAllExportFolder(format)
            }
        }
        findViewById<ImageButton>(R.id.transferAllSaves).setOnClickListener {
            startToolbarAction()
            confirmTransferSaves(saves.toList(), TransferMode.ALL)
        }
        findViewById<ImageButton>(R.id.createCard).setOnClickListener {
            startToolbarAction()
            confirmCreateCard()
        }
        findViewById<ImageButton>(R.id.closeCard).setOnClickListener {
            startToolbarAction()
            confirmCloseCard()
        }
        findViewById<ImageButton>(R.id.deleteAllSaves).setOnClickListener {
            startToolbarAction()
            confirmDeleteAllSaves()
        }
        findViewById<ImageButton>(R.id.exportManySaves).setOnClickListener {
            startToolbarAction()
            showExportFormatChoice(onCancel = ::finishToolbarAction) { format ->
                chooseMultiExportFolder(format)
            }
        }
        findViewById<ImageButton>(R.id.transferManySaves).setOnClickListener {
            startToolbarAction()
            confirmTransferSaves(selectedMultiSaveNames(), TransferMode.MANY)
        }
        findViewById<ImageButton>(R.id.deleteManySaves).setOnClickListener {
            startToolbarAction()
            confirmDeleteSelectedSaves()
        }
        cardMenuButton.setOnClickListener {
            setCardContentExpanded(!controlsExpanded)
        }
        findViewById<ImageButton>(R.id.infoButton).setOnClickListener {
            ManualDialog.show(this) { confirmCloseApp() }
        }
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        if (state == null) MyMCSound.play(this, MyMCSound.Effect.APP_OPEN)
        restoreOpenCards(state)
    }

    private fun openExpandedPreview(position: Int, payload: String?) {
        if (expandedPreviewActive) return
        if (payload.isNullOrBlank()) {
            MyMCToast.show(this, getString(R.string.preview_preparing))
            return
        }
        val source = activeSession() ?: return
        val saveName = saves.getOrNull(position) ?: return
        val lines = saveDisplay.getOrNull(position).orEmpty().split("\n")
        val expectedPath = source.file.absolutePath
        val expectedUri = source.uri.toString()
        val timezoneOffset = Ps2TimeZone.offsetMinutes(this)
        expandedPreviewActive = true
        adapter.suspendVisiblePreviews()
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_loading_game_save_files),
            saveName,
        )
        ioExecutor.execute {
            var loadError: Exception? = null
            val api = mymcApi
            var modifiedDateTime = ""
            val files = try {
                val array = JSONArray(
                    api.callAttr("list_save_files", expectedPath, saveName).toString()
                )
                (0 until array.length()).map { index ->
                    val item = array.getJSONObject(index)
                    SavePreviewDialog.FileItem(
                        item.getString("name"),
                        item.optLong("size", 0L),
                    )
                }
            } catch (error: Exception) {
                loadError = error
                emptyList()
            }
            try {
                val dateInfo = JSONObject(
                    api.callAttr(
                        "get_save_datetime",
                        expectedPath,
                        saveName,
                        timezoneOffset,
                    ).toString()
                )
                modifiedDateTime = dateInfo
                    .optJSONObject("modified")
                    ?.optString("display")
                    .orEmpty()
            } catch (_: Exception) {
                // The editor remains available with the current device time as fallback.
            }
            runOnUiThread {
                progress.dismiss()
                if (
                    isFinishing || isDestroyed || !expandedPreviewActive ||
                    activeSession()?.uri?.toString() != expectedUri ||
                    cardFile?.absolutePath != expectedPath
                ) {
                    expandedPreviewActive = false
                    adapter.resumeVisiblePreviews()
                    return@runOnUiThread
                }
                loadError?.let {
                    MyMCToast.show(this, getString(R.string.preview_open_failed), it.message, true)
                }
                try {
                    expandedPreviewHandle = SavePreviewDialog.show(
                        this,
                        lines.getOrElse(0) { getString(R.string.game_save_default) },
                        lines.getOrElse(1) { getString(R.string.save_serial_format, "—") },
                        lines.getOrElse(2) { getString(R.string.save_region_fallback) },
                        saveName,
                        modifiedDateTime,
                        payload,
                        files,
                        allowEditing = true,
                        onExportFile = { fileName ->
                            chooseInternalFileExport(saveName, fileName, expectedUri)
                        },
                        onReplaceFile = { fileName ->
                            chooseInternalFileReplacement(saveName, fileName, expectedUri)
                        },
                        onAddFile = {
                            chooseInternalFileAddition(saveName, expectedUri)
                        },
                        onRenameFile = { fileName ->
                            requestInternalFileRename(saveName, fileName, expectedUri)
                        },
                        onRemoveFile = { fileName ->
                            confirmInternalFileRemoval(saveName, fileName, expectedUri)
                        },
                        onChangeDateTime = { currentDateTime ->
                            requestSaveDateTimeChange(saveName, currentDateTime, expectedUri)
                        },
                        onChangeRegion = { currentId ->
                            requestSaveRegionChange(currentId, expectedUri)
                        },
                        horizontalSlide = false,
                    ) {
                        expandedPreviewHandle = null
                        expandedPreviewSaveName = null
                        expandedPreviewActive = false
                        adapter.resumeVisiblePreviews()
                    }
                    expandedPreviewSaveName = saveName
                } catch (error: Exception) {
                    expandedPreviewActive = false
                    adapter.resumeVisiblePreviews()
                    MyMCToast.show(
                        this,
                        getString(R.string.preview_open_failed),
                        error.message,
                        true,
                    )
                }
            }
        }
    }

    private fun refreshExpandedPreview(sourceUri: String, saveName: String) {
        if (!expandedPreviewActive || expandedPreviewHandle == null) return
        val source = openCards.firstOrNull { it.uri.toString() == sourceUri } ?: return
        if (source.uri.toString() != activeSession()?.uri?.toString()) return
        val position = saves.indexOf(saveName)
        if (position < 0) return
        val lines = saveDisplay.getOrNull(position).orEmpty().split("\n")
        val expectedPath = source.file.absolutePath
        val timezoneOffset = Ps2TimeZone.offsetMinutes(this)
        ioExecutor.execute {
            try {
                val api = mymcApi
                val fileArray = JSONArray(
                    api.callAttr("list_save_files", expectedPath, saveName).toString()
                )
                val files = (0 until fileArray.length()).map { index ->
                    val item = fileArray.getJSONObject(index)
                    SavePreviewDialog.FileItem(
                        item.getString("name"),
                        item.optLong("size", 0L),
                    )
                }
                val dateInfo = JSONObject(
                    api.callAttr(
                        "get_save_datetime",
                        expectedPath,
                        saveName,
                        timezoneOffset,
                    ).toString()
                )
                val modifiedDateTime = dateInfo
                    .optJSONObject("modified")
                    ?.optString("display")
                    .orEmpty()
                val payload = JSONObject(
                    api.callAttr("get_icon_payload", expectedPath, saveName).toString()
                ).toString()
                runOnUiThread {
                    if (
                        !expandedPreviewActive ||
                        activeSession()?.uri?.toString() != sourceUri ||
                        activeSession()?.file?.absolutePath != expectedPath
                    ) return@runOnUiThread
                    expandedPreviewHandle?.refresh(
                        lines.getOrElse(0) { getString(R.string.game_save_default) },
                        lines.getOrElse(1) { getString(R.string.save_serial_format, "—") },
                        lines.getOrElse(2) { getString(R.string.save_region_fallback) },
                        saveName,
                        modifiedDateTime,
                        payload,
                        files,
                    )
                }
            } catch (error: Exception) {
                runOnUiThread {
                    MyMCToast.show(
                        this,
                        getString(R.string.preview_refresh_failed),
                        error.message,
                        true,
                    )
                }
            }
        }
    }

    private fun hideNavigationBar() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.navigationBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideNavigationBar()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (!::list.isInitialized) return super.dispatchTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                swipeTracking = !saveListInteractionBlocked && !listPreparingPreviews &&
                    !cardContentTransitionActive && !expandedPreviewActive && openCards.size >= 2
                swipeStartX = event.rawX
                swipeStartY = event.rawY
                swipeStartTime = event.eventTime
            }
            MotionEvent.ACTION_MOVE -> {
                if (swipeTracking) {
                    val dx = kotlin.math.abs(event.rawX - swipeStartX)
                    val dy = kotlin.math.abs(event.rawY - swipeStartY)
                    val tolerance = 18f * resources.displayMetrics.density
                    if (dy > tolerance && dy > dx * 1.15f) swipeTracking = false
                }
            }
            MotionEvent.ACTION_UP -> {
                if (swipeTracking) {
                    val dx = event.rawX - swipeStartX
                    val dy = event.rawY - swipeStartY
                    val threshold = 64f * resources.displayMetrics.density
                    val quickEnough = event.eventTime - swipeStartTime <= 1200L
                    val direction = if (dx < 0f) 1 else -1
                    val target = activeCardIndex + direction
                    if (
                        quickEnough && kotlin.math.abs(dx) >= threshold &&
                        kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.25f &&
                        target in openCards.indices
                    ) {
                        swipeTracking = false
                        val cancel = MotionEvent.obtain(event)
                        cancel.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(cancel)
                        cancel.recycle()
                        switchToCard(target, direction)
                        return true
                    }
                }
                swipeTracking = false
            }
            MotionEvent.ACTION_CANCEL -> swipeTracking = false
        }
        return super.dispatchTouchEvent(event)
    }

    private fun showConfirmDialog(
        title: String,
        message: String? = null,
        onCancel: (() -> Unit)? = null,
        onConfirm: () -> Unit
    ) {
        MyMCDialog.show(this, title, message, onCancel = onCancel, onConfirm = onConfirm)
    }

    private fun restoreOpenCards(state: Bundle?) {
        if (state == null) return
        val savedUris = state.getStringArrayList(STATE_CARD_URIS)
            ?.map(Uri::parse)
            .orEmpty()
            .ifEmpty {
                state.getString(STATE_CARD_URI)?.let { listOf(Uri.parse(it)) }.orEmpty()
            }
        if (savedUris.isEmpty()) return
        val savedFlags = state.getBooleanArray(STATE_CARD_FOLDER_FLAGS)
        val legacyFolder = state.getBoolean(STATE_CARD_IS_FOLDER, false)
        val desiredActive = state.getInt(STATE_ACTIVE_CARD_INDEX, savedUris.lastIndex)
        ioExecutor.execute {
            val restored = mutableListOf<OpenCardSession>()
            savedUris.forEachIndexed { index, uri ->
                var local: File? = null
                try {
                    val isFolder = savedFlags?.getOrNull(index) ?: legacyFolder
                    val opened = if (isFolder) folderCardStorage.copyTreeToCache(uri) else copyToCache(uri)
                    local = opened
                    val api = mymcApi
                    if (api.callAttr("card_state", opened.absolutePath).toString() != "valid") {
                        throw IllegalStateException(getString(R.string.card_invalid))
                    }
                    val snapshot = JSONObject(
                        api.callAttr("card_snapshot", opened.absolutePath).toString()
                    )
                    restored += OpenCardSession(
                        opened,
                        uri,
                        isFolder,
                        snapshot,
                        resolveCardDisplayName(uri, isFolder),
                    )
                } catch (_: Exception) {
                    discardCardCache(local)
                }
            }
            runOnUiThread {
                if (restored.isEmpty()) return@runOnUiThread
                openCards.clear()
                openCards.addAll(restored)
                activeCardIndex = desiredActive.coerceIn(openCards.indices)
                syncActiveSessionAliases()
                showActiveCardSession(scheduleContext = true)
            }
        }
    }

    private fun resolveCardDisplayName(uri: Uri, isFolder: Boolean): String {
        if (isFolder) {
            return folderCardStorage.treeDisplayName(uri)
        }
        var name: String? = null
        try {
            contentResolver.query(
                uri,
                arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)
                }
            }
        } catch (_: Exception) { }
        return name?.takeIf { it.isNotBlank() }
            ?: Uri.decode(uri.lastPathSegment.orEmpty())
                .substringAfterLast('/')
                .substringAfterLast(':')
                .takeIf { it.isNotBlank() }
            ?: getString(R.string.selected_file)
    }

    private fun activeSession(): OpenCardSession? = openCards.getOrNull(activeCardIndex)

    private fun registerCardSession(
        file: File,
        uri: Uri,
        isFolder: Boolean,
        snapshot: JSONObject,
    ): Boolean {
        val existing = openCards.indexOfFirst { it.uri.toString() == uri.toString() }
        val session = OpenCardSession(
            file,
            uri,
            isFolder,
            snapshot,
            resolveCardDisplayName(uri, isFolder),
        )
        if (existing >= 0) {
            val previous = openCards[existing].file
            openCards[existing] = session
            if (previous.absolutePath != file.absolutePath) discardCardCache(previous)
            activeCardIndex = existing
        } else {
            openCards += session
            activeCardIndex = openCards.lastIndex
        }
        syncActiveSessionAliases()
        return true
    }

    private fun syncActiveSessionAliases() {
        val session = activeSession()
        cardFile = session?.file
        cardUri = session?.uri
        cardIsFolder = session?.isFolder ?: false
        updateCardName(session?.uri)
        updateCardPageIndicator()
        if (::adapter.isInitialized) adapter.setTransferAvailable(openCards.size >= 2)
    }

    private fun updateCardPageIndicator() {
        if (!::cardPageIndicator.isInitialized) return
        val multiple = openCards.size >= 2 && activeCardIndex in openCards.indices
        cardPageIndicator.visibility = if (multiple) View.VISIBLE else View.INVISIBLE
        cardPageIndicator.text = if (multiple) {
            getString(R.string.memory_card_page_format, activeCardIndex + 1, openCards.size)
        } else ""
        updateCardSelector()
    }

    private fun updateCardSelector() {
        if (!::cardSelector.isInitialized || !::cardSelectorScroll.isInitialized) return
        val showSelector = openCards.size >= 2
        cardSelectorScroll.visibility = if (showSelector) View.VISIBLE else View.GONE
        cardSelector.removeAllViews()
        if (!showSelector) return
        val density = resources.displayMetrics.density
        openCards.forEachIndexed { index, session ->
            val selected = index == activeCardIndex
            val item = TextView(this).apply {
                text = getString(R.string.card_selector_item, index + 1, session.displayName)
                contentDescription = getString(
                    R.string.card_selector_description,
                    index + 1,
                    openCards.size,
                    session.displayName,
                )
                setTextColor(getColor(if (selected) R.color.ps2_green else R.color.ps2_text_secondary))
                textSize = 11f
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = android.view.Gravity.CENTER
                minWidth = (104f * density).toInt()
                maxWidth = (178f * density).toInt()
                setPadding((12f * density).toInt(), 0, (12f * density).toInt(), 0)
                setBackgroundResource(
                    if (selected) R.drawable.card_selector_selected
                    else R.drawable.card_selector_normal
                )
                isClickable = !selected
                isFocusable = !selected
                setOnClickListener {
                    val direction = if (index > activeCardIndex) 1 else -1
                    switchToCard(index, direction)
                }
            }
            cardSelector.addView(
                item,
                android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    (32f * density).toInt(),
                ).apply {
                    if (index > 0) marginStart = (5f * density).toInt()
                },
            )
        }
        cardSelectorScroll.post {
            val active = cardSelector.getChildAt(activeCardIndex) ?: return@post
            val targetX = (active.left - (cardSelectorScroll.width - active.width) / 2).coerceAtLeast(0)
            cardSelectorScroll.smoothScrollTo(targetX, 0)
        }
    }

    private fun replaceActiveCard(file: File, snapshot: JSONObject) {
        val session = activeSession() ?: return
        val previous = session.file
        session.file = file
        session.snapshot = snapshot
        cardFile = file
        if (previous.absolutePath != file.absolutePath) discardCardCache(previous)
    }

    private fun showActiveCardSession(scheduleContext: Boolean) {
        val session = activeSession() ?: return
        cardMenuButton.setImageResource(R.drawable.ic_memory_card)
        syncActiveSessionAliases()
        showCardContents(
            session.snapshot.getJSONArray("saves"),
            updateStatus = false,
            previewFile = session.file,
        )
        applyCardStatus(session.snapshot.getJSONObject("stats"))
        if (scheduleContext) scheduleCardContextActions()
    }

    private fun switchToCard(targetIndex: Int, direction: Int) {
        if (
            targetIndex !in openCards.indices ||
            targetIndex == activeCardIndex ||
            cardContentTransitionActive || expandedPreviewActive
        ) return
        MyMCSound.playCardTransition(this, direction)
        activeSession()?.firstVisibleSave = list.firstVisiblePosition.coerceAtLeast(0)
        if (adapter.isMultiMode()) adapter.exitMultiMode()
        clearSelectionState()
        cardContentTransitionActive = true
        saveListInteractionBlocked = true
        cardUiReady = false
        setImportButtonVisible(false)
        setToolbarGroupEnabled(cardMenuPanel, false)
        val distance = 34f * resources.displayMetrics.density
        val outgoing = if (direction > 0) -distance else distance
        val incoming = -outgoing

        cardInfoPanel.animate().cancel()
        cardActionsRow.animate().cancel()
        cardInfoPanel.animate()
            .alpha(0f)
            .translationX(outgoing)
            .setDuration(420L)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f))
            .start()
        cardActionsRow.animate()
            .alpha(0f)
            .translationX(outgoing)
            .setDuration(420L)
            .setInterpolator(PathInterpolator(0.4f, 0f, 0.2f, 1f))
            .start()
        animateSaveRows(false) {
            activeCardIndex = targetIndex
            syncActiveSessionAliases()
            val target = activeSession() ?: return@animateSaveRows
            list.setSelection(target.firstVisibleSave)
            cardInfoPanel.translationX = incoming
            cardInfoPanel.alpha = 0f
            cardActionsRow.translationX = incoming
            cardActionsRow.alpha = 0f
            cardUiReady = true
            showActiveCardSession(scheduleContext = false)
            refreshToolbarAvailability()
            if (controlsExpanded) setImportButtonVisible(true)
            cardInfoPanel.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(520L)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .start()
            cardActionsRow.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(520L)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .withEndAction {
                    cardContentTransitionActive = false
                    saveListInteractionBlocked = false
                    setToolbarGroupEnabled(cardMenuPanel, true)
                }
                .start()
        }
    }

    private fun clearSelectionState() {
        if (::adapter.isInitialized && adapter.isMultiMode()) adapter.exitMultiMode()
        selectedSave = null
        list.clearChoices()
        adapter.clearSelection()
    }

    private fun startToolbarAction() {
        saveListInteractionBlocked = true
    }

    private fun finishToolbarAction() {
        saveListInteractionBlocked = false
    }

    private fun setCardContentExpanded(expanded: Boolean) {
        if (cardContentTransitionActive || controlsExpanded == expanded) return
        MyMCSound.playFunctionTransition(this)
        controlsExpanded = expanded
        cardContentTransitionActive = true
        saveListInteractionBlocked = true
        cardMenuButton.isEnabled = false
        val token = ++controlsAnimationToken
        val density = resources.displayMetrics.density
        val params = cardActionsRow.layoutParams
        val fullHeight = (60f * density).toInt()
        val shouldAnimateSaves = cardFile != null &&
            saves.isNotEmpty() &&
            (!expanded || (rowPreviewsReady && !listPreparingPreviews))
        var toolbarFinished = false
        var savesFinished = !shouldAnimateSaves

        fun finishWhenReady() {
            if (
                token != controlsAnimationToken ||
                !toolbarFinished || !savesFinished
            ) return
            if (!expanded) {
                params.height = 0
                cardActionsRow.layoutParams = params
                cardActionsRow.visibility = View.INVISIBLE
                cardActionsRow.alpha = 1f
                cardActionsRow.translationY = 0f
            } else {
                setToolbarGroupEnabled(cardMenuPanel, true)
            }
            cardContentTransitionActive = false
            saveListInteractionBlocked = false
            cardMenuButton.isEnabled = true
        }

        cardActionsRow.animate().cancel()
        setToolbarGroupEnabled(cardMenuPanel, false)
        if (expanded) {
            params.height = fullHeight
            cardActionsRow.layoutParams = params
            cardActionsRow.visibility = View.VISIBLE
            cardActionsRow.alpha = 0f
            cardActionsRow.translationY = -10f * density
            if (cardFile != null && cardUiReady) {
                setImportButtonVisible(true)
            }
        } else {
            setImportButtonVisible(false)
            cardActionsRow.alpha = 1f
            cardActionsRow.translationY = 0f
        }

        cardActionsRow.animate()
            .alpha(if (expanded) 1f else 0f)
            .translationY(if (expanded) 0f else -10f * density)
            .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
            .setDuration(460L)
            .withEndAction {
                if (token != controlsAnimationToken) return@withEndAction
                toolbarFinished = true
                finishWhenReady()
            }
            .start()

        if (shouldAnimateSaves) {
            animateSaveRows(expanded, if (expanded) 45L else 0L) {
                if (token != controlsAnimationToken) return@animateSaveRows
                savesFinished = true
                finishWhenReady()
            }
        } else {
            finishWhenReady()
        }
    }

    private fun setMultiSaveActionsVisible(visible: Boolean) {
        if (batchModeActive == visible) return
        MyMCSound.playFunctionTransition(this)
        batchModeActive = visible
        if (visible) {
            setToolbarGroupVisible(allSaveActions, false)
            setToolbarGroupVisible(transferAllActions, false)
            setToolbarGroupVisible(formatCardActions, false)
        }
        setToolbarGroupVisible(multiExportActions, visible)
        setToolbarGroupVisible(transferManyActions, visible && openCards.size >= 2, if (visible) 80L else 0L)
        setToolbarGroupVisible(multiRemoveActions, visible, if (visible) 100L else 0L)
        if (!visible) {
            refreshToolbarAvailability()
            if (controlsExpanded && cardFile != null && cardUiReady) {
                setImportButtonVisible(true)
            }
        }
    }

    private fun setToolbarGroupEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        if (view is android.view.ViewGroup) {
            for (index in 0 until view.childCount) {
                setToolbarGroupEnabled(view.getChildAt(index), enabled)
            }
        }
    }

    private fun measureToolbarGroupWidth(group: View): Int {
        val params = group.layoutParams
        val originalWidth = params.width
        params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        val height = when {
            params.height > 0 -> params.height
            group.height > 0 -> group.height
            else -> (54f * resources.displayMetrics.density).toInt()
        }
        group.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
        )
        val measuredWidth = group.measuredWidth.coerceAtLeast(1)
        params.width = originalWidth
        return measuredWidth
    }

    private fun animateToolbarGroup(
        group: View,
        show: Boolean,
        isCurrent: () -> Boolean
    ) {
        toolbarGroupAnimations.remove(group)?.cancel()
        setToolbarGroupEnabled(group, false)

        val params = group.layoutParams
        if (!show && group.visibility != View.VISIBLE) {
            group.visibility = View.GONE
            group.alpha = 1f
            group.translationX = 0f
            params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
            group.layoutParams = params
            return
        }

        val targetWidth = measureToolbarGroupWidth(group)
        val offset = 26f * resources.displayMetrics.density
        val startWidth = if (group.visibility == View.VISIBLE && group.width > 0) group.width else 0
        val startAlpha = if (group.visibility == View.VISIBLE) group.alpha else 0f
        val startTranslation = if (group.visibility == View.VISIBLE) group.translationX else offset
        val endWidth = if (show) targetWidth else 0
        val endAlpha = if (show) 1f else 0f
        val endTranslation = if (show) 0f else offset

        params.width = startWidth
        group.layoutParams = params
        group.alpha = startAlpha
        group.translationX = startTranslation
        group.visibility = View.VISIBLE

        var cancelled = false
        val animator = ValueAnimator.ofFloat(0f, 1f)
        animator.duration = 1000L
        animator.interpolator = if (show) {
            PathInterpolator(0.2f, 0f, 0f, 1f)
        } else {
            PathInterpolator(0.4f, 0f, 0.2f, 1f)
        }
        animator.addUpdateListener { valueAnimator ->
            val fraction = valueAnimator.animatedValue as Float
            params.width = (startWidth + (endWidth - startWidth) * fraction).toInt()
            group.alpha = startAlpha + (endAlpha - startAlpha) * fraction
            group.translationX = startTranslation + (endTranslation - startTranslation) * fraction
            group.layoutParams = params
            cardMenuPanel.requestLayout()
        }
        animator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (toolbarGroupAnimations[group] === animator) {
                    toolbarGroupAnimations.remove(group)
                }
                if (cancelled || !isCurrent()) return
                if (show) {
                    params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                    group.layoutParams = params
                    group.alpha = 1f
                    group.translationX = 0f
                    group.visibility = View.VISIBLE
                    setToolbarGroupEnabled(group, true)
                } else {
                    group.visibility = View.GONE
                    params.width = android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                    group.layoutParams = params
                    group.alpha = 1f
                    group.translationX = 0f
                    setToolbarGroupEnabled(group, false)
                }
                cardMenuPanel.requestLayout()
            }
        })
        toolbarGroupAnimations[group] = animator
        animator.start()
    }

    private fun selectedMultiSaveNames(): List<String> =
        adapter.selectedMultiPositions().sorted().mapNotNull { saves.getOrNull(it) }

    private fun selectSaveAt(position: Int) {
        if (position !in saves.indices) return
        selectedSave = saves[position]
        adapter.selectPosition(position)
    }

    private fun updatePermanentStatus() {
        val file = cardFile
        if (file == null) {
            setImportButtonVisible(false)
            refreshToolbarAvailability()
            cardInfoPanel.setBackgroundResource(R.drawable.ps2_panel)
            status.text = getString(R.string.no_memory_card_open)
            return
        }
        cardInfoPanel.setBackgroundResource(R.drawable.card_info_selected_green)
        try {
            val api = mymcApi
            val stats = org.json.JSONObject(api.callAttr("card_stats", file.absolutePath).toString())
            applyCardStatus(stats)
        } catch (_: Exception) {
            status.text = getString(R.string.save_games_found_count, saves.size)
            refreshToolbarAvailability()
        }
    }

    private fun applyCardStatus(stats: JSONObject) {
        cardInfoPanel.setBackgroundResource(R.drawable.card_info_selected_green)
        val freeBytes = stats.optLong("free_bytes", 0L)
        val freeKb = freeBytes / 1024L
        status.text = if (stats.optBoolean("dynamic", false)) {
            getString(R.string.save_games_found_dynamic, saves.size)
        } else if (freeBytes <= 0L) {
            getString(R.string.save_games_found_full, saves.size)
        } else {
            getString(R.string.save_games_found_free, saves.size, freeKb)
        }
        refreshToolbarAvailability()
    }

    private fun setImportButtonVisible(visible: Boolean) {
        val shouldShow = visible
        importButtonTargetVisible = shouldShow
        val token = ++importButtonAnimationToken
        val offset = 18f * resources.displayMetrics.density
        importButton.animate().cancel()
        importButton.clearAnimation()
        if (shouldShow) {
            importButton.isClickable = true
            if (importButton.visibility != View.VISIBLE) {
                importButton.alpha = 0f
                importButton.translationX = offset
                importButton.visibility = View.VISIBLE
            }
            importButton.animate()
                .alpha(1f)
                .translationX(0f)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .setDuration(520)
                .withEndAction {
                    if (token == importButtonAnimationToken && importButtonTargetVisible) {
                        importButton.alpha = 1f
                        importButton.translationX = 0f
                        importButton.visibility = View.VISIBLE
                        importButton.isClickable = true
                    }
                }
                .start()
        } else {
            importButton.isClickable = false
            if (importButton.visibility != View.VISIBLE) {
                importButton.visibility = View.INVISIBLE
                importButton.alpha = 0f
                importButton.translationX = 0f
                return
            }
            importButton.animate()
                .alpha(0f)
                .translationX(offset)
                .setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
                .setDuration(520)
                .withEndAction {
                    if (token == importButtonAnimationToken && !importButtonTargetVisible) {
                        importButton.translationX = 0f
                        importButton.alpha = 0f
                        importButton.visibility = View.INVISIBLE
                        importButton.isClickable = false
                    }
                }
                .start()
        }
    }

    private fun setToolbarGroupVisible(group: View, visible: Boolean, delayMs: Long = 0L) {
        if (toolbarVisibilityTargets[group] == visible) return
        toolbarVisibilityTargets[group] = visible
        val token = (toolbarVisibilityTokens[group] ?: 0) + 1
        toolbarVisibilityTokens[group] = token
        if (!visible) {
            animateToolbarGroup(group, false) {
                toolbarVisibilityTokens[group] == token && toolbarVisibilityTargets[group] == false
            }
            return
        }
        setToolbarGroupEnabled(group, false)
        window.decorView.postDelayed({
            if (toolbarVisibilityTokens[group] != token || toolbarVisibilityTargets[group] != true) {
                return@postDelayed
            }
            animateToolbarGroup(group, true) {
                toolbarVisibilityTokens[group] == token && toolbarVisibilityTargets[group] == true
            }
        }, delayMs)
    }

    private fun refreshToolbarAvailability() {
        val ready = cardFile != null && cardUiReady
        val canTransfer = ready && openCards.size >= 2
        adapter.setTransferAvailable(openCards.size >= 2)
        if (batchModeActive) {
            setToolbarGroupVisible(openCardActions, true)
            setToolbarGroupVisible(allSaveActions, false)
            setToolbarGroupVisible(transferAllActions, false)
            setToolbarGroupVisible(createCardActions, true, 80L)
            setToolbarGroupVisible(formatCardActions, false)
            setToolbarGroupVisible(closeCardActions, ready, if (ready) 160L else 0L)
            setToolbarGroupVisible(multiExportActions, true)
            setToolbarGroupVisible(transferManyActions, canTransfer, if (canTransfer) 80L else 0L)
            setToolbarGroupVisible(multiRemoveActions, true, 100L)
            setImportButtonVisible(controlsExpanded && ready)
            return
        }
        setToolbarGroupVisible(openCardActions, true)
        setToolbarGroupVisible(allSaveActions, ready && saves.size > 1)
        setToolbarGroupVisible(transferAllActions, canTransfer && saves.size > 1, if (canTransfer) 80L else 0L)
        setToolbarGroupVisible(createCardActions, true, 80L)
        setToolbarGroupVisible(formatCardActions, ready && saves.isNotEmpty(), if (ready) 120L else 0L)
        setToolbarGroupVisible(closeCardActions, ready, if (ready) 240L else 0L)
        setToolbarGroupVisible(multiExportActions, false)
        setToolbarGroupVisible(transferManyActions, false)
        setToolbarGroupVisible(multiRemoveActions, false)
    }

    private fun scheduleCardContextActions() {
        setToolbarGroupVisible(allSaveActions, false)
        setToolbarGroupVisible(transferAllActions, false)
        setToolbarGroupVisible(formatCardActions, false)
        setToolbarGroupVisible(closeCardActions, false)
        setToolbarGroupVisible(multiExportActions, false)
        setToolbarGroupVisible(transferManyActions, false)
        setToolbarGroupVisible(multiRemoveActions, false)
        setImportButtonVisible(false)
        cardUiReady = false
        saveListExpanded = false
        if (saves.isNotEmpty()) {
            list.visibility = View.VISIBLE
            list.alpha = 0f
            listPreparingPreviews = true
        }
        val token = ++saveAnimationToken
        window.decorView.postDelayed({
            if (token != saveAnimationToken || cardFile == null) return@postDelayed
            cardUiReady = true
            MyMCSound.playFunctionTransition(this)
            refreshToolbarAvailability()
            if (controlsExpanded) setImportButtonVisible(true)
            if (controlsExpanded && ((rowPreviewsReady && !listPreparingPreviews) || saves.isEmpty())) {
                animateSaveRows(true)
            }
        }, 1000L)
    }

    private fun resetVisibleSaveRowVisuals() {
        for (index in 0 until list.childCount) {
            list.getChildAt(index)?.apply {
                animate().cancel()
                clearAnimation()
                alpha = 1f
                translationX = 0f
                translationY = 0f
                scaleX = 1f
                scaleY = 1f
                visibility = View.VISIBLE
            }
        }
    }

    private fun animateSaveRows(show: Boolean, delayMs: Long = 0L, after: (() -> Unit)? = null) {
        val token = ++saveAnimationToken
        val offset = 14f * resources.displayMetrics.density
        // Cancels both running animations and their start delays. This is
        // essential because ListView may reuse the same view for another save.
        resetVisibleSaveRowVisuals()
        val children = (0 until list.childCount).map { index ->
            val child = list.getChildAt(index)
            child to (child.getTag(R.id.press_bound_position) as? Int)
        }
        if (show) {
            list.visibility = View.VISIBLE
            list.alpha = 1f
            saveListExpanded = true
            children.forEach { (child, _) ->
                child.alpha = 0f
                child.translationY = -offset
            }
        } else {
            saveListExpanded = false
        }
        val ordered = if (show) children else children.asReversed()
        ordered.forEachIndexed { index, (child, boundPosition) ->
            val startDelay = delayMs + index * 45L
            child.animate()
                .alpha(if (show) 1f else 0f)
                .translationY(if (show) 0f else -offset)
                .setStartDelay(startDelay)
                .setInterpolator(PathInterpolator(0.2f, 0f, 0f, 1f))
                .setDuration(300L)
                .withStartAction {
                    if (
                        token != saveAnimationToken ||
                        child.getTag(R.id.press_bound_position) != boundPosition
                    ) {
                        child.animate().cancel()
                        child.alpha = 1f
                        child.translationY = 0f
                    }
                }
                .withLayer()
                .start()
        }
        val endDelay = delayMs + (ordered.size.coerceAtLeast(1) - 1) * 45L + 315L
        list.postDelayed({
            if (token != saveAnimationToken) return@postDelayed
            resetVisibleSaveRowVisuals()
            if (show) {
                list.visibility = View.VISIBLE
                list.alpha = 1f
            } else {
                list.visibility = View.INVISIBLE
            }
            after?.invoke()
        }, endDelay)
    }

    private fun confirmCloseApp() {
        showConfirmDialog(getString(R.string.confirm_close_app)) {
            clearSelectionState()
            closeApp()
        }
    }

    private fun confirmCloseCard() {
        if (cardFile == null) {
            MyMCToast.show(this, getString(R.string.no_memory_card_open))
            finishToolbarAction()
            return
        }
        showConfirmDialog(getString(R.string.confirm_close_card), onCancel = ::finishToolbarAction) {
            closeCard()
        }
    }

    private fun confirmOpenCard() {
        showConfirmDialog(
            getString(R.string.confirm_open_card),
            getString(R.string.select_memory_card_type),
            onCancel = ::finishToolbarAction
        ) {
            MyMCChoiceDialog.show(
                this,
                getString(R.string.choose_open_source_type),
                listOf(
                    getString(R.string.memory_card_file_type),
                    getString(R.string.memory_card_folder_type),
                ),
                onCancel = ::finishToolbarAction,
            ) { index ->
                when (index) {
                    0 -> chooseCard()
                    else -> chooseFolderCard(openFolderCardRequest)
                }
            }
        }
    }

    private fun confirmCreateCard() {
        showConfirmDialog(
            getString(R.string.confirm_create_card),
            getString(R.string.create_card_explanation),
            onCancel = ::finishToolbarAction
        ) {
            MyMCChoiceDialog.show(
                this,
                getString(R.string.choose_memory_card_type),
                listOf(
                    getString(R.string.memory_card_file_type),
                    getString(R.string.memory_card_folder_type),
                ),
                onCancel = ::finishToolbarAction
            ) { index ->
                if (index == 0) {
                    MyMCChoiceDialog.show(
                        this,
                        getString(R.string.choose_size),
                        listOf("8 MB", "16 MB", "32 MB", "64 MB"),
                        onCancel = ::finishToolbarAction,
                    ) { sizeIndex ->
                        pendingCardSizeMb = listOf(8, 16, 32, 64)[sizeIndex]
                        chooseCreateCard()
                    }
                } else {
                    showConfirmDialog(
                        getString(R.string.create_folder_card_title),
                        getString(R.string.create_folder_card_explanation),
                        onCancel = ::finishToolbarAction,
                    ) { chooseFolderCard(createFolderCardRequest) }
                }
            }
        }
    }

    private fun confirmDeleteAllSaves() {
        val sourceCard = cardFile
        val destinationUri = cardUri
        if (sourceCard == null || destinationUri == null) {
            MyMCToast.show(this, getString(R.string.no_memory_card_open))
            finishToolbarAction()
            return
        }
        if (saves.isEmpty()) {
            MyMCToast.show(this, getString(R.string.card_has_no_save_games))
            finishToolbarAction()
            return
        }
        showConfirmDialog(
            getString(R.string.confirm_format_card),
            getString(R.string.format_card_count, saves.size),
            onCancel = ::finishToolbarAction
        ) {
            showConfirmDialog(
                getString(R.string.final_confirmation),
                getString(R.string.cannot_undo_continue),
                onCancel = ::finishToolbarAction
            ) {
                performDeleteAllSaves(sourceCard, destinationUri)
            }
        }
    }

    private fun confirmTransferSaves(names: List<String>, mode: TransferMode) {
        startToolbarAction()
        val cleanNames = names.distinct().filter { it in saves }
        val destinations = openCards.indices.filter { it != activeCardIndex }
        if (destinations.isEmpty()) {
            MyMCToast.show(this, getString(R.string.open_card_first))
            finishToolbarAction()
            return
        }
        if (cleanNames.isEmpty()) {
            MyMCToast.show(this, getString(R.string.select_one_or_more_saves))
            finishToolbarAction()
            return
        }
        if (destinations.size == 1) {
            showTransferConfirmation(cleanNames, mode, destinations.first())
            return
        }
        MyMCChoiceDialog.show(
            this,
            getString(R.string.choose_transfer_destination),
            destinations.map { index ->
                getString(
                    R.string.transfer_destination_option,
                    index + 1,
                    openCards.size,
                    openCards[index].displayName,
                )
            },
            onCancel = ::finishToolbarAction,
        ) { selected ->
            showTransferConfirmation(cleanNames, mode, destinations[selected])
        }
    }

    private fun showTransferConfirmation(
        cleanNames: List<String>,
        mode: TransferMode,
        destinationIndex: Int,
    ) {
        val source = activeSession() ?: run {
            finishToolbarAction()
            return
        }
        val destination = openCards.getOrNull(destinationIndex) ?: run {
            finishToolbarAction()
            return
        }
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_checking_transfer_conflicts),
            destination.displayName,
        )
        ioExecutor.execute {
            try {
                val result = JSONObject(
                    mymcApi.callAttr(
                        "transfer_conflicts",
                        source.file.absolutePath,
                        destination.file.absolutePath,
                        JSONArray(cleanNames).toString(),
                    ).toString()
                )
                runOnUiThread {
                    progress.dismiss()
                    val liveSource = activeSession()
                    val liveDestination = openCards.getOrNull(destinationIndex)
                    if (
                        liveSource?.uri != source.uri || liveDestination == null ||
                        liveDestination.uri != destination.uri
                    ) {
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    if (result.optBoolean("has_conflicts", false)) {
                        val existingNames = transferConflictDestinationNames(result)
                        showConfirmDialog(
                            getString(R.string.transfer_overwrite_title),
                            getString(
                                R.string.transfer_overwrite_message,
                                destination.displayName,
                                existingNames.joinToString(", ").ifBlank {
                                    cleanNames.joinToString(", ")
                                },
                            ),
                            onCancel = ::finishToolbarAction,
                        ) {
                            performTransferSaves(cleanNames, destinationIndex, mode)
                        }
                    } else {
                        showFinalTransferConfirmation(
                            cleanNames,
                            mode,
                            destinationIndex,
                            destination.displayName,
                        )
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.transfer_check_failed),
                        error.message,
                        true,
                    )
                    finishToolbarAction()
                }
            }
        }
    }

    private fun transferConflictDestinationNames(result: JSONObject): Set<String> {
        val conflicts = result.optJSONArray("conflicts") ?: return emptySet()
        val existingNames = linkedSetOf<String>()
        for (index in 0 until conflicts.length()) {
            val names = conflicts.optJSONObject(index)
                ?.optJSONArray("destination_names") ?: continue
            for (nameIndex in 0 until names.length()) {
                names.optString(nameIndex).takeIf { it.isNotBlank() }
                    ?.let(existingNames::add)
            }
        }
        return existingNames
    }

    private fun showFinalTransferConfirmation(
        cleanNames: List<String>,
        mode: TransferMode,
        destinationIndex: Int,
        destinationName: String,
    ) {
        val title = when (mode) {
            TransferMode.ONE -> getString(R.string.confirm_transfer_game_save)
            TransferMode.MANY -> getString(R.string.confirm_transfer_save_games, cleanNames.size)
            TransferMode.ALL -> getString(R.string.confirm_transfer_all_save_games)
        }
        val message = when (mode) {
            TransferMode.ONE -> getString(
                R.string.transfer_game_save_destination,
                destinationName,
            )
            TransferMode.MANY -> getString(
                R.string.transfer_save_games_destination,
                cleanNames.size,
                destinationName,
            )
            TransferMode.ALL -> getString(
                R.string.transfer_all_destination,
                destinationName,
            )
        }
        showConfirmDialog(title, message, onCancel = ::finishToolbarAction) {
            performTransferSaves(cleanNames, destinationIndex, mode)
        }
    }

    private fun performTransferSaves(
        names: List<String>,
        destinationIndex: Int,
        mode: TransferMode,
    ) {
        val source = activeSession() ?: run { finishToolbarAction(); return }
        val destination = openCards.getOrNull(destinationIndex)
            ?: run { finishToolbarAction(); return }
        val workingCard = File(
            cacheDir,
            "transfer-card-${System.currentTimeMillis()}${if (destination.isFolder) "" else ".ps2"}",
        )
        val progress = MyMCProgressDialog.show(
            this,
            getString(
                if (mode == TransferMode.ONE) R.string.progress_transferring_game_save
                else R.string.progress_transferring_save_games
            ),
            getString(R.string.progress_processing_items, names.size),
        )
        ioExecutor.execute {
            try {
                val api = mymcApi
                val result = JSONObject(
                    api.callAttr(
                        "transfer_saves",
                        source.file.absolutePath,
                        destination.file.absolutePath,
                        JSONArray(names).toString(),
                        workingCard.absolutePath,
                    ).toString()
                )
                commitCardToUri(
                    workingCard,
                    destination.uri,
                    isFolder = destination.isFolder,
                )
                val snapshot = JSONObject(
                    api.callAttr("card_snapshot", workingCard.absolutePath).toString()
                )
                runOnUiThread {
                    progress.dismiss()
                    val liveDestination = openCards.getOrNull(destinationIndex)
                    if (liveDestination == null || liveDestination.uri != destination.uri) {
                        discardCardCache(workingCard)
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    val previous = liveDestination.file
                    liveDestination.file = workingCard
                    liveDestination.snapshot = snapshot
                    if (previous.absolutePath != workingCard.absolutePath) discardCardCache(previous)
                    if (adapter.isMultiMode()) adapter.exitMultiMode()
                    MyMCToast.show(
                        this,
                        getString(
                            R.string.save_games_transferred_count,
                            result.optInt("count", names.size),
                        ),
                        destination.displayName,
                        true,
                    )
                    MyMCSound.play(this, MyMCSound.Effect.TRANSFER)
                    finishToolbarAction()
                    val direction = if (destinationIndex > activeCardIndex) 1 else -1
                    switchToCard(destinationIndex, direction)
                }
            } catch (error: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.transfer_failed), error.message, true)
                    finishToolbarAction()
                }
            }
        }
    }

    private fun performDeleteAllSaves(sourceCard: File, destinationUri: Uri) {
        val workingCard = newWorkingCard("delete-all")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_formatting_card),
            getString(R.string.progress_updating_card_safely)
        )
        ioExecutor.execute {
            try {
                val api = mymcApi
                val result = JSONObject(api.callAttr(
                    "delete_all_saves", sourceCard.absolutePath, workingCard.absolutePath
                ).toString())
                val snapshot = JSONObject(api.callAttr(
                    "card_snapshot", workingCard.absolutePath
                ).toString())
                val remaining = snapshot.getJSONArray("saves")
                if (remaining.length() != 0) {
                    throw IllegalStateException(getString(R.string.not_all_saves_removed))
                }
                commitCardToUri(workingCard, destinationUri)
                runOnUiThread {
                    progress.dismiss()
                    replaceActiveCard(workingCard, snapshot)
                    showCardContents(remaining, updateStatus = false, previewFile = workingCard)
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    val removed = result.optInt("removed", 0)
                    MyMCToast.show(
                        this,
                        getString(R.string.card_formatted),
                        getString(R.string.save_games_removed_count, removed),
                        true
                    )
                    MyMCSound.play(this, MyMCSound.Effect.REMOVE)
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.format_card_failed), e.message, true)
                    finishToolbarAction()
                }
            }
        }
    }

    private fun deleteSelectedSave() {
        val sourceCard = cardFile
        val destinationUri = cardUri
        val save = selectedSave
        if (sourceCard == null || destinationUri == null || save == null) {
            MyMCToast.show(this, getString(R.string.select_game_save), getString(R.string.open_card_first))
            return
        }
        showConfirmDialog(getString(R.string.confirm_remove_game_save), save) {
            performDelete(save, sourceCard, destinationUri)
        }
    }

    private fun performDelete(save: String, sourceCard: File, destinationUri: Uri) {
        val workingCard = newWorkingCard("delete-card")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_removing_game_save),
            getString(R.string.progress_updating_card_safely),
        )
        ioExecutor.execute {
            try {
                val api = mymcApi
                api.callAttr("delete_save", sourceCard.absolutePath, save, workingCard.absolutePath)
                val snapshot = JSONObject(
                    api.callAttr("card_snapshot", workingCard.absolutePath).toString()
                )
                commitCardToUri(workingCard, destinationUri)
                runOnUiThread {
                    progress.dismiss()
                    replaceActiveCard(workingCard, snapshot)
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = workingCard,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    MyMCToast.show(this, getString(R.string.game_save_removed), save)
                    MyMCSound.play(this, MyMCSound.Effect.REMOVE)
                    if (expandedPreviewSaveName == save) {
                        expandedPreviewHandle?.dismiss()
                    }
                }
            } catch (e: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.remove_game_save_failed),
                        e.message,
                        true,
                    )
                }
            }
        }
    }

    private fun formatSaveDisplay(obj: org.json.JSONObject): String {
        val title = obj.optString("title", obj.optString("name", getString(R.string.game_save_default)))
        val serial = obj.optString("serial", obj.optString("name", ""))
        val region = obj.optString("region", getString(R.string.unknown))
        val flag = obj.optString("flag", "🌐")
        val sizeBytes = obj.optLong("size_bytes", obj.optLong("size", 0L))
        val sizeText = when {
            sizeBytes >= 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f MB", sizeBytes / (1024.0 * 1024.0))
            sizeBytes >= 1024L -> "${(sizeBytes + 1023L) / 1024L} KB"
            else -> "$sizeBytes B"
        }
        return "$title\n${getString(R.string.save_serial_format, serial)}\n${getString(R.string.save_region_size_format, region, flag, sizeText)}"
    }

    private fun closeApp() {
        finishAndRemoveTask()
    }

    private fun updateCardName(uri: Uri?) {
        if (uri == null) {
            cardName.text = getString(R.string.memory_card_name_none)
            return
        }
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index)
                }
            }
        } catch (_: Exception) { }
        cardName.text = getString(
            if (cardIsFolder) R.string.memory_card_name_folder else R.string.memory_card_name,
            name ?: uri.lastPathSegment ?: getString(R.string.selected_file)
        )
    }

    private fun closeCard() {
        setImportButtonVisible(false)
        cardUiReady = false
        val closingIndex = activeCardIndex
        val closingSession = activeSession() ?: run {
            finishToolbarAction()
            return
        }
        clearSelectionState()
        refreshToolbarAvailability()
        MyMCToast.show(this, getString(R.string.card_closed))
        animateSaveRows(false, 1000L) {
            if (closingIndex in openCards.indices) openCards.removeAt(closingIndex)
            discardCardCache(closingSession.file)
            if (openCards.isNotEmpty()) {
                activeCardIndex = closingIndex.coerceAtMost(openCards.lastIndex)
                syncActiveSessionAliases()
                showActiveCardSession(scheduleContext = true)
            } else {
                activeCardIndex = -1
                syncActiveSessionAliases()
                saves.clear()
                saveDisplay.clear()
                adapter.clearPreviewPayloads()
                adapter.notifyDataSetChanged()
                rowPreviewsReady = true
                listPreparingPreviews = false
                updatePermanentStatus()
                refreshToolbarAvailability()
            }
            finishToolbarAction()
        }
    }

    private fun chooseCreateCard() {
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, "MemoryCard-${pendingCardSizeMb}MB.ps2")
            addCategory(Intent.CATEGORY_OPENABLE)
        }, createCard)
    }

    private fun createCard(uri: Uri) {
        val tmp = File(cacheDir, "new-card-${System.currentTimeMillis()}.ps2")
        try {
            val api = mymcApi
            api.callAttr("create_card", tmp.absolutePath, pendingCardSizeMb)
            copyFileToUri(tmp, uri)
            val local = copyToCache(uri)
            val snapshot = JSONObject(api.callAttr("card_snapshot", local.absolutePath).toString())
            if (!registerCardSession(local, uri, false, snapshot)) return
            showCardContents(snapshot.getJSONArray("saves"), updateStatus = false, previewFile = local)
            applyCardStatus(snapshot.getJSONObject("stats"))
            scheduleCardContextActions()
            MyMCToast.show(this, getString(R.string.card_created), long = true)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.create_card_failed), e.message, true)
        } finally {
            tmp.delete()
            finishToolbarAction()
        }
    }

    private fun showFolderCardNameDialog(parentUri: Uri) {
        MyMCTextInputDialog.show(
            this,
            getString(R.string.folder_card_name_title),
            getString(R.string.folder_card_name_message),
            getString(R.string.folder_card_name_hint),
            initialText = "MemoryCard01",
            onCancel = ::finishToolbarAction,
            validate = ::validateFolderCardName,
        ) { requestedName ->
            createFolderCard(parentUri, normalizedFolderCardName(requestedName))
        }
    }

    private fun validateFolderCardName(value: String): String? {
        val trimmed = value.trim().trimEnd(' ', '.')
        if (trimmed.isBlank() || trimmed == "." || trimmed == "..") {
            return getString(R.string.folder_card_name_required)
        }
        if (trimmed.any { it < ' ' || it in "\\/:*?\"<>|" }) {
            return getString(R.string.folder_card_name_invalid_characters)
        }
        val stem = trimmed.substringBeforeLast('.').uppercase(java.util.Locale.ROOT)
        val reserved = setOf("CON", "PRN", "AUX", "NUL") +
            (1..9).flatMap { listOf("COM$it", "LPT$it") }
        if (stem in reserved) {
            return getString(R.string.folder_card_name_reserved)
        }
        return null
    }

    private fun normalizedFolderCardName(value: String): String {
        val clean = value.trim().trimEnd(' ', '.')
        return if (clean.endsWith(".ps2", ignoreCase = true)) clean else "$clean.ps2"
    }

    private fun createFolderCard(parentUri: Uri, folderName: String) {
        val localFolder = File(cacheDir, "new-folder-card-${System.currentTimeMillis()}")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_creating_folder_card),
            getString(R.string.progress_writing_safely),
        )
        ioExecutor.execute {
            var createdFolderUri: Uri? = null
            try {
                val cardFolderUri = folderCardStorage.createCardDirectory(parentUri, folderName)
                createdFolderUri = cardFolderUri
                val api = mymcApi
                api.callAttr("create_folder_card", localFolder.absolutePath)
                folderCardStorage.syncCacheToTree(
                    localFolder,
                    cardFolderUri,
                    allowEmptyDestination = true,
                )
                val snapshot = JSONObject(
                    api.callAttr("card_snapshot", localFolder.absolutePath).toString()
                )
                runOnUiThread {
                    progress.dismiss()
                    if (!registerCardSession(localFolder, cardFolderUri, true, snapshot)) {
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = localFolder,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    scheduleCardContextActions()
                    MyMCToast.show(this, getString(R.string.folder_card_created), long = true)
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                discardCardCache(localFolder)
                createdFolderUri?.let(folderCardStorage::deleteCreatedCardDirectory)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.create_card_failed),
                        error.message,
                        true,
                    )
                    finishToolbarAction()
                }
            }
        }
    }

    private fun chooseCard() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, openCard)
    }

    private fun chooseFolderCard(requestCode: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }, requestCode)
    }

    private fun loadFolderCard(uri: Uri) {
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_opening_folder_card),
            getString(R.string.progress_reading_card),
        )
        ioExecutor.execute {
            var localFolder: File? = null
            try {
                val mirroredFolder = folderCardStorage.copyTreeToCache(uri)
                localFolder = mirroredFolder
                val api = mymcApi
                if (api.callAttr("card_state", mirroredFolder.absolutePath).toString() != "valid") {
                    throw IllegalStateException(getString(R.string.selected_folder_invalid))
                }
                val snapshot = JSONObject(
                    api.callAttr("card_snapshot", mirroredFolder.absolutePath).toString()
                )
                val openedFolder = mirroredFolder
                runOnUiThread {
                    progress.dismiss()
                    if (!registerCardSession(openedFolder, uri, true, snapshot)) {
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = openedFolder,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    scheduleCardContextActions()
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                discardCardCache(localFolder)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.open_card_failed),
                        error.message,
                        true,
                    )
                    finishToolbarAction()
                }
            }
        }
    }

    private fun chooseImportSource() {
        if (cardFile == null || cardUri == null) {
            MyMCToast.show(this, getString(R.string.open_card_first))
            finishToolbarAction()
            return
        }
        MyMCChoiceDialog.show(
            this,
            getString(R.string.choose_import_source),
            listOf(
                getString(R.string.import_container_files),
                getString(R.string.folder_game_save_format),
                getString(R.string.folder_game_saves_collection),
            ),
            onCancel = ::finishToolbarAction,
        ) { index ->
            when (index) {
                0 -> choosePsu()
                1 -> chooseFolderCard(importFolderSaveRequest)
                else -> chooseFolderCard(importFolderSavesRequest)
            }
        }
    }

    private fun choosePsu() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/octet-stream", "*/*"))
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, importPsu)
    }

    private fun chooseInternalFileExport(
        saveName: String,
        fileName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, fileName, sourceUri)
        startToolbarAction()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_TITLE, fileName)
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }, exportInternalFileRequest)
    }

    private fun chooseInternalFileReplacement(
        saveName: String,
        fileName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, fileName, sourceUri)
        startToolbarAction()
        showConfirmDialog(
            getString(R.string.confirm_replace_internal_file, fileName),
            getString(R.string.replace_internal_file_warning),
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
        ) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, replaceInternalFileRequest)
        }
    }

    private fun chooseInternalFileAddition(
        saveName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, null, sourceUri)
        startToolbarAction()
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, addInternalFileRequest)
    }

    private fun requestInternalFileAdditionName(sourceFileUri: Uri) {
        val suggested = documentDisplayName(sourceFileUri).ifBlank { "NOVO_ARQUIVO.BIN" }
        MyMCTextInputDialog.show(
            this,
            getString(R.string.add_internal_file_title),
            getString(R.string.add_internal_file_message),
            getString(R.string.internal_file_name_hint),
            initialText = suggested,
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
            validate = ::validatePs2EntryName,
        ) { fileName ->
            pendingInternalFileName = fileName
            addInternalFile(sourceFileUri)
        }
    }

    private fun requestInternalFileRename(
        saveName: String,
        fileName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, fileName, sourceUri)
        startToolbarAction()
        MyMCTextInputDialog.show(
            this,
            getString(R.string.rename_internal_file_title),
            getString(R.string.rename_internal_file_message, fileName),
            getString(R.string.internal_file_name_hint),
            initialText = fileName,
            iconRes = R.drawable.ic_dialog_alert,
            confirmTextRes = R.string.confirm,
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
            validate = { value ->
                validatePs2EntryName(value)
                    ?: if (value == fileName) getString(R.string.name_unchanged) else null
            },
        ) { newName ->
            showConfirmDialog(
                getString(R.string.confirm_rename_internal_file, fileName),
                getString(R.string.rename_internal_file_warning, newName),
                onCancel = {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                },
            ) {
                renameInternalFile(newName)
            }
        }
    }

    private fun confirmInternalFileRemoval(
        saveName: String,
        fileName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, fileName, sourceUri)
        startToolbarAction()
        val warning = if (
            fileName.equals("icon.sys", ignoreCase = true) ||
            fileName.endsWith(".icn", ignoreCase = true)
        ) {
            getString(R.string.remove_internal_icon_file_warning)
        } else {
            getString(R.string.remove_internal_file_warning)
        }
        showConfirmDialog(
            getString(R.string.confirm_remove_internal_file, fileName),
            warning,
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
        ) {
            removeInternalFile()
        }
    }

    private fun requestSaveRegionChange(
        saveName: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, null, sourceUri)
        startToolbarAction()
        MyMCTextInputDialog.show(
            this,
            getString(R.string.change_save_region_title),
            getString(R.string.change_save_region_message),
            getString(R.string.change_save_region_hint),
            initialText = saveName,
            iconRes = R.drawable.ic_dialog_alert,
            confirmTextRes = R.string.confirm,
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
            validate = { value ->
                validatePs2EntryName(value)
                    ?: if (value == saveName) getString(R.string.name_unchanged) else null
            },
        ) { newSaveName ->
            showConfirmDialog(
                getString(R.string.confirm_change_save_region),
                getString(R.string.change_save_region_warning, saveName, newSaveName),
                onCancel = {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                },
            ) {
                renameSaveRegion(newSaveName)
            }
        }
    }

    private fun requestSaveDateTimeChange(
        saveName: String,
        currentDateTime: String,
        sourceUri: String,
    ) {
        setPendingInternalSource(saveName, null, sourceUri)
        startToolbarAction()
        val initialValue = currentDateTime.ifBlank {
            java.text.SimpleDateFormat(
                "dd/MM/yyyy HH:mm:ss",
                java.util.Locale.ROOT,
            ).format(java.util.Date())
        }
        MyMCTextInputDialog.show(
            this,
            getString(R.string.change_save_datetime_title),
            getString(
                R.string.change_save_datetime_message,
                Ps2TimeZone.format(Ps2TimeZone.offsetMinutes(this)),
            ),
            getString(R.string.change_save_datetime_hint),
            initialText = initialValue,
            iconRes = R.drawable.ic_dialog_alert,
            confirmTextRes = R.string.confirm,
            onCancel = {
                clearPendingInternalFileAction()
                finishToolbarAction()
            },
            validate = ::validateSaveDateTime,
        ) { newDateTime ->
            showConfirmDialog(
                getString(R.string.confirm_change_save_datetime),
                getString(R.string.change_save_datetime_warning, newDateTime),
                onCancel = {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                },
            ) {
                changeSaveDateTime(newDateTime)
            }
        }
    }

    private fun parseSaveDateTime(value: String): IntArray? {
        if (!Regex("^\\d{2}/\\d{2}/\\d{4} \\d{2}:\\d{2}:\\d{2}$").matches(value)) {
            return null
        }
        val parser = java.text.SimpleDateFormat(
            "dd/MM/yyyy HH:mm:ss",
            java.util.Locale.ROOT,
        ).apply {
            isLenient = false
            timeZone = java.util.TimeZone.getTimeZone("UTC")
        }
        val parsed = try {
            parser.parse(value)
        } catch (_: Exception) {
            null
        } ?: return null
        val calendar = java.util.Calendar
            .getInstance(java.util.TimeZone.getTimeZone("UTC"))
            .apply { time = parsed }
        val year = calendar.get(java.util.Calendar.YEAR)
        if (year !in 2000..2099) return null
        return intArrayOf(
            year,
            calendar.get(java.util.Calendar.MONTH) + 1,
            calendar.get(java.util.Calendar.DAY_OF_MONTH),
            calendar.get(java.util.Calendar.HOUR_OF_DAY),
            calendar.get(java.util.Calendar.MINUTE),
            calendar.get(java.util.Calendar.SECOND),
        )
    }

    private fun validateSaveDateTime(value: String): String? =
        if (parseSaveDateTime(value) == null) {
            getString(R.string.save_datetime_invalid)
        } else {
            null
        }

    private fun validatePs2EntryName(value: String): String? {
        if (value.isBlank() || value == "." || value == "..") {
            return getString(R.string.internal_file_name_required)
        }
        if (value.startsWith("_pcsx2_", ignoreCase = true)) {
            return getString(R.string.internal_file_name_reserved)
        }
        if (value.any { it.code < 32 || it in "?*/\\" }) {
            return getString(R.string.internal_file_name_invalid)
        }
        val charset = java.nio.charset.Charset.forName("Shift_JIS")
        if (!charset.newEncoder().canEncode(value)) {
            return getString(R.string.internal_file_name_unsupported)
        }
        if (value.toByteArray(charset).size > 31) {
            return getString(R.string.internal_file_name_too_long)
        }
        return null
    }

    private fun documentDisplayName(uri: Uri): String = try {
        contentResolver.query(
            uri,
            arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null,
        )?.use { cursor ->
            if (!cursor.moveToFirst()) return@use ""
            val index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (index >= 0) cursor.getString(index).orEmpty() else ""
        }.orEmpty()
    } catch (_: Exception) {
        ""
    }

    private fun setPendingInternalSource(
        saveName: String,
        fileName: String?,
        sourceUri: String,
    ) {
        pendingInternalSaveName = saveName
        pendingInternalFileName = fileName
        pendingInternalCardUri = sourceUri
    }

    private fun clearPendingInternalFileAction() {
        pendingInternalSaveName = null
        pendingInternalFileName = null
        pendingInternalCardUri = null
    }

    private fun pendingInternalFileSource(): OpenCardSession? {
        val uri = pendingInternalCardUri ?: return null
        return openCards.firstOrNull { it.uri.toString() == uri }
    }

    private fun applyInternalSaveMutation(
        source: OpenCardSession,
        workingPrefix: String,
        progressTitle: String,
        progressMessage: String,
        successTitle: String,
        successMessage: (String) -> String?,
        failureTitle: String,
        effect: MyMCSound.Effect,
        cleanup: (() -> Unit)? = null,
        mutation: (File) -> String,
    ) {
        val originalPreviewSaveName = pendingInternalSaveName
        val workingCard = File(
            cacheDir,
            "$workingPrefix-${System.currentTimeMillis()}${if (source.isFolder) "" else ".ps2"}",
        )
        val progress = MyMCProgressDialog.show(this, progressTitle, progressMessage)
        ioExecutor.execute {
            try {
                val result = mutation(workingCard)
                commitCardToUri(workingCard, source.uri, isFolder = source.isFolder)
                val snapshot = JSONObject(
                    mymcApi.callAttr("card_snapshot", workingCard.absolutePath).toString()
                )
                runOnUiThread {
                    progress.dismiss()
                    val sessionIndex = openCards.indexOfFirst {
                        it.uri.toString() == source.uri.toString()
                    }
                    val liveSession = openCards.getOrNull(sessionIndex)
                    if (liveSession == null) {
                        discardCardCache(workingCard)
                        clearPendingInternalFileAction()
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    val previous = liveSession.file
                    liveSession.file = workingCard
                    liveSession.snapshot = snapshot
                    if (previous.absolutePath != workingCard.absolutePath) {
                        discardCardCache(previous)
                    }
                    if (sessionIndex == activeCardIndex) {
                        syncActiveSessionAliases()
                        showCardContents(
                            snapshot.getJSONArray("saves"),
                            updateStatus = false,
                            previewFile = workingCard,
                        )
                        applyCardStatus(snapshot.getJSONObject("stats"))
                    }
                    MyMCToast.show(this, successTitle, successMessage(result), long = true)
                    MyMCSound.play(this, effect)
                    val refreshedSaveName = try {
                        JSONObject(result).optString("save_name").ifBlank {
                            originalPreviewSaveName.orEmpty()
                        }
                    } catch (_: Exception) {
                        originalPreviewSaveName.orEmpty()
                    }
                    if (refreshedSaveName.isNotBlank()) {
                        refreshExpandedPreview(source.uri.toString(), refreshedSaveName)
                    }
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        failureTitle,
                        internalEditorErrorMessage(error),
                        true,
                    )
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } finally {
                cleanup?.invoke()
            }
        }
    }

    private fun internalEditorErrorMessage(error: Exception): String {
        val message = error.message.orEmpty()
        return when {
            "INTERNAL_FILE_EXISTS" in message -> getString(R.string.internal_file_already_exists)
            "SAVE_NAME_EXISTS" in message -> getString(R.string.save_id_already_exists)
            "LAST_INTERNAL_FILE" in message -> getString(R.string.cannot_remove_last_internal_file)
            "RESERVED_PS2_NAME" in message -> getString(R.string.internal_file_name_reserved)
            "UNSUPPORTED_PS2_NAME" in message -> getString(R.string.internal_file_name_unsupported)
            "PS2_NAME_TOO_LONG" in message -> getString(R.string.internal_file_name_too_long)
            "INVALID_PS2_NAME" in message -> getString(R.string.internal_file_name_invalid)
            "SAVE_DATE_YEAR_RANGE" in message -> getString(R.string.save_datetime_invalid)
            "INVALID_SAVE_DATETIME" in message -> getString(R.string.save_datetime_invalid)
            else -> error.message ?: getString(R.string.unknown)
        }
    }

    private fun addInternalFile(sourceFileUri: Uri) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val fileName = pendingInternalFileName
        if (source == null || saveName == null || fileName == null) {
            MyMCToast.show(this, getString(R.string.internal_file_add_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val input = File(cacheDir, "internal-addition-${System.currentTimeMillis()}")
        val cardSource = source
        applyInternalSaveMutation(
            cardSource,
            "add-internal-file",
            getString(R.string.progress_adding_internal_file),
            fileName,
            getString(R.string.internal_file_added),
            { fileName },
            getString(R.string.internal_file_add_failed),
            MyMCSound.Effect.IMPORT,
            cleanup = { input.delete() },
        ) { workingCard ->
            contentResolver.openInputStream(sourceFileUri).use { rawInput ->
                BufferedInputStream(requireNotNull(rawInput), 256 * 1024).use { stream ->
                    BufferedOutputStream(input.outputStream(), 256 * 1024).use { output ->
                        stream.copyTo(output, 256 * 1024)
                    }
                }
            }
            mymcApi.callAttr(
                "add_save_file",
                cardSource.file.absolutePath,
                saveName,
                input.absolutePath,
                fileName,
                workingCard.absolutePath,
            ).toString()
        }
    }

    private fun renameInternalFile(newName: String) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val oldName = pendingInternalFileName
        if (source == null || saveName == null || oldName == null) {
            MyMCToast.show(this, getString(R.string.internal_file_rename_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val cardSource = source
        applyInternalSaveMutation(
            cardSource,
            "rename-internal-file",
            getString(R.string.progress_renaming_internal_file),
            getString(R.string.progress_processing_internal_file),
            getString(R.string.internal_file_renamed),
            { newName },
            getString(R.string.internal_file_rename_failed),
            MyMCSound.Effect.CONFIRM,
        ) { workingCard ->
            mymcApi.callAttr(
                "rename_save_file",
                cardSource.file.absolutePath,
                saveName,
                oldName,
                newName,
                workingCard.absolutePath,
            ).toString()
        }
    }

    private fun removeInternalFile() {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val fileName = pendingInternalFileName
        if (source == null || saveName == null || fileName == null) {
            MyMCToast.show(this, getString(R.string.internal_file_remove_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val cardSource = source
        applyInternalSaveMutation(
            cardSource,
            "remove-internal-file",
            getString(R.string.progress_removing_internal_file),
            getString(R.string.progress_processing_internal_file),
            getString(R.string.internal_file_removed),
            { fileName },
            getString(R.string.internal_file_remove_failed),
            MyMCSound.Effect.REMOVE,
        ) { workingCard ->
            mymcApi.callAttr(
                "delete_save_file",
                cardSource.file.absolutePath,
                saveName,
                fileName,
                workingCard.absolutePath,
            ).toString()
        }
    }

    private fun renameSaveRegion(newSaveName: String) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        if (source == null || saveName == null) {
            MyMCToast.show(this, getString(R.string.save_region_change_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val cardSource = source
        applyInternalSaveMutation(
            cardSource,
            "change-save-region",
            getString(R.string.progress_changing_save_region),
            getString(R.string.progress_processing_internal_file),
            getString(R.string.save_region_changed),
            { result ->
                val data = JSONObject(result)
                val region = data.optString("region", getString(R.string.unknown))
                getString(R.string.save_region_changed_detail, newSaveName, region)
            },
            getString(R.string.save_region_change_failed),
            MyMCSound.Effect.CONFIRM,
        ) { workingCard ->
            mymcApi.callAttr(
                "rename_save_root",
                cardSource.file.absolutePath,
                saveName,
                newSaveName,
                workingCard.absolutePath,
            ).toString()
        }
    }

    private fun changeSaveDateTime(newDateTime: String) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val fields = parseSaveDateTime(newDateTime)
        if (source == null || saveName == null || fields == null) {
            MyMCToast.show(this, getString(R.string.save_datetime_change_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val cardSource = source
        applyInternalSaveMutation(
            cardSource,
            "change-save-datetime",
            getString(R.string.progress_changing_save_datetime),
            getString(R.string.progress_processing_internal_file),
            getString(R.string.save_datetime_changed),
            { result ->
                JSONObject(result)
                    .optJSONObject("modified")
                    ?.optString("display", newDateTime)
                    ?: newDateTime
            },
            getString(R.string.save_datetime_change_failed),
            MyMCSound.Effect.CONFIRM,
        ) { workingCard ->
            mymcApi.callAttr(
                "change_save_datetime",
                cardSource.file.absolutePath,
                saveName,
                fields[0],
                fields[1],
                fields[2],
                fields[3],
                fields[4],
                fields[5],
                Ps2TimeZone.offsetMinutes(this),
                workingCard.absolutePath,
            ).toString()
        }
    }

    private fun exportInternalFile(destinationUri: Uri) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val fileName = pendingInternalFileName
        val sourceFile = source?.file
        if (sourceFile == null || saveName == null || fileName == null) {
            MyMCToast.show(this, getString(R.string.internal_file_export_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val temp = File(cacheDir, "internal-export-${System.currentTimeMillis()}")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_exporting_internal_file),
            fileName,
        )
        ioExecutor.execute {
            try {
                val bytes = mymcApi
                    .callAttr(
                        "read_save_file",
                        sourceFile.absolutePath,
                        saveName,
                        fileName,
                    ).toJava(ByteArray::class.java)
                BufferedOutputStream(temp.outputStream(), 256 * 1024).use { output ->
                    output.write(bytes)
                }
                copyFileToUri(temp, destinationUri)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.internal_file_exported), fileName)
                    MyMCSound.play(this, MyMCSound.Effect.EXPORT)
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.internal_file_export_failed),
                        error.message,
                        true,
                    )
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } finally {
                temp.delete()
            }
        }
    }

    private fun replaceInternalFile(replacementUri: Uri) {
        val source = pendingInternalFileSource()
        val saveName = pendingInternalSaveName
        val fileName = pendingInternalFileName
        if (source == null || saveName == null || fileName == null) {
            MyMCToast.show(this, getString(R.string.internal_file_replace_failed))
            clearPendingInternalFileAction()
            finishToolbarAction()
            return
        }
        val replacement = File(cacheDir, "internal-replacement-${System.currentTimeMillis()}")
        val cardSource = source
        val workingCard = File(
            cacheDir,
            "replace-internal-file-${System.currentTimeMillis()}${if (cardSource.isFolder) "" else ".ps2"}",
        )
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_replacing_internal_file),
            getString(R.string.progress_processing_internal_file),
        )
        ioExecutor.execute {
            try {
                contentResolver.openInputStream(replacementUri).use { rawInput ->
                    BufferedInputStream(requireNotNull(rawInput), 256 * 1024).use { input ->
                        BufferedOutputStream(replacement.outputStream(), 256 * 1024).use { output ->
                            input.copyTo(output, 256 * 1024)
                        }
                    }
                }
                val api = mymcApi
                api.callAttr(
                    "replace_save_file",
                    cardSource.file.absolutePath,
                    saveName,
                    fileName,
                    replacement.absolutePath,
                    workingCard.absolutePath,
                )
                commitCardToUri(
                    workingCard,
                    cardSource.uri,
                    isFolder = cardSource.isFolder,
                )
                val snapshot = JSONObject(
                    api.callAttr("card_snapshot", workingCard.absolutePath).toString()
                )
                runOnUiThread {
                    progress.dismiss()
                    val sessionIndex = openCards.indexOfFirst {
                        it.uri.toString() == cardSource.uri.toString()
                    }
                    val liveSession = openCards.getOrNull(sessionIndex)
                    if (liveSession == null) {
                        discardCardCache(workingCard)
                        clearPendingInternalFileAction()
                        finishToolbarAction()
                        return@runOnUiThread
                    }
                    val previous = liveSession.file
                    liveSession.file = workingCard
                    liveSession.snapshot = snapshot
                    if (previous.absolutePath != workingCard.absolutePath) {
                        discardCardCache(previous)
                    }
                    if (sessionIndex == activeCardIndex) {
                        syncActiveSessionAliases()
                        showCardContents(
                            snapshot.getJSONArray("saves"),
                            updateStatus = false,
                            previewFile = workingCard,
                        )
                        applyCardStatus(snapshot.getJSONObject("stats"))
                    }
                    MyMCToast.show(this, getString(R.string.internal_file_replaced), fileName)
                    MyMCSound.play(this, MyMCSound.Effect.CONFIRM)
                    refreshExpandedPreview(cardSource.uri.toString(), saveName)
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.internal_file_replace_failed),
                        error.message,
                        true,
                    )
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            } finally {
                replacement.delete()
            }
        }
    }

    private fun showExportFormatChoice(
        onCancel: (() -> Unit)? = null,
        onChoose: (String) -> Unit
    ) {
        val labels = listOf(
            "PSU", "MAX", "CBS", "SPS", "XPS",
            getString(R.string.folder_game_save_format),
        )
        val formats = listOf("psu", "max", "cbs", "sps", "xps", "folder")
        MyMCChoiceDialog.show(
            this,
            getString(R.string.choose_export_format),
            labels,
            onCancel = onCancel
        ) { index ->
            onChoose(formats[index])
        }
    }

    private fun chooseExportTarget(format: String) {
        val sourceCard = cardFile
        val save = selectedSave
        if (sourceCard == null || save == null) {
            MyMCToast.show(this, getString(R.string.select_game_save), getString(R.string.open_card_first)); return
        }
        chooseExportTargetFor(sourceCard, save, format)
    }

    private fun chooseExportTargetFor(sourceCard: File, save: String, format: String) {
        pendingSingleExportCard = sourceCard
        pendingSingleExportSave = save
        pendingExportFormat = format
        if (format == "folder") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                )
            }, exportFolderSaveRequest)
            return
        }
        try {
            val api = mymcApi
            val arr = JSONArray(api.callAttr("list_saves", sourceCard.absolutePath).toString())
            var title = save
            var serial = save
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                if (obj.getString("name") == save) {
                    title = obj.optString("title", save)
                    serial = obj.optString("serial", save)
                    break
                }
            }
            val safeTitle = title.replace(Regex("[\\/:*?\"<>|\r\n]"), "_").replace(Regex("\\s+"), " ").trim().ifEmpty { save }
            val safeSerial = serial.replace(Regex("[\\/:*?\"<>|]"), "_").trim()
            val exportName = if (safeSerial.isNotEmpty() && safeSerial != safeTitle) "$safeTitle - $safeSerial" else safeTitle
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                type = "application/octet-stream"
                putExtra(Intent.EXTRA_TITLE, "$exportName.${format.uppercase(java.util.Locale.ROOT)}")
                addCategory(Intent.CATEGORY_OPENABLE)
            }, exportPsu)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.prepare_export_failed), e.message, true)
        }
    }

    private fun chooseMultiExportFolder(format: String) {
        if (selectedMultiSaveNames().isEmpty()) {
            MyMCToast.show(this, getString(R.string.select_one_or_more_saves))
            finishToolbarAction()
            return
        }
        pendingExportAll = false
        pendingExportFormat = format
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }, exportMany)
    }

    private fun chooseAllExportFolder(format: String) {
        if (cardFile == null || saves.size <= 1) {
            MyMCToast.show(this, getString(R.string.export_all_requires_two))
            finishToolbarAction()
            return
        }
        pendingExportAll = true
        pendingExportFormat = format
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }, exportMany)
    }

    private fun exportSelectedSaves(treeUri: Uri) {
        val sourceCard = cardFile ?: run { finishToolbarAction(); return }
        val exportingAll = pendingExportAll
        val names = if (exportingAll) saves.toList() else selectedMultiSaveNames()
        val format = pendingExportFormat
        if (names.isEmpty()) {
            finishToolbarAction()
            return
        }
        val progress = MyMCProgressDialog.show(
            this,
            getString(
                if (exportingAll) R.string.progress_exporting_all_save_games
                else R.string.progress_exporting_save_games
            ),
            getString(R.string.progress_processing_items, names.size)
        )
        ioExecutor.execute {
            var exported = 0
            try {
                val api = mymcApi
                val parent = DocumentsContract.buildDocumentUriUsingTree(
                    treeUri, DocumentsContract.getTreeDocumentId(treeUri)
                )
                val metadata = JSONArray(api.callAttr("list_saves", sourceCard.absolutePath).toString())
                val labels = mutableMapOf<String, String>()
                for (i in 0 until metadata.length()) {
                    val obj = metadata.getJSONObject(i)
                    val title = obj.optString("title", obj.optString("name", getString(R.string.game_save_default))).trim()
                    val serial = obj.optString("serial", "").trim()
                    labels[obj.optString("name")] =
                        if (serial.isNotEmpty() && title != serial) "$title - $serial" else title
                }
                val extension = format.uppercase(java.util.Locale.ROOT)
                names.forEachIndexed { index, name ->
                    val safeName = labels[name].orEmpty().replace(Regex("[\\/:*?\"<>|\\r\\n]"), "_").trim()
                        .ifEmpty { "GameSave-${index + 1}" }
                    if (format == "folder") {
                        val temp = File(
                            cacheDir,
                            "multi-folder-export-${System.currentTimeMillis()}-$index",
                        )
                        try {
                            val result = JSONObject(api.callAttr(
                                "export_save_folder",
                                sourceCard.absolutePath,
                                name,
                                temp.absolutePath,
                            ).toString())
                            folderCardStorage.exportDirectoryToTree(
                                temp,
                                treeUri,
                                result.optString("folder_name", safeName),
                            )
                            exported++
                        } finally {
                            discardCardCache(temp)
                        }
                    } else {
                        val temp = File(cacheDir, "multi-export-${System.currentTimeMillis()}-$index.$format")
                        try {
                            api.callAttr("export_save_any", sourceCard.absolutePath, name, temp.absolutePath, format)
                            val destination = DocumentsContract.createDocument(
                                contentResolver, parent, "application/octet-stream", "$safeName.$extension"
                            ) ?: throw IllegalStateException(
                                getString(R.string.cannot_create_file, "$safeName.$extension")
                            )
                            copyFileToUri(temp, destination)
                            exported++
                        } finally {
                            temp.delete()
                        }
                    }
                }
                runOnUiThread {
                    progress.dismiss()
                    if (!exportingAll) adapter.exitMultiMode()
                    MyMCToast.show(this, getString(R.string.save_games_exported_count, exported), long = true)
                    MyMCSound.play(this, MyMCSound.Effect.EXPORT)
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(
                            if (exportingAll) R.string.all_export_failed
                            else R.string.multi_export_failed
                        ),
                        e.message,
                        true
                    )
                    finishToolbarAction()
                }
            }
        }
    }

    private fun confirmDeleteSelectedSaves() {
        val names = selectedMultiSaveNames()
        if (names.isEmpty()) {
            MyMCToast.show(this, getString(R.string.select_one_or_more_saves))
            finishToolbarAction()
            return
        }
        showConfirmDialog(
            getString(R.string.confirm_remove_save_games, names.size),
            getString(R.string.selected_items_removed_permanently),
            onCancel = ::finishToolbarAction
        ) { performDeleteSelectedSaves(names) }
    }

    private fun performDeleteSelectedSaves(names: List<String>) {
        val sourceCard = cardFile ?: run { finishToolbarAction(); return }
        val destinationUri = cardUri ?: run { finishToolbarAction(); return }
        val workingCard = newWorkingCard("delete-many")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_removing_save_games),
            getString(R.string.progress_updating_card_safely)
        )
        ioExecutor.execute {
            try {
                val api = mymcApi
                val result = JSONObject(api.callAttr(
                    "delete_saves", sourceCard.absolutePath, JSONArray(names).toString(), workingCard.absolutePath
                ).toString())
                commitCardToUri(workingCard, destinationUri)
                val snapshot = JSONObject(api.callAttr("card_snapshot", workingCard.absolutePath).toString())
                runOnUiThread {
                    progress.dismiss()
                    replaceActiveCard(workingCard, snapshot)
                    adapter.exitMultiMode()
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = workingCard,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    MyMCToast.show(
                        this,
                        getString(R.string.save_games_removed_count, result.optInt("count", 0)),
                        long = true
                    )
                    MyMCSound.play(this, MyMCSound.Effect.REMOVE)
                    finishToolbarAction()
                }
            } catch (e: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.remove_save_games_failed), e.message, true)
                    finishToolbarAction()
                }
            }
        }
    }

    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        if (result != RESULT_OK || data == null) {
            if (
                request == exportInternalFileRequest ||
                request == replaceInternalFileRequest ||
                request == addInternalFileRequest
            ) {
                clearPendingInternalFileAction()
            }
            finishToolbarAction()
            return
        }
        val uri = data.data
        when (request) {
            openCard -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                } catch (_: Exception) { }
                loadCard(uri)
                finishToolbarAction()
            }
            openFolderCardRequest -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) { }
                loadFolderCard(uri)
            }
            exportPsu -> uri?.let { export(it) }
            exportFolderSaveRequest -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) { }
                exportFolderSave(uri)
            }
            importPsu -> {
                val selected = mutableListOf<Uri>()
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) selected += clip.getItemAt(i).uri
                }
                uri?.let { if (it !in selected) selected += it }
                startBatchImport(selected)
            }
            importFolderSaveRequest -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                } catch (_: Exception) { }
                importFolderSave(uri)
            }
            importFolderSavesRequest -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                } catch (_: Exception) { }
                importFolderSaveCollection(uri)
            }
            createCard -> if (uri != null) createCard(uri) else finishToolbarAction()
            createFolderCardRequest -> {
                if (uri == null) {
                    finishToolbarAction()
                    return
                }
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) { }
                showFolderCardNameDialog(uri)
            }
            exportMany -> if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) { }
                exportSelectedSaves(uri)
            } else finishToolbarAction()
            exportInternalFileRequest -> {
                if (uri != null) exportInternalFile(uri) else {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            }
            replaceInternalFileRequest -> {
                if (uri != null) replaceInternalFile(uri) else {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            }
            addInternalFileRequest -> {
                if (uri != null) requestInternalFileAdditionName(uri) else {
                    clearPendingInternalFileAction()
                    finishToolbarAction()
                }
            }
        }
    }

    private fun startBatchImport(uris: List<Uri>) {
        if (uris.isEmpty()) {
            finishToolbarAction()
            return
        }
        pendingImports.clear()
        pendingImports.addAll(uris)
        processNextImport()
    }

    private fun processNextImport() {
        if (pendingImports.isEmpty()) {
            finishToolbarAction()
            return
        }
        val next = pendingImports.removeFirst()
        importPsu(next) { processNextImport() }
    }

    private fun copyToCache(uri: Uri): File {
        val out = File(cacheDir, "card-${System.currentTimeMillis()}.ps2")
        contentResolver.openInputStream(uri).use { rawInput ->
            val input = BufferedInputStream(requireNotNull(rawInput), 256 * 1024)
            BufferedOutputStream(out.outputStream(), 256 * 1024).use { output ->
                input.copyTo(output, 256 * 1024)
            }
        }
        return out
    }

    private fun newWorkingCard(prefix: String): File = File(
        cacheDir,
        "$prefix-${System.currentTimeMillis()}${if (cardIsFolder) "" else ".ps2"}",
    )

    private fun commitCardToUri(
        localCard: File,
        uri: Uri,
        allowEmptyFolder: Boolean = false,
        isFolder: Boolean = cardIsFolder,
    ) {
        if (isFolder) {
            folderCardStorage.syncCacheToTree(localCard, uri, allowEmptyFolder)
        } else {
            copyFileToUri(localCard, uri)
        }
    }

    private fun discardCardCache(file: File?) {
        if (file == null || !file.exists()) return
        if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    private fun copyFileToUri(file: File, uri: Uri) {
        contentResolver.openOutputStream(uri, "wt").use { rawOutput ->
            BufferedOutputStream(requireNotNull(rawOutput), 256 * 1024).use { output ->
                BufferedInputStream(file.inputStream(), 256 * 1024).use { input ->
                    input.copyTo(output, 256 * 1024)
                }
                output.flush()
            }
        }
        verifyWrittenUriSize(file, uri)
    }

    private fun verifyWrittenUriSize(source: File, uri: Uri) {
        try {
            contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                val writtenSize = descriptor.statSize
                if (writtenSize >= 0L && writtenSize != source.length()) {
                    throw IllegalStateException(
                        getString(R.string.incomplete_file, source.length(), writtenSize)
                    )
                }
            }
        } catch (e: IllegalStateException) {
            throw e
        } catch (_: Exception) {
            // Some document providers don't expose statSize. The closed and
            // flushed buffered stream remains the authoritative write result.
        }
    }

    private fun loadCard(uri: Uri) {
        try {
            val file = copyToCache(uri)
            val api = mymcApi
            val state = api.callAttr("card_state", file.absolutePath).toString()

            when (state) {
                "valid" -> {
                    cardUiReady = false
                    val snapshot = JSONObject(api.callAttr("card_snapshot", file.absolutePath).toString())
                    if (!registerCardSession(file, uri, false, snapshot)) return
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = file,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    scheduleCardContextActions()
                }
                "blank" -> {
                    showConfirmDialog(
                        getString(R.string.card_unformatted),
                        getString(R.string.confirm_format_unformatted)
                    ) {
                        formatBlankCard(uri, file)
                    }
                }
                else -> {
                    discardCardCache(file)
                    MyMCToast.show(
                        this,
                        getString(R.string.card_invalid),
                        getString(R.string.selected_file_invalid),
                        true
                    )
                }
            }
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.open_card_failed), e.message, true)
        }
    }

    private fun formatBlankCard(uri: Uri, sourceFile: File) {
        val formatted = File(cacheDir, "formatted-card-${System.currentTimeMillis()}.ps2")
        try {
            val api = mymcApi
            api.callAttr("format_blank_card", sourceFile.absolutePath, formatted.absolutePath)
            api.callAttr("list_saves", formatted.absolutePath)
            copyFileToUri(formatted, uri)

            val local = copyToCache(uri)
            val snapshot = JSONObject(api.callAttr("card_snapshot", local.absolutePath).toString())
            if (!registerCardSession(local, uri, false, snapshot)) return
            showCardContents(snapshot.getJSONArray("saves"), updateStatus = false, previewFile = local)
            applyCardStatus(snapshot.getJSONObject("stats"))
            scheduleCardContextActions()
            MyMCToast.show(this, getString(R.string.card_formatted), long = true)
            MyMCSound.play(this, MyMCSound.Effect.REMOVE)
        } catch (e: Exception) {
            MyMCToast.show(this, getString(R.string.format_card_failed), e.message, true)
        } finally {
            sourceFile.delete()
            formatted.delete()
        }
    }

    private fun showCardContents(api: com.chaquo.python.PyObject, file: File) {
        val result = api.callAttr("list_saves", file.absolutePath).toString()
        showCardContents(JSONArray(result), previewFile = file)
    }

    private fun showCardContents(arr: JSONArray, updateStatus: Boolean = true, previewFile: File? = cardFile) {
        // A previous close/transfer/remove animation may still target recycled
        // rows. Invalidate it before replacing the adapter data.
        saveAnimationToken++
        resetVisibleSaveRowVisuals()
        list.animate().cancel()
        list.clearAnimation()
        list.translationY = 0f
        cardMenuButton.setImageResource(R.drawable.ic_memory_card)
        if (adapter.isMultiMode()) adapter.exitMultiMode()
        saves.clear()
        saveDisplay.clear()
        val ordered = (0 until arr.length())
            .map { arr.getJSONObject(it) }
            .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) {
                it.optString("title", it.optString("name", ""))
            })
        for (obj in ordered) {
            saves += obj.getString("name")
            saveDisplay += formatSaveDisplay(obj)
        }
        adapter.selectedPosition = -1
        adapter.clearPreviewPayloads()
        adapter.notifyDataSetChanged()
        selectedSave = null
        list.clearChoices()
        rowPreviewsReady = saves.isEmpty()
        if (saves.isNotEmpty()) {
            saveListExpanded = false
            listPreparingPreviews = true
            list.visibility = View.VISIBLE
            list.alpha = 0f
        } else {
            listPreparingPreviews = false
            list.alpha = 1f
        }
        if (updateStatus) updatePermanentStatus()
        refreshToolbarAvailability()
        if (previewFile != null) {
            loadRowPreviews(previewFile, saves.toList())
        } else if (cardUiReady && saves.isEmpty()) {
            animateSaveRows(true)
        }
    }

    private fun loadRowPreviews(file: File, names: List<String>) {
        val loadToken = ++previewLoadToken
        if (names.isEmpty()) {
            rowPreviewsReady = true
            listPreparingPreviews = false
            if (cardUiReady && controlsExpanded && !saveListExpanded) animateSaveRows(true)
            return
        }
        val expectedPath = file.absolutePath
        ioExecutor.execute {
            val payloads = linkedMapOf<String, String>()
            val snapshots = linkedMapOf<String, android.graphics.Bitmap>()
            try {
                val api = mymcApi
                names.chunked(8).forEach { batch ->
                    var result: JSONObject? = null
                    for (attempt in 0..2) {
                        try {
                            result = JSONObject(api.callAttr(
                                "get_icon_payloads", expectedPath, JSONArray(batch).toString()
                            ).toString())
                            break
                        } catch (_: Exception) {
                            if (attempt == 2) result = null
                        }
                    }
                    batch.forEach { name ->
                        var payload = result?.optJSONObject(name)
                        if (payload?.optBoolean("ok", false) != true) {
                            for (attempt in 0..1) {
                                try {
                                    val retry = JSONObject(api.callAttr(
                                        "get_icon_payload", expectedPath, name
                                    ).toString())
                                    payload = retry
                                    if (retry.optBoolean("ok", false)) break
                                } catch (_: Exception) { }
                            }
                        }
                        payload?.let {
                            val json = it.toString()
                            payloads[name] = json
                            snapshots[name] = Ps2IconSnapshotRenderer.render(json)
                        }
                    }
                }
            } catch (_: Exception) {
                // A missing or invalid icon must not affect save management.
            } finally {
                runOnUiThread {
                    if (loadToken != previewLoadToken || cardFile?.absolutePath != expectedPath) {
                        return@runOnUiThread
                    }
                    adapter.setPreviewPayloads(payloads, snapshots)
                    rowPreviewsReady = true
                    list.postDelayed({
                        if (
                            loadToken != previewLoadToken ||
                            cardFile?.absolutePath != expectedPath
                        ) return@postDelayed
                        listPreparingPreviews = false
                        if (cardUiReady && controlsExpanded && !saveListExpanded) animateSaveRows(true)
                    }, 40L)
                }
            }
        }
    }

    private fun importFolderSave(folderUri: Uri) {
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_importing_folder_game_save),
            getString(R.string.progress_reading_folder_game_save),
        )
        ioExecutor.execute {
            try {
                val mirroredFolder = folderCardStorage.copySaveFolderToCache(folderUri)
                val cleanupRoot = mirroredFolder.parentFile ?: mirroredFolder
                runOnUiThread {
                    progress.dismiss()
                    importCachedFolderSave(mirroredFolder) {
                        ioExecutor.execute { discardCardCache(cleanupRoot) }
                        finishToolbarAction()
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(error)
                    finishToolbarAction()
                }
            }
        }
    }

    private fun importFolderSaveCollection(parentUri: Uri) {
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_preparing_folder_batch),
            getString(R.string.progress_finding_folder_game_saves),
        )
        ioExecutor.execute {
            var localRoot: File? = null
            try {
                val mirroredRoot = folderCardStorage.copyTreeToCache(parentUri)
                localRoot = mirroredRoot
                val folders = mirroredRoot.listFiles()
                    .orEmpty()
                    .filter { candidate ->
                        candidate.isDirectory &&
                            !candidate.name.startsWith("_pcsx2_") &&
                            candidate.listFiles().orEmpty().any { child ->
                                child.isFile && !child.name.startsWith("_pcsx2_")
                            }
                    }
                    .sortedBy { it.name.lowercase(java.util.Locale.ROOT) }
                if (folders.isEmpty()) {
                    throw IllegalArgumentException(
                        getString(R.string.no_folder_game_saves_found)
                    )
                }
                runOnUiThread {
                    progress.dismiss()
                    pendingFolderImports.clear()
                    pendingFolderImports.addAll(folders)
                    pendingFolderImportRoot = mirroredRoot
                    processNextFolderImport()
                }
            } catch (error: Exception) {
                discardCardCache(localRoot)
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(error)
                    finishToolbarAction()
                }
            }
        }
    }

    private fun processNextFolderImport() {
        if (pendingFolderImports.isEmpty()) {
            val completedRoot = pendingFolderImportRoot
            pendingFolderImportRoot = null
            completedRoot?.let { root ->
                ioExecutor.execute { discardCardCache(root) }
            }
            finishToolbarAction()
            return
        }
        importCachedFolderSave(pendingFolderImports.removeFirst()) {
            processNextFolderImport()
        }
    }

    private fun importCachedFolderSave(folder: File, onFinished: () -> Unit) {
        val sourceCard = cardFile ?: run { onFinished(); return }
        val destinationUri = cardUri ?: run { onFinished(); return }
        val workingCard = newWorkingCard("import-folder-save-card")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_importing_folder_game_save),
            folder.name,
        )
        ioExecutor.execute {
            try {
                val info = JSONObject(mymcApi.callAttr(
                    "import_save_any",
                    sourceCard.absolutePath,
                    folder.absolutePath,
                    workingCard.absolutePath,
                ).toString())
                runOnUiThread {
                    progress.dismiss()
                    val commit = {
                        commitPreparedImport(
                            workingCard,
                            destinationUri,
                            info,
                            onFinished,
                        )
                    }
                    if (info.optBoolean("overwritten", false)) {
                        MyMCDialog.show(
                            this,
                            getString(R.string.confirm_overwrite_game_save),
                            onCancel = {
                                discardCardCache(workingCard)
                                onFinished()
                            },
                        ) { commit() }
                    } else {
                        commit()
                    }
                }
            } catch (error: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(error)
                    onFinished()
                }
            }
        }
    }

    private fun importPsu(psuUri: Uri, onFinished: () -> Unit) {
        val sourceCard = cardFile ?: run { onFinished(); return }
        val destinationUri = cardUri ?: run { onFinished(); return }
        val displayName = try {
            contentResolver.query(psuUri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(android.provider.OpenableColumns.DISPLAY_NAME)) else ""
            } ?: ""
        } catch (_: Exception) { "" }
        val ext = displayName.substringAfterLast('.', "").lowercase()
        if (ext !in setOf("psu", "max", "sps", "xps", "cbs")) {
            onFinished()
            MyMCToast.show(
                this,
                getString(R.string.unsupported_format),
                getString(R.string.supported_import_formats),
                true
            )
            return
        }

        val temp = File(cacheDir, "import-${System.currentTimeMillis()}.$ext")
        val workingCard = newWorkingCard("import-card")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_importing_game_save),
            getString(R.string.progress_reading_card)
        )
        ioExecutor.execute {
            try {
                contentResolver.openInputStream(psuUri).use { rawInput ->
                    val input = BufferedInputStream(requireNotNull(rawInput), 256 * 1024)
                    BufferedOutputStream(temp.outputStream(), 256 * 1024).use { output ->
                        input.copyTo(output, 256 * 1024)
                    }
                }
                val info = JSONObject(mymcApi.callAttr(
                    "import_save_any", sourceCard.absolutePath, temp.absolutePath, workingCard.absolutePath
                ).toString())
                runOnUiThread {
                    progress.dismiss()
                    val commit = { commitPreparedImport(workingCard, destinationUri, info, onFinished) }
                    if (info.optBoolean("overwritten", false)) {
                        MyMCDialog.show(this, getString(R.string.confirm_overwrite_game_save), onCancel = {
                            discardCardCache(workingCard)
                            onFinished()
                        }) { commit() }
                    } else commit()
                }
            } catch (e: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(e)
                    onFinished()
                }
            } finally {
                temp.delete()
            }
        }
    }

    private fun commitPreparedImport(
        workingCard: File,
        destinationUri: Uri,
        info: JSONObject,
        onFinished: () -> Unit
    ) {
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_saving_card),
            getString(R.string.progress_writing_safely)
        )
        ioExecutor.execute {
            try {
                commitCardToUri(workingCard, destinationUri)
                val snapshot = JSONObject(mymcApi
                    .callAttr("card_snapshot", workingCard.absolutePath).toString())
                runOnUiThread {
                    progress.dismiss()
                    replaceActiveCard(workingCard, snapshot)
                    showCardContents(
                        snapshot.getJSONArray("saves"),
                        updateStatus = false,
                        previewFile = workingCard,
                    )
                    applyCardStatus(snapshot.getJSONObject("stats"))
                    val title = info.optString(
                        "title",
                        info.optString("save_name", getString(R.string.game_save_default))
                    ).trim()
                    val serial = info.optString("serial", "").trim()
                    val gameName = if (serial.isNotEmpty() && title != serial) "$title - $serial" else title
                    val toastTitle = if (info.optBoolean("overwritten", false)) {
                        getString(R.string.game_save_overwritten)
                    } else {
                        getString(R.string.game_save_imported)
                    }
                    MyMCToast.show(this, toastTitle, gameName, true)
                    MyMCSound.play(this, MyMCSound.Effect.IMPORT)
                    onFinished()
                }
            } catch (e: Exception) {
                discardCardCache(workingCard)
                runOnUiThread {
                    progress.dismiss()
                    showImportFailure(e)
                    onFinished()
                }
            }
        }
    }

    private fun showImportFailure(error: Exception) {
        val detail = error.message ?: error.toString()
        val normalized = detail.lowercase(java.util.Locale.ROOT)
        val noSpace = normalized.contains("sem espaço") ||
            normalized.contains("sem espaco") ||
            normalized.contains("no space") ||
            normalized.contains("errno 28")
        if (noSpace) {
            MyMCToast.show(
                this,
                getString(R.string.no_space_on_card),
                long = true
            )
        } else {
            MyMCToast.show(this, getString(R.string.import_failed), detail, true)
        }
    }

    private fun exportFolderSave(treeUri: Uri) {
        val file = pendingSingleExportCard ?: cardFile ?: run { finishToolbarAction(); return }
        val save = pendingSingleExportSave ?: selectedSave ?: run { finishToolbarAction(); return }
        val temp = File(cacheDir, "folder-save-export-${System.currentTimeMillis()}")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_exporting_game_save),
            getString(R.string.progress_generating_folder_format),
        )
        ioExecutor.execute {
            try {
                val result = JSONObject(mymcApi.callAttr(
                    "export_save_folder",
                    file.absolutePath,
                    save,
                    temp.absolutePath,
                ).toString())
                val exportedName = folderCardStorage.exportDirectoryToTree(
                    temp,
                    treeUri,
                    result.optString("folder_name", save),
                )
                runOnUiThread {
                    progress.dismiss()
                    updatePermanentStatus()
                    MyMCToast.show(
                        this,
                        getString(R.string.game_save_exported),
                        getString(R.string.folder_game_save_export_result, exportedName),
                        true,
                    )
                    MyMCSound.play(this, MyMCSound.Effect.EXPORT)
                    finishToolbarAction()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(
                        this,
                        getString(R.string.export_failed),
                        error.message,
                        true,
                    )
                    finishToolbarAction()
                }
            } finally {
                discardCardCache(temp)
            }
        }
    }

    private fun export(uri: Uri) {
        val file = pendingSingleExportCard ?: cardFile ?: return
        val save = pendingSingleExportSave ?: selectedSave ?: return
        val format = pendingExportFormat
        val tmp = File(cacheDir, "export-${System.currentTimeMillis()}.$format")
        val progress = MyMCProgressDialog.show(
            this,
            getString(R.string.progress_exporting_game_save),
            getString(R.string.progress_generating_format)
        )
        ioExecutor.execute {
            try {
                mymcApi.callAttr(
                    "export_save_any", file.absolutePath, save, tmp.absolutePath, format
                )
                copyFileToUri(tmp, uri)
                runOnUiThread {
                    progress.dismiss()
                    updatePermanentStatus()
                    MyMCToast.show(
                        this,
                        getString(R.string.game_save_exported),
                        format.uppercase(java.util.Locale.ROOT)
                    )
                    MyMCSound.play(this, MyMCSound.Effect.EXPORT)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    MyMCToast.show(this, getString(R.string.export_failed), e.message, true)
                }
            } finally {
                tmp.delete()
            }
        }
    }
}

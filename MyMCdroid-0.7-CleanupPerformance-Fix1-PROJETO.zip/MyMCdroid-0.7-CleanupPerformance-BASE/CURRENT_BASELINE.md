# Base oficial atual

`MyMCdroid 0.7 — Cleanup & Performance`

Esta versão foi aprovada em 14/08/2026 e passa a ser a base oficial para as próximas alterações. Foi criada a partir da antiga base oficial `MyMCdroid 0.6 — Directional Outline Icons`.

Itens consolidados:

- reorganização conservadora do código e dos arquivos de apoio;
- remoção de classes e recursos Android comprovadamente sem referências;
- testes Python e código legado preservados fora do pacote do aplicativo;
- cache de estruturas FAT somente leitura durante cada operação;
- reutilização do módulo Python durante a sessão do aplicativo;
- leitura parcial de cabeçalhos de importação e detecção de cartão apagado em blocos;
- redução de releituras de metadados mantendo a regra Serial ID + Região;
- interface, Manual, Sobre, múltiplos Memory Cards, formato pasta e PSU/MAX/CBS/SPS/XPS preservados.
- ícone Abrir Memory Card sem a linha azul interna, mantendo cor, tamanho e contorno externo.

O próximo ciclo de desenvolvimento deverá avançar para a versão 0.8.
